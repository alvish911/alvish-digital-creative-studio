# ALVISH – Digital Creative Studio

Premium black-and-red multi-page portfolio website and 20-section full-control Admin CMS built with React 19, TypeScript, Tailwind CSS v4, Motion, and Express.

## Features Included

- **Cinematic Intro & Persistent Audio**: Black-and-red volumetric glow reveal, glowing ALVISH emblem, `LET'S CREATE SOMETHING AMAZING` transition, autoplay attempt with visible Sound-On / Tap-to-Enable-Audio fallback, and uninterrupted playback across SPA navigation.
- **10 Complete Individual URL Pages**:
  - `/` — Home
  - `/about` — About
  - `/services` — Services (all 12 services + 3 editable Website Design Packages: ₹5,999 / ₹9,999 / ₹15,999)
  - `/skills` — Skills (animated progress bars + capability matrix)
  - `/experience` — Experience Timeline
  - `/portfolio` — Portfolio Gallery (7 categories, image/video previews, lightbox details)
  - `/achievements` — Achievements & Certifications
  - `/testimonials` — Client Reviews Slider (with pause/manual controls and clear Demo labeling until replaced)
  - `/contact` — Contact Details (WhatsApp `8247206736`, Instagram `alvish_studios_dwm`) + Server-Persisted Enquiry Form
  - `/admin/login` & `/admin/dashboard` — Secure Admin Portal with 20 management modules, Draft/Publish/Preview workflow, Media Upload, Backup & Restore.

## Quick Local Setup

```bash
npm install
cp .env.example .env
npm run dev
```

Visit `http://localhost:3000`.

### Admin Access Setup

- **Option 1 (Recommended for Production)**: Set `ADMIN_EMAIL` and `ADMIN_PASSWORD` in your server `.env` (or platform Secrets panel).
- **Option 2 (First-Run Claim)**: Leave `ADMIN_PASSWORD` empty on initial boot and navigate to `/admin/login` to claim the single admin account securely (hashed via `scrypt` on the server; the setup endpoint locks automatically once claimed).

## Supabase Production Database Setup

A complete PostgreSQL schema with all 12 tables and Row Level Security (RLS) policies is provided in `/supabase/schema.sql`.

1. Create a new Supabase project.
2. Open **SQL Editor** in Supabase and run `/supabase/schema.sql`.
3. Create your admin user in Supabase Authentication and insert their `auth.users.id` into `public.admin_users`.
4. Create a public storage bucket (e.g., `studio-media`) restricted to admin uploads.
5. Configure `SUPABASE_URL`, `SUPABASE_ANON_KEY`, and `SUPABASE_SERVICE_ROLE_KEY` in your production environment variables (never expose `SUPABASE_SERVICE_ROLE_KEY` in frontend code).

## Free Hosting (Netlify & Vercel)

This project includes `netlify.toml`, `public/_redirects`, and `vercel.json` ready for zero-config free static hosting:

- **Build Command**: `npm run build`
- **Publish / Output Directory**: `dist`
- **Node Version**: `20`

See `DEPLOYMENT.md` for step-by-step Netlify (GitHub & Drag-and-Drop) and Vercel instructions.

## Custom Intro Music

Your studio background track lives at `/public/assets/aistudio/alvish-track_c7df55aa.mp3`. When running the full-stack server (`npm start`), you can also change it from **Admin Dashboard → Music Settings**.

