# Deployment Guide — ALVISH Digital Creative Studio

This project is pre-configured for **FREE hosting on Netlify or Vercel** (static build) as well as full-stack Node.js hosting if you want the live server-backed Admin CMS.

---

## Option A: Deploy for FREE on Netlify (Recommended)

Both `netlify.toml` and `public/_redirects` are already included in the project so all 10 routes (`/about`, `/services`, `/portfolio`, `/contact`, etc.) and Netlify Forms work out of the box.

### Method 1: Deploy via GitHub (Automatic Updates)
1. Unzip `alvish-digital-creative-studio.zip` on your computer.
2. Create a free account at [github.com](https://github.com) and create a new repository (e.g., `alvish-studio`).
3. Upload or push all unzipped project files to your GitHub repository.
4. Create a free account at [netlify.com](https://www.netlify.com) and click **Add new site → Import an existing project**.
5. Choose **GitHub** and select your `alvish-studio` repository.
6. Verify the build settings (auto-detected from `netlify.toml`):
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`
7. Click **Deploy site**. Netlify installs dependencies, builds the app, and publishes it with a free HTTPS URL (`https://<your-site>.netlify.app`).
8. *(Optional)* Go to **Domain management** to change your free subdomain or connect a custom domain.

### Method 2: Drag & Drop Deploy (Netlify Drop — No Git Required)
1. Unzip `alvish-digital-creative-studio.zip` and open a terminal inside the folder.
2. Run:
   ```bash
   npm install
   npm run build
   ```
3. Go to [app.netlify.com/drop](https://app.netlify.com/drop).
4. Drag and drop the generated **`dist`** folder onto the page. Your site goes live immediately with free HTTPS.

### Contact Form on Free Netlify Hosting
- A hidden `<form name="contact" netlify>` blueprint is included in `index.html`.
- Submissions from `/contact` are automatically captured in your **Netlify Dashboard → Forms** for free, alongside your direct WhatsApp (`8247206736`) and Instagram (`@alvish_studios_dwm`) links.

---

## Option B: Deploy for FREE on Vercel

`vercel.json` is pre-configured with Vite build settings and SPA routing rewrites.

1. Push the unzipped project folder to GitHub (or install Vercel CLI: `npm i -g vercel`).
2. Sign in to [vercel.com](https://vercel.com) → **Add New → Project** → import your GitHub repository.
3. Confirm settings (auto-detected from `vercel.json`):
   - **Framework Preset**: Vite
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
4. Click **Deploy**.

---

## Option C: Full-Stack Node.js Hosting (Includes Live Admin CMS Backend)

Static hosts (Netlify / Vercel) serve the complete public portfolio website, animations, background music, and Netlify Forms for free. If you also want the live server-backed Admin Dashboard (`/admin/login` & `/admin/dashboard`) with server-side authentication and media uploads, host the Node server (`server.ts`) on a Node host (Render, Railway, Fly.io, Cloud Run, or VPS):

```bash
npm install
npm run build
NODE_ENV=production npm start
```

Set these environment variables on your Node host:
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD` (12+ characters with letters, numbers, and symbols)
- `APP_URL` (your production HTTPS domain)

For persistent PostgreSQL storage, run `/supabase/schema.sql` in Supabase.
