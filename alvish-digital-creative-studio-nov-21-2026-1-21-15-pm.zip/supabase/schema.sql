-- ============================================================================
-- ALVISH – DIGITAL CREATIVE STUDIO
-- Complete PostgreSQL / Supabase Production Schema with Row Level Security
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 1. Admin Users (linked to Supabase auth.users)
CREATE TABLE IF NOT EXISTS public.admin_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  auth_user_id UUID UNIQUE NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  role TEXT NOT NULL DEFAULT 'admin' CHECK (role IN ('super_admin', 'admin')),
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Helper function to verify authenticated admin status in RLS policies
CREATE OR REPLACE FUNCTION public.is_authorized_admin()
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.admin_users
    WHERE auth_user_id = auth.uid()
      AND is_active = true
  );
$$;

-- 2. Website Settings (singleton config for Home, About, Intro, Music, Theme, Contact, Socials, SEO)
CREATE TABLE IF NOT EXISTS public.website_settings (
  id TEXT PRIMARY KEY DEFAULT 'primary',
  brand_name TEXT NOT NULL DEFAULT 'ALVISH',
  business_name TEXT NOT NULL DEFAULT 'ALVISH – Digital Creative Studio',
  designation TEXT NOT NULL DEFAULT 'FREELANCER & ENTREPRENEUR',
  home_config JSONB NOT NULL DEFAULT '{}'::jsonb,
  about_config JSONB NOT NULL DEFAULT '{}'::jsonb,
  contact_config JSONB NOT NULL DEFAULT '{}'::jsonb,
  social_links JSONB NOT NULL DEFAULT '{}'::jsonb,
  intro_settings JSONB NOT NULL DEFAULT '{}'::jsonb,
  music_settings JSONB NOT NULL DEFAULT '{}'::jsonb,
  theme_settings JSONB NOT NULL DEFAULT '{}'::jsonb,
  seo_settings JSONB NOT NULL DEFAULT '{}'::jsonb,
  section_visibility JSONB NOT NULL DEFAULT '{}'::jsonb,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 3. Services (12+ editable services)
CREATE TABLE IF NOT EXISTS public.services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  short_description TEXT NOT NULL,
  full_description TEXT NOT NULL,
  starting_price TEXT NOT NULL,
  icon_name TEXT NOT NULL DEFAULT 'Globe',
  image_url TEXT,
  deliverables JSONB NOT NULL DEFAULT '[]'::jsonb,
  is_featured BOOLEAN NOT NULL DEFAULT false,
  is_active BOOLEAN NOT NULL DEFAULT true,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 4. Pricing Packages (Basic ₹5,999, Premium ₹9,999, Pro ₹15,999 — fully editable features)
CREATE TABLE IF NOT EXISTS public.pricing_packages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  price TEXT NOT NULL,
  subtitle TEXT NOT NULL DEFAULT '',
  features JSONB NOT NULL DEFAULT '[]'::jsonb,
  is_highlighted BOOLEAN NOT NULL DEFAULT false,
  whatsapp_message TEXT NOT NULL DEFAULT '',
  sort_order INTEGER NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 5. Skills
CREATE TABLE IF NOT EXISTS public.skills (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'Design & Strategy',
  percentage INTEGER NOT NULL CHECK (percentage >= 0 AND percentage <= 100),
  description TEXT NOT NULL DEFAULT '',
  sort_order INTEGER NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 6. Experience Timeline
CREATE TABLE IF NOT EXISTS public.experience (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  company_or_project TEXT NOT NULL,
  description TEXT NOT NULL,
  start_date TEXT NOT NULL,
  end_date TEXT NOT NULL DEFAULT 'Present',
  highlights JSONB NOT NULL DEFAULT '[]'::jsonb,
  sort_order INTEGER NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 7. Portfolio Projects (7 categories + reorderable)
CREATE TABLE IF NOT EXISTS public.portfolio_projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  category TEXT NOT NULL CHECK (
    category IN (
      'Website Designs',
      'AI Videos',
      'AI Songs',
      'Advertisements',
      'Posters',
      'Business Promotions',
      'Social Media Designs'
    )
  ),
  client_name TEXT NOT NULL DEFAULT '',
  year TEXT NOT NULL DEFAULT '2026',
  summary TEXT NOT NULL,
  details TEXT NOT NULL DEFAULT '',
  image_url TEXT NOT NULL,
  video_url TEXT,
  project_url TEXT,
  metrics TEXT,
  is_featured BOOLEAN NOT NULL DEFAULT false,
  is_published BOOLEAN NOT NULL DEFAULT true,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 8. Achievements & Certifications
CREATE TABLE IF NOT EXISTS public.achievements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  issuer TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('Certificate', 'Award', 'Milestone', 'Recognition')),
  date_label TEXT NOT NULL,
  description TEXT NOT NULL,
  image_url TEXT,
  credential_url TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 9. Testimonials / Client Reviews
CREATE TABLE IF NOT EXISTS public.testimonials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_name TEXT NOT NULL,
  client_role TEXT NOT NULL DEFAULT '',
  client_company TEXT NOT NULL DEFAULT '',
  client_avatar_url TEXT,
  review_text TEXT NOT NULL,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  is_demo BOOLEAN NOT NULL DEFAULT false,
  is_published BOOLEAN NOT NULL DEFAULT true,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 10. Contact Enquiries
CREATE TABLE IF NOT EXISTS public.contact_enquiries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT NOT NULL,
  message TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'read', 'replied', 'archived')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 11. Navigation Items
CREATE TABLE IF NOT EXISTS public.navigation (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  label TEXT NOT NULL,
  path TEXT NOT NULL UNIQUE,
  is_visible BOOLEAN NOT NULL DEFAULT true,
  sort_order INTEGER NOT NULL DEFAULT 0
);

-- 12. Media Files Registry
CREATE TABLE IF NOT EXISTS public.media_files (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  file_name TEXT NOT NULL,
  storage_path TEXT NOT NULL,
  public_url TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  size_bytes INTEGER NOT NULL,
  uploaded_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ============================================================================

ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.website_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pricing_packages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.skills ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.experience ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.portfolio_projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.testimonials ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contact_enquiries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.navigation ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.media_files ENABLE ROW LEVEL SECURITY;

-- Admin Users: Only authorized admins can view or manage
CREATE POLICY "Admins can view admin_users"
  ON public.admin_users FOR SELECT USING (public.is_authorized_admin());

-- Public READ for published content tables
CREATE POLICY "Public read website_settings"
  ON public.website_settings FOR SELECT USING (true);
CREATE POLICY "Admin write website_settings"
  ON public.website_settings FOR ALL USING (public.is_authorized_admin()) WITH CHECK (public.is_authorized_admin());

CREATE POLICY "Public read active services"
  ON public.services FOR SELECT USING (is_active = true OR public.is_authorized_admin());
CREATE POLICY "Admin write services"
  ON public.services FOR ALL USING (public.is_authorized_admin()) WITH CHECK (public.is_authorized_admin());

CREATE POLICY "Public read pricing_packages"
  ON public.pricing_packages FOR SELECT USING (true);
CREATE POLICY "Admin write pricing_packages"
  ON public.pricing_packages FOR ALL USING (public.is_authorized_admin()) WITH CHECK (public.is_authorized_admin());

CREATE POLICY "Public read skills"
  ON public.skills FOR SELECT USING (true);
CREATE POLICY "Admin write skills"
  ON public.skills FOR ALL USING (public.is_authorized_admin()) WITH CHECK (public.is_authorized_admin());

CREATE POLICY "Public read experience"
  ON public.experience FOR SELECT USING (true);
CREATE POLICY "Admin write experience"
  ON public.experience FOR ALL USING (public.is_authorized_admin()) WITH CHECK (public.is_authorized_admin());

CREATE POLICY "Public read published portfolio"
  ON public.portfolio_projects FOR SELECT USING (is_published = true OR public.is_authorized_admin());
CREATE POLICY "Admin write portfolio"
  ON public.portfolio_projects FOR ALL USING (public.is_authorized_admin()) WITH CHECK (public.is_authorized_admin());

CREATE POLICY "Public read achievements"
  ON public.achievements FOR SELECT USING (true);
CREATE POLICY "Admin write achievements"
  ON public.achievements FOR ALL USING (public.is_authorized_admin()) WITH CHECK (public.is_authorized_admin());

CREATE POLICY "Public read published testimonials"
  ON public.testimonials FOR SELECT USING (is_published = true OR public.is_authorized_admin());
CREATE POLICY "Admin write testimonials"
  ON public.testimonials FOR ALL USING (public.is_authorized_admin()) WITH CHECK (public.is_authorized_admin());

CREATE POLICY "Public read visible navigation"
  ON public.navigation FOR SELECT USING (is_visible = true OR public.is_authorized_admin());
CREATE POLICY "Admin write navigation"
  ON public.navigation FOR ALL USING (public.is_authorized_admin()) WITH CHECK (public.is_authorized_admin());

-- Contact Enquiries: Public INSERT only, Admin SELECT/UPDATE/DELETE
CREATE POLICY "Public submit contact_enquiries"
  ON public.contact_enquiries FOR INSERT WITH CHECK (true);
CREATE POLICY "Admin manage contact_enquiries"
  ON public.contact_enquiries FOR SELECT USING (public.is_authorized_admin());
CREATE POLICY "Admin update contact_enquiries"
  ON public.contact_enquiries FOR UPDATE USING (public.is_authorized_admin());
CREATE POLICY "Admin delete contact_enquiries"
  ON public.contact_enquiries FOR DELETE USING (public.is_authorized_admin());

-- Media Files: Public read, Admin write
CREATE POLICY "Public read media_files"
  ON public.media_files FOR SELECT USING (true);
CREATE POLICY "Admin write media_files"
  ON public.media_files FOR ALL USING (public.is_authorized_admin()) WITH CHECK (public.is_authorized_admin());
