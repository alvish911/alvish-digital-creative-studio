import 'dotenv/config';
import express, { type Request, type Response, type NextFunction } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { createServer as createViteServer } from 'vite';
import { StudioStore } from './src/server/store.ts';
import {
  RateLimiter,
  SessionManager,
  constantTimeStringEqual,
  hashPassword,
  verifyPassword,
} from './src/server/auth.ts';
import {
  sanitizeText,
  validateAdminPassword,
  validateBackupPayload,
  validateContactForm,
} from './src/shared/validation.ts';
import type { SiteContent } from './src/shared/types.ts';

const PORT = 3000;
const IS_PROD = process.env.NODE_ENV === 'production';
const UPLOADS_DIR = path.resolve(process.cwd(), 'public', 'uploads');
fs.mkdirSync(UPLOADS_DIR, { recursive: true });

const store = new StudioStore();
const sessions = new SessionManager();
const loginLimiter = new RateLimiter(6, 15 * 60 * 1000);
const contactLimiter = new RateLimiter(10, 15 * 60 * 1000);

interface AuthenticatedRequest extends Request {
  adminEmail?: string;
  adminToken?: string;
}

function getClientIp(req: Request): string {
  const forwarded = req.headers['x-forwarded-for'];
  if (typeof forwarded === 'string' && forwarded.length > 0) {
    return forwarded.split(',')[0].trim();
  }
  return req.ip || req.socket.remoteAddress || 'unknown';
}

function getEnvAdminConfig(): { email: string; password: string } | null {
  const envPass = (process.env.ADMIN_PASSWORD || '').trim();
  if (!envPass) return null;
  const envEmail = (process.env.ADMIN_EMAIL || 'admin@alvishstudios.com').trim().toLowerCase();
  return { email: envEmail, password: envPass };
}

function extractBearerToken(req: Request): string | null {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) return null;
  return header.slice('Bearer '.length).trim() || null;
}

function requireAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const token = extractBearerToken(req);
  const session = sessions.verify(token);
  if (!session) {
    res.status(401).json({ error: 'Authentication required. Please sign in to the admin panel.' });
    return;
  }
  req.adminEmail = session.email;
  req.adminToken = session.token;
  next();
}

const ALLOWED_UPLOAD_TYPES: Record<string, { ext: string; maxBytes: number; checkMagic: (buf: Buffer) => boolean }> = {
  'image/png': {
    ext: '.png',
    maxBytes: 6 * 1024 * 1024,
    checkMagic: (b) => b.length >= 8 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47,
  },
  'image/jpeg': {
    ext: '.jpg',
    maxBytes: 6 * 1024 * 1024,
    checkMagic: (b) => b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff,
  },
  'image/webp': {
    ext: '.webp',
    maxBytes: 6 * 1024 * 1024,
    checkMagic: (b) => b.length >= 12 && b.subarray(0, 4).toString('ascii') === 'RIFF' && b.subarray(8, 12).toString('ascii') === 'WEBP',
  },
  'audio/wav': {
    ext: '.wav',
    maxBytes: 12 * 1024 * 1024,
    checkMagic: (b) => b.length >= 12 && b.subarray(0, 4).toString('ascii') === 'RIFF' && b.subarray(8, 12).toString('ascii') === 'WAVE',
  },
  'audio/mpeg': {
    ext: '.mp3',
    maxBytes: 12 * 1024 * 1024,
    checkMagic: (b) =>
      b.length >= 3 &&
      ((b[0] === 0x49 && b[1] === 0x44 && b[2] === 0x33) || (b[0] === 0xff && (b[1] & 0xe0) === 0xe0)),
  },
  'video/mp4': {
    ext: '.mp4',
    maxBytes: 15 * 1024 * 1024,
    checkMagic: (b) => b.length >= 8 && b.subarray(4, 8).toString('ascii') === 'ftyp',
  },
};

async function startServer() {
  const app = express();
  app.disable('x-powered-by');
  app.use(express.json({ limit: '16mb' }));

  // Baseline security headers compatible with embedded preview iframe
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    next();
  });

  // Serve uploaded media safely with strict no-sniff
  app.use('/uploads', express.static(UPLOADS_DIR, { maxAge: '7d', index: false }));

  // Exported deployable archives (served from workspace root without polluting public/ or dist/)
  const getArchiveMeta = (fileName: string) => {
    const target = path.resolve(process.cwd(), fileName);
    if (!fs.existsSync(target)) {
      return { available: false, fileName, sizeBytes: 0, sizeLabel: '0 MB' };
    }
    const sizeBytes = fs.statSync(target).size;
    return {
      available: true,
      fileName,
      sizeBytes,
      sizeLabel: `${(sizeBytes / (1024 * 1024)).toFixed(2)} MB`,
    };
  };

  const sendArchive = (res: Response, fileName: string) => {
    const zipPath = path.resolve(process.cwd(), fileName);
    if (!fs.existsSync(zipPath)) {
      res.status(404).json({ error: `${fileName} not found.` });
      return;
    }
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Cache-Control', 'no-store');
    res.download(zipPath, fileName);
  };

  app.get('/api/export/info', (_req, res) => {
    res.json({
      sourceZip: getArchiveMeta('alvish-digital-creative-studio.zip'),
      distZip: getArchiveMeta('alvish-studio-netlify-drop.zip'),
    });
  });

  app.get('/api/export/source-zip', (_req, res) => {
    sendArchive(res, 'alvish-digital-creative-studio.zip');
  });

  app.get('/api/export/dist-zip', (_req, res) => {
    sendArchive(res, 'alvish-studio-netlify-drop.zip');
  });

  app.get('/downloads/alvish-digital-creative-studio.zip', (_req, res) => {
    sendArchive(res, 'alvish-digital-creative-studio.zip');
  });

  app.get('/downloads/alvish-studio-netlify-drop.zip', (_req, res) => {
    sendArchive(res, 'alvish-studio-netlify-drop.zip');
  });

  // Public site content API (never exposes admin hashes or enquiries)
  app.get('/api/site', (_req, res) => {
    res.json(store.getPublishedSite());
  });

  // Public contact form submission with validation & rate limiting
  app.post('/api/contact', (req, res) => {
    const ip = getClientIp(req);
    const limit = contactLimiter.check(ip);
    if (!limit.allowed) {
      res.setHeader('Retry-After', String(limit.retryAfterSeconds));
      res.status(429).json({
        error: `Too many enquiries submitted recently. Please wait ${limit.retryAfterSeconds} seconds or message directly on WhatsApp.`,
      });
      return;
    }

    const input = {
      name: sanitizeText(req.body?.name, 120),
      phone: sanitizeText(req.body?.phone, 30),
      email: sanitizeText(req.body?.email, 160),
      message: sanitizeText(req.body?.message, 3000),
    };

    const validation = validateContactForm(input);
    if (!validation.valid) {
      res.status(400).json({ error: 'Please check the highlighted form fields.', errors: validation.errors });
      return;
    }

    contactLimiter.recordAttempt(ip);
    const saved = store.addEnquiry(input);
    res.status(201).json({
      ok: true,
      id: saved.id,
      createdAt: saved.createdAt,
      message: 'Your enquiry has been received and saved by ALVISH – Digital Creative Studio.',
    });
  });

  // Admin auth status
  app.get('/api/admin/auth/status', (req, res) => {
    const token = extractBearerToken(req);
    const session = sessions.verify(token);
    const envAdmin = getEnvAdminConfig();
    const storedAdmin = store.getAdminCredential();
    res.json({
      authenticated: Boolean(session),
      needsBootstrap: !envAdmin && !storedAdmin,
      envManaged: Boolean(envAdmin),
      email: session?.email ?? null,
    });
  });

  // First-run one-time admin setup (locks permanently once claimed or if env password is set)
  app.post('/api/admin/auth/bootstrap', (req, res) => {
    const envAdmin = getEnvAdminConfig();
    const existing = store.getAdminCredential();
    if (envAdmin || existing) {
      res.status(409).json({ error: 'Admin account is already configured. Please sign in.' });
      return;
    }

    const email = sanitizeText(req.body?.email, 160).toLowerCase();
    const password = typeof req.body?.password === 'string' ? req.body.password : '';

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
      res.status(400).json({ error: 'Please enter a valid admin email address.' });
      return;
    }

    const pwCheck = validateAdminPassword(password);
    if (!pwCheck.valid) {
      res.status(400).json({ error: pwCheck.reason });
      return;
    }

    const now = new Date().toISOString();
    store.setAdminCredential({
      email,
      passwordHash: hashPassword(password),
      createdAt: now,
      updatedAt: now,
    });
    store.recordSecurityEvent('admin_bootstrap', email, 'Initial admin account securely claimed via scrypt hash.');

    const session = sessions.create(email);
    res.status(201).json({
      token: session.token,
      email: session.email,
      expiresAt: session.expiresAt,
    });
  });

  // Admin login with rate limiting and timing-safe verification
  app.post('/api/admin/auth/login', (req, res) => {
    const ip = getClientIp(req);
    const limit = loginLimiter.check(ip);
    if (!limit.allowed) {
      res.setHeader('Retry-After', String(limit.retryAfterSeconds));
      res.status(429).json({
        error: `Too many failed login attempts. Try again in ${limit.retryAfterSeconds} seconds.`,
      });
      return;
    }

    const email = sanitizeText(req.body?.email, 160).toLowerCase();
    const password = typeof req.body?.password === 'string' ? req.body.password : '';

    if (!email || !password) {
      res.status(400).json({ error: 'Email and password are required.' });
      return;
    }

    const envAdmin = getEnvAdminConfig();
    const storedAdmin = store.getAdminCredential();

    if (!envAdmin && !storedAdmin) {
      res.status(409).json({ error: 'Admin account is not initialized yet. Complete first-run setup first.' });
      return;
    }

    let isValid = false;
    let resolvedEmail = email;

    if (envAdmin) {
      const emailOk = constantTimeStringEqual(email, envAdmin.email);
      const passOk = constantTimeStringEqual(password, envAdmin.password);
      isValid = emailOk && passOk;
      resolvedEmail = envAdmin.email;
    } else if (storedAdmin) {
      const emailOk = constantTimeStringEqual(email, storedAdmin.email);
      const passOk = verifyPassword(password, storedAdmin.passwordHash);
      isValid = emailOk && passOk;
      resolvedEmail = storedAdmin.email;
    }

    if (!isValid) {
      loginLimiter.recordAttempt(ip);
      store.recordSecurityEvent('login_failed', email || 'unknown', `Failed sign-in attempt from ${ip}`);
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    loginLimiter.reset(ip);
    const session = sessions.create(resolvedEmail);
    store.recordSecurityEvent('login_success', resolvedEmail, 'Authenticated admin session created.');
    res.json({
      token: session.token,
      email: session.email,
      expiresAt: session.expiresAt,
    });
  });

  app.post('/api/admin/auth/logout', requireAdmin, (req: AuthenticatedRequest, res) => {
    if (req.adminToken) {
      sessions.revoke(req.adminToken);
    }
    store.recordSecurityEvent('logout', req.adminEmail || 'admin', 'Admin signed out.');
    res.json({ ok: true });
  });

  app.post('/api/admin/auth/change-password', requireAdmin, (req: AuthenticatedRequest, res) => {
    if (getEnvAdminConfig()) {
      res.status(400).json({
        error: 'Admin password is managed by the server ADMIN_PASSWORD environment variable. Update it in Secrets.',
      });
      return;
    }
    const storedAdmin = store.getAdminCredential();
    if (!storedAdmin) {
      res.status(400).json({ error: 'No stored admin credential found.' });
      return;
    }

    const currentPassword = typeof req.body?.currentPassword === 'string' ? req.body.currentPassword : '';
    const newPassword = typeof req.body?.newPassword === 'string' ? req.body.newPassword : '';

    if (!verifyPassword(currentPassword, storedAdmin.passwordHash)) {
      res.status(401).json({ error: 'Current password is incorrect.' });
      return;
    }

    const pwCheck = validateAdminPassword(newPassword);
    if (!pwCheck.valid) {
      res.status(400).json({ error: pwCheck.reason });
      return;
    }

    store.setAdminCredential({
      ...storedAdmin,
      passwordHash: hashPassword(newPassword),
      updatedAt: new Date().toISOString(),
    });
    store.recordSecurityEvent('password_changed', req.adminEmail || storedAdmin.email, 'Admin password updated.');
    res.json({ ok: true, message: 'Admin password updated successfully.' });
  });

  // Protected Admin CMS state
  app.get('/api/admin/state', requireAdmin, (_req, res) => {
    res.json({
      published: store.getPublishedSite(),
      draft: store.getDraftSite(),
      hasUnpublishedChanges: store.hasUnpublishedChanges(),
      enquiries: store.listEnquiries(),
      media: store.listMedia(),
      securityEvents: store.listSecurityEvents(),
    });
  });

  app.put('/api/admin/draft', requireAdmin, (req: AuthenticatedRequest, res) => {
    const check = validateBackupPayload(req.body?.content);
    if (!check.valid || !check.site) {
      res.status(400).json({ error: check.error || 'Invalid website configuration payload.' });
      return;
    }
    const saved = store.saveDraft(check.site);
    res.json({ ok: true, draft: saved, hasUnpublishedChanges: store.hasUnpublishedChanges() });
  });

  app.post('/api/admin/publish', requireAdmin, (req: AuthenticatedRequest, res) => {
    let incoming: SiteContent | undefined;
    if (req.body?.content) {
      const check = validateBackupPayload(req.body.content);
      if (!check.valid || !check.site) {
        res.status(400).json({ error: check.error || 'Invalid content payload.' });
        return;
      }
      incoming = check.site;
    }
    const published = store.publish(incoming);
    store.recordSecurityEvent('site_published', req.adminEmail || 'admin', `Published site version ${published.version}`);
    res.json({ ok: true, published, draft: published, hasUnpublishedChanges: false });
  });

  app.post('/api/admin/discard-draft', requireAdmin, (_req, res) => {
    const draft = store.discardDraft();
    res.json({ ok: true, draft, hasUnpublishedChanges: false });
  });

  // Contact enquiry management
  app.patch('/api/admin/enquiries/:id', requireAdmin, (req, res) => {
    const id = sanitizeText(req.params.id, 64);
    const status = req.body?.status;
    if (status !== 'new' && status !== 'read' && status !== 'replied') {
      res.status(400).json({ error: 'Invalid status value.' });
      return;
    }
    const updated = store.updateEnquiryStatus(id, status);
    if (!updated) {
      res.status(404).json({ error: 'Enquiry not found.' });
      return;
    }
    res.json({ ok: true, enquiry: updated });
  });

  app.delete('/api/admin/enquiries/:id', requireAdmin, (req, res) => {
    const id = sanitizeText(req.params.id, 64);
    const deleted = store.deleteEnquiry(id);
    if (!deleted) {
      res.status(404).json({ error: 'Enquiry not found.' });
      return;
    }
    res.json({ ok: true });
  });

  // Secure media upload (base64 payload with strict MIME + magic-byte validation + path confinement)
  app.post('/api/admin/media/upload', requireAdmin, (req: AuthenticatedRequest, res) => {
    const mimeType = sanitizeText(req.body?.mimeType, 80).toLowerCase();
    const rawName = sanitizeText(req.body?.fileName, 120);
    const base64Data = typeof req.body?.dataBase64 === 'string' ? req.body.dataBase64 : '';

    const rule = ALLOWED_UPLOAD_TYPES[mimeType];
    if (!rule) {
      res.status(400).json({
        error: 'Unsupported file type. Allowed formats: PNG, JPEG, WebP, WAV, MP3, MP4.',
      });
      return;
    }

    const stripped = base64Data.includes(',') ? base64Data.split(',')[1] : base64Data;
    const buffer = Buffer.from(stripped, 'base64');
    if (buffer.length === 0 || buffer.length > rule.maxBytes) {
      res.status(400).json({
        error: `File size must be between 1 byte and ${Math.round(rule.maxBytes / (1024 * 1024))} MB.`,
      });
      return;
    }

    if (!rule.checkMagic(buffer)) {
      res.status(400).json({ error: 'File contents do not match the declared media format.' });
      return;
    }

    const safeStem = (rawName.replace(/\.[^/.]+$/, '').replace(/[^a-zA-Z0-9_-]/g, '-').slice(0, 40) || 'asset').toLowerCase();
    const uniqueName = `${safeStem}-${crypto.randomBytes(6).toString('hex')}${rule.ext}`;
    const resolvedTarget = path.resolve(UPLOADS_DIR, uniqueName);
    if (!resolvedTarget.startsWith(UPLOADS_DIR + path.sep)) {
      res.status(400).json({ error: 'Invalid upload destination.' });
      return;
    }

    fs.writeFileSync(resolvedTarget, buffer);
    const record = store.addMedia({
      fileName: uniqueName,
      url: `/uploads/${uniqueName}`,
      mimeType,
      sizeBytes: buffer.length,
    });
    store.recordSecurityEvent('media_upload', req.adminEmail || 'admin', `Uploaded ${uniqueName} (${mimeType})`);
    res.status(201).json({ ok: true, media: record });
  });

  app.delete('/api/admin/media/:id', requireAdmin, (req: AuthenticatedRequest, res) => {
    const id = sanitizeText(req.params.id, 64);
    const removed = store.deleteMedia(id);
    if (!removed) {
      res.status(404).json({ error: 'Media item not found.' });
      return;
    }
    if (removed.url.startsWith('/uploads/')) {
      const fileName = path.basename(removed.url);
      const resolvedTarget = path.resolve(UPLOADS_DIR, fileName);
      if (resolvedTarget.startsWith(UPLOADS_DIR + path.sep) && fs.existsSync(resolvedTarget)) {
        try {
          fs.unlinkSync(resolvedTarget);
        } catch (err) {
          console.error('Could not unlink uploaded asset:', err);
        }
      }
    }
    store.recordSecurityEvent('media_delete', req.adminEmail || 'admin', `Deleted media ${removed.fileName}`);
    res.json({ ok: true });
  });

  // Backup & Restore endpoints
  app.get('/api/admin/backup', requireAdmin, (req: AuthenticatedRequest, res) => {
    const backup = store.exportBackup();
    store.recordSecurityEvent('backup_exported', req.adminEmail || 'admin', 'Exported full CMS JSON backup.');
    res.setHeader('Content-Disposition', 'attachment; filename="alvish-studio-backup.json"');
    res.json(backup);
  });

  app.post('/api/admin/restore', requireAdmin, (req: AuthenticatedRequest, res) => {
    const check = validateBackupPayload(req.body);
    if (!check.valid || !check.site) {
      res.status(400).json({ error: check.error || 'Backup file failed validation.' });
      return;
    }
    const enquiries = Array.isArray(req.body?.enquiries) ? req.body.enquiries : undefined;
    const restored = store.restoreBackup(check.site, enquiries);
    store.recordSecurityEvent('backup_restored', req.adminEmail || 'admin', 'Restored studio content from backup JSON.');
    res.json({ ok: true, published: restored, draft: restored, hasUnpublishedChanges: false });
  });

  // Frontend serving (Vite middleware in dev, dist/ static in prod, SPA fallback for all 10 routes)
  if (!IS_PROD) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir, { maxAge: '1d' }));
    app.get('*', (req, res, next) => {
      if (req.path.startsWith('/api/')) {
        next();
        return;
      }
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ALVISH – Digital Creative Studio server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start ALVISH Studio server:', err);
  process.exit(1);
});
