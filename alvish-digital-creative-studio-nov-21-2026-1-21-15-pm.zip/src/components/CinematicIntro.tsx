import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Volume2, VolumeX, ArrowRight } from 'lucide-react';
import { useSite } from '../context/SiteContext';
import { useStudioAudio } from '../context/AudioContext';

interface CinematicIntroProps {
  onComplete: () => void;
}

export const CinematicIntro: React.FC<CinematicIntroProps> = ({ onComplete }) => {
  const { site } = useSite();
  const { isPlaying, isMuted, autoplayBlocked, enableAudio, toggleMute } = useStudioAudio();
  const [phase, setPhase] = useState<'brand' | 'tagline' | 'exit'>('brand');

  useEffect(() => {
    const duration = Math.max(2600, Math.min(7000, site.intro.durationMs || 4200));
    const taglineDelay = Math.round(duration * 0.56);
    const exitDelay = duration;
    const completeDelay = duration + 550;

    const t1 = window.setTimeout(() => setPhase('tagline'), taglineDelay);
    const t2 = window.setTimeout(() => setPhase('exit'), exitDelay);
    const t3 = window.setTimeout(() => onComplete(), completeDelay);

    // Failsafe timer guarantees site never stays stuck on intro
    const failsafe = window.setTimeout(() => onComplete(), completeDelay + 1200);

    return () => {
      window.clearTimeout(t1);
      window.clearTimeout(t2);
      window.clearTimeout(t3);
      window.clearTimeout(failsafe);
    };
  }, [site.intro.durationMs, onComplete]);

  return (
    <AnimatePresence>
      {phase !== 'exit' && (
        <motion.div
          key="alvish-intro"
          data-testid="cinematic-intro"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.55, ease: [0.16, 1, 0.3, 1] } }}
          className="fixed inset-0 z-50 flex flex-col items-center justify-center overflow-hidden bg-[#050505] px-6 text-center select-none"
        >
          {/* Cinematic crimson light beams */}
          <motion.div
            aria-hidden="true"
            initial={{ opacity: 0, scale: 0.75 }}
            animate={{ opacity: [0.25, 0.72, 0.45], scale: [0.85, 1.12, 1] }}
            transition={{ duration: 3.4, ease: [0.16, 1, 0.3, 1] }}
            className="pointer-events-none absolute h-[460px] w-[460px] rounded-full blur-[120px]"
            style={{
              background:
                'radial-gradient(circle, rgba(255,23,68,0.42) 0%, rgba(139,0,0,0.22) 48%, rgba(5,5,5,0) 76%)',
            }}
          />
          <motion.div
            aria-hidden="true"
            initial={{ x: '-45%', opacity: 0 }}
            animate={{ x: '45%', opacity: [0, 0.55, 0] }}
            transition={{ duration: 2.8, ease: 'easeInOut' }}
            className="pointer-events-none absolute inset-y-0 w-72 -skew-x-12 bg-gradient-to-r from-transparent via-[#FF1744]/20 to-transparent blur-2xl"
          />

          {/* Top Controls: Visible Sound-On / Audio fallback + Skip */}
          <div className="absolute top-6 inset-x-6 flex items-center justify-between max-w-6xl mx-auto">
            {site.music.enabled ? (
              <button
                type="button"
                onClick={() => {
                  if (autoplayBlocked || !isPlaying) {
                    void enableAudio();
                  } else {
                    toggleMute();
                  }
                }}
                aria-label={isMuted || autoplayBlocked ? 'Enable intro sound' : 'Mute intro sound'}
                className="glass-panel inline-flex items-center gap-2 rounded-lg px-4 py-2 text-xs font-medium text-white hover:border-[#FF1744]/50 transition-colors cursor-pointer whitespace-nowrap"
              >
                {isMuted || autoplayBlocked || !isPlaying ? (
                  <>
                    <VolumeX className="w-4 h-4 text-[#FF1744]" aria-hidden="true" />
                    <span>{autoplayBlocked ? 'Tap to Enable Sound' : 'Sound Off'}</span>
                  </>
                ) : (
                  <>
                    <Volume2 className="w-4 h-4 text-[#FF1744]" aria-hidden="true" />
                    <span>Sound On</span>
                  </>
                )}
              </button>
            ) : (
              <div />
            )}

            {site.intro.skipButtonVisible && (
              <button
                type="button"
                onClick={onComplete}
                className="glass-panel inline-flex items-center gap-2 rounded-lg px-4 py-2 text-xs font-medium text-zinc-200 hover:text-white hover:border-[#FF1744]/50 transition-colors cursor-pointer whitespace-nowrap"
              >
                <span>Enter Studio</span>
                <ArrowRight className="w-3.5 h-3.5 text-[#FF1744]" aria-hidden="true" />
              </button>
            )}
          </div>

          {/* Center Sequence */}
          <div className="relative z-10 max-w-3xl mx-auto">
            <AnimatePresence mode="wait">
              {phase === 'brand' ? (
                <motion.div
                  key="phase-brand"
                  initial={{ opacity: 0, y: 18 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -14, filter: 'blur(6px)' }}
                  transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
                  className="flex flex-col items-center"
                >
                  {/* Glowing ALVISH Monogram Mark */}
                  <motion.div
                    initial={{ scale: 0.82, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
                    className="relative mb-8 flex h-20 w-20 items-center justify-center rounded-2xl border border-[#FF1744]/40 bg-[#101010]/80 backdrop-blur-xl shadow-[0_0_60px_-8px_rgba(255,23,68,0.65)]"
                  >
                    <span className="font-display text-3xl font-extrabold tracking-tight text-white">
                      A
                    </span>
                    <span
                      aria-hidden="true"
                      className="absolute inset-0 rounded-2xl border border-[#FF1744]/25 scale-110"
                    />
                  </motion.div>

                  <motion.h1
                    initial={{ letterSpacing: '0.35em', opacity: 0 }}
                    animate={{ letterSpacing: '0.18em', opacity: 1 }}
                    transition={{ duration: 0.9, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
                    className="font-display text-5xl sm:text-6xl md:text-7xl font-extrabold text-white"
                  >
                    {site.home.brandName}
                  </motion.h1>

                  <motion.p
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.7, delay: 0.4 }}
                    className="mt-4 font-display text-sm sm:text-base font-semibold tracking-[0.28em] text-[#FF1744]"
                  >
                    {site.home.subheading}
                  </motion.p>

                  <motion.div
                    initial={{ scaleX: 0, opacity: 0 }}
                    animate={{ scaleX: 1, opacity: 1 }}
                    transition={{ duration: 0.7, delay: 0.6 }}
                    className="my-6 h-px w-28 bg-gradient-to-r from-transparent via-[#FF1744] to-transparent"
                  />

                  <motion.p
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.6, delay: 0.78 }}
                    className="text-xs sm:text-sm font-medium tracking-[0.24em] text-zinc-300"
                  >
                    {site.home.designation}
                  </motion.p>
                </motion.div>
              ) : (
                <motion.div
                  key="phase-tagline"
                  initial={{ opacity: 0, scale: 0.96, y: 12 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
                  className="flex flex-col items-center"
                >
                  <p className="font-display text-2xl sm:text-4xl md:text-5xl font-bold tracking-[0.08em] text-white text-balance">
                    {site.intro.tagline || "LET'S CREATE SOMETHING AMAZING"}
                  </p>
                  <div className="mt-6 h-0.5 w-24 bg-gradient-to-r from-transparent via-[#FF1744] to-transparent" />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
