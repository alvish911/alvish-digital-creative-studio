import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, Volume2, VolumeX } from 'lucide-react';
import { useSite } from '../context/SiteContext';
import { useStudioAudio } from '../context/AudioContext';

export const Navbar: React.FC = () => {
  const { site } = useSite();
  const { isPlaying, isMuted, autoplayBlocked, enableAudio, toggleMute } = useStudioAudio();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  const visibleNav = [...site.navigation]
    .filter((item) => item.visible)
    .sort((a, b) => a.order - b.order);

  const isRouteActive = (path: string) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname === path || location.pathname.startsWith(`${path}/`);
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-white/[0.08] bg-[#050505]/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
        {/* Zone 1: Clean single-line brand wordmark */}
        <Link
          to="/"
          onClick={() => setMobileOpen(false)}
          className="font-display text-xl font-extrabold tracking-[0.16em] text-white hover:text-[#FF1744] transition-colors whitespace-nowrap shrink-0"
        >
          {site.home.brandName}
        </Link>

        {/* Zone 2: Desktop navigation links with animated active indicator */}
        <nav aria-label="Primary Navigation" className="hidden lg:flex items-center gap-1 xl:gap-2">
          {visibleNav.map((item) => {
            const active = isRouteActive(item.path);
            return (
              <Link
                key={item.id}
                to={item.path}
                aria-current={active ? 'page' : undefined}
                className={`relative px-2.5 xl:px-3 py-2 text-[13px] font-medium transition-colors whitespace-nowrap shrink-0 ${
                  active ? 'text-white' : 'text-zinc-400 hover:text-white'
                }`}
              >
                {item.label}
                {active && (
                  <motion.span
                    layoutId="active-nav-indicator"
                    transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                    className="absolute inset-x-2.5 bottom-0.5 h-[2px] rounded-full bg-[#FF1744] shadow-[0_0_12px_rgba(255,23,68,0.85)]"
                  />
                )}
              </Link>
            );
          })}
        </nav>

        {/* Zone 3: Sound control + Mobile Menu Trigger */}
        <div className="flex items-center gap-2 shrink-0">
          {site.music.enabled && (
            <button
              type="button"
              onClick={() => {
                if (autoplayBlocked && !isPlaying) {
                  void enableAudio();
                } else {
                  toggleMute();
                }
              }}
              aria-label={isMuted || autoplayBlocked ? 'Enable studio audio' : 'Mute studio audio'}
              title={autoplayBlocked ? 'Tap to enable studio music' : isMuted ? 'Unmute audio' : 'Mute audio'}
              className="inline-flex h-10 items-center gap-1.5 rounded-lg border border-white/10 bg-white/[0.03] px-3 text-xs font-medium text-zinc-200 hover:border-[#FF1744]/50 hover:text-white transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              {isMuted || autoplayBlocked || !isPlaying ? (
                <>
                  <VolumeX className="w-4 h-4 text-[#FF1744]" aria-hidden="true" />
                  <span className="hidden sm:inline">{autoplayBlocked ? 'Play Audio' : 'Muted'}</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-4 h-4 text-[#FF1744]" aria-hidden="true" />
                  <span className="hidden sm:inline">Audio On</span>
                </>
              )}
            </button>
          )}

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-expanded={mobileOpen}
            aria-controls="mobile-navigation-drawer"
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            className="inline-flex h-11 w-11 items-center justify-center rounded-lg border border-white/10 bg-white/[0.03] text-white hover:border-[#FF1744]/50 lg:hidden cursor-pointer"
          >
            {mobileOpen ? <X className="w-5 h-5" aria-hidden="true" /> : <Menu className="w-5 h-5" aria-hidden="true" />}
          </button>
        </div>
      </div>

      {/* Responsive Mobile Navigation Drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.nav
            id="mobile-navigation-drawer"
            aria-label="Mobile Navigation"
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="border-t border-white/10 bg-[#08080a]/95 backdrop-blur-2xl lg:hidden"
          >
            <div className="mx-auto max-w-7xl px-4 py-4 grid grid-cols-2 gap-2">
              {visibleNav.map((item) => {
                const active = isRouteActive(item.path);
                return (
                  <Link
                    key={item.id}
                    to={item.path}
                    onClick={() => setMobileOpen(false)}
                    aria-current={active ? 'page' : undefined}
                    className={`flex items-center justify-between rounded-lg px-4 py-3 text-sm font-medium transition-colors ${
                      active
                        ? 'bg-[#FF1744]/15 text-white border border-[#FF1744]/40'
                        : 'text-zinc-300 hover:bg-white/[0.04] hover:text-white border border-transparent'
                    }`}
                  >
                    <span>{item.label}</span>
                  </Link>
                );
              })}
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
};
