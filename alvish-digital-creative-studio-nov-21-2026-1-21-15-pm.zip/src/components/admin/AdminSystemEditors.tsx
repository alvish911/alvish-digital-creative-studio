import React, { useRef, useState } from 'react';
import { ArrowDown, ArrowUp, Check, Copy, Download, Shield, Trash2, Upload } from 'lucide-react';
import type {
  ContactEnquiry,
  MediaFileItem,
  SecurityEvent,
  SiteContent,
} from '../../shared/types';
import {
  FieldInput,
  FieldTextarea,
  FieldToggle,
  MediaUploadField,
  SectionHeader,
} from './AdminFieldKit';
import { SafeImage } from '../SafeImage';

interface SystemEditorProps {
  section:
    | 'contact'
    | 'social'
    | 'media'
    | 'intro'
    | 'music'
    | 'theme'
    | 'navigation'
    | 'seo'
    | 'backup'
    | 'security';
  draft: SiteContent;
  onChange: (next: SiteContent) => void;
  enquiries: ContactEnquiry[];
  media: MediaFileItem[];
  securityEvents: SecurityEvent[];
  envManagedAuth: boolean;
  onUploadFile: (file: File) => Promise<MediaFileItem | null>;
  onDeleteMedia: (id: string) => Promise<void>;
  onUpdateEnquiryStatus: (id: string, status: ContactEnquiry['status']) => Promise<void>;
  onDeleteEnquiry: (id: string) => Promise<void>;
  onDownloadBackup: () => Promise<void>;
  onRestoreBackup: (jsonText: string) => Promise<{ ok: boolean; message: string }>;
  onChangePassword: (currentPassword: string, newPassword: string) => Promise<{ ok: boolean; message: string }>;
}

export const AdminSystemEditors: React.FC<SystemEditorProps> = ({
  section,
  draft,
  onChange,
  enquiries,
  media,
  securityEvents,
  envManagedAuth,
  onUploadFile,
  onDeleteMedia,
  onUpdateEnquiryStatus,
  onDeleteEnquiry,
  onDownloadBackup,
  onRestoreBackup,
  onChangePassword,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [restoreFeedback, setRestoreFeedback] = useState<{ ok: boolean; message: string } | null>(null);
  const [pwForm, setPwForm] = useState({ current: '', next: '', confirm: '' });
  const [pwFeedback, setPwFeedback] = useState<{ ok: boolean; message: string } | null>(null);
  const mediaInputRef = useRef<HTMLInputElement | null>(null);
  const restoreInputRef = useRef<HTMLInputElement | null>(null);

  if (section === 'contact') {
    const c = draft.contact;
    const updateContact = (patch: Partial<SiteContent['contact']>) =>
      onChange({ ...draft, contact: { ...c, ...patch } });

    return (
      <div>
        <SectionHeader
          title="Contact Details & Enquiry Inbox"
          subtitle="Update public studio WhatsApp, Instagram, email, and manage submitted contact enquiries."
        />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldInput label="Studio Name" value={c.studioName} onChange={(v) => updateContact({ studioName: v })} />
          <FieldInput label="Sub Name" value={c.subName} onChange={(v) => updateContact({ subName: v })} />
          <FieldInput label="WhatsApp Number" value={c.whatsappNumber} onChange={(v) => updateContact({ whatsappNumber: v })} />
          <FieldInput label="WhatsApp Display" value={c.whatsappDisplay} onChange={(v) => updateContact({ whatsappDisplay: v })} />
          <FieldInput label="WhatsApp URL" value={c.whatsappLink} onChange={(v) => updateContact({ whatsappLink: v })} />
          <FieldInput label="Instagram Handle" value={c.instagramHandle} onChange={(v) => updateContact({ instagramHandle: v })} />
          <FieldInput label="Instagram URL" value={c.instagramUrl} onChange={(v) => updateContact({ instagramUrl: v })} />
          <FieldInput label="Email Address" value={c.email} onChange={(v) => updateContact({ email: v })} />
          <FieldInput label="Location" value={c.location} onChange={(v) => updateContact({ location: v })} />
          <FieldInput label="Availability Note" value={c.availabilityText} onChange={(v) => updateContact({ availabilityText: v })} />
        </div>

        <div className="mt-10 border-t border-white/[0.08] pt-6">
          <h3 className="font-display text-lg font-bold text-white">
            Submitted Contact Enquiries ({enquiries.length})
          </h3>
          {enquiries.length === 0 ? (
            <p className="mt-3 text-sm text-zinc-500">
              No enquiries received yet. Messages sent via /contact will appear here.
            </p>
          ) : (
            <div className="mt-4 space-y-3">
              {enquiries.map((enq) => (
                <div key={enq.id} className="rounded-xl border border-white/10 bg-[#0d0d10] p-5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <span className="font-display text-base font-bold text-white">{enq.name}</span>
                      <span className="ml-2 text-xs text-zinc-400">
                        {enq.phone} · {enq.email}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <select
                        aria-label={`Status for enquiry from ${enq.name}`}
                        value={enq.status}
                        onChange={(e) =>
                          void onUpdateEnquiryStatus(enq.id, e.target.value as ContactEnquiry['status'])
                        }
                        className="rounded-md border border-white/15 bg-[#09090b] px-2.5 py-1 text-xs text-white"
                      >
                        <option value="new">New</option>
                        <option value="read">Read</option>
                        <option value="replied">Replied</option>
                      </select>
                      <button
                        type="button"
                        onClick={() => void onDeleteEnquiry(enq.id)}
                        aria-label={`Delete enquiry from ${enq.name}`}
                        className="rounded-md border border-white/12 p-1.5 text-zinc-400 hover:text-[#FF1744] cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                      </button>
                    </div>
                  </div>
                  <p className="mt-3 text-sm text-zinc-300 leading-relaxed">{enq.message}</p>
                  <p className="mt-2 font-mono-tabular text-[11px] text-zinc-500">
                    Received: {new Date(enq.createdAt).toLocaleString()}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  if (section === 'social') {
    const s = draft.socialLinks;
    const updateSocial = (patch: Partial<SiteContent['socialLinks']>) =>
      onChange({ ...draft, socialLinks: { ...s, ...patch } });

    return (
      <div>
        <SectionHeader
          title="Social Media Links"
          subtitle="Manage official studio profiles across WhatsApp, Instagram, YouTube, LinkedIn, Behance, and X."
        />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldInput label="WhatsApp URL" value={s.whatsapp} onChange={(v) => updateSocial({ whatsapp: v })} />
          <FieldInput label="Instagram URL" value={s.instagram} onChange={(v) => updateSocial({ instagram: v })} />
          <FieldInput label="YouTube Channel URL" value={s.youtube} onChange={(v) => updateSocial({ youtube: v })} placeholder="https://youtube.com/..." />
          <FieldInput label="LinkedIn URL" value={s.linkedin} onChange={(v) => updateSocial({ linkedin: v })} placeholder="https://linkedin.com/in/..." />
          <FieldInput label="Behance URL" value={s.behance} onChange={(v) => updateSocial({ behance: v })} placeholder="https://behance.net/..." />
          <FieldInput label="X / Twitter URL" value={s.x} onChange={(v) => updateSocial({ x: v })} placeholder="https://x.com/..." />
        </div>
      </div>
    );
  }

  if (section === 'media') {
    return (
      <div>
        <SectionHeader
          title="Images & Media Library"
          subtitle="Upload validated images (PNG, JPEG, WebP), audio (WAV, MP3), or video (MP4) assets to use across your studio."
          action={
            <>
              <input
                ref={mediaInputRef}
                type="file"
                accept="image/png,image/jpeg,image/webp,audio/wav,audio/mpeg,video/mp4"
                className="hidden"
                onChange={async (e) => {
                  const file = e.target.files?.[0];
                  if (file) await onUploadFile(file);
                  e.target.value = '';
                }}
              />
              <button
                type="button"
                onClick={() => mediaInputRef.current?.click()}
                className="crimson-glow-btn inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold text-white cursor-pointer"
              >
                <Upload className="w-4 h-4" aria-hidden="true" />
                <span>Upload Media File</span>
              </button>
            </>
          }
        />

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {media.map((item) => (
            <div key={item.id} className="rounded-xl border border-white/10 bg-[#0d0d10] overflow-hidden">
              {item.mimeType.startsWith('image/') ? (
                <div className="h-36 w-full bg-black">
                  <SafeImage src={item.url} alt={item.fileName} className="h-full w-full object-cover" />
                </div>
              ) : (
                <div className="h-36 w-full bg-[#120b0d] flex flex-col items-center justify-center p-4 text-center">
                  <span className="font-mono-tabular text-xs text-[#FF1744]">{item.mimeType}</span>
                  <span className="mt-1 text-xs text-zinc-300 truncate max-w-full">{item.fileName}</span>
                </div>
              )}
              <div className="p-4">
                <p className="text-xs font-semibold text-white truncate">{item.fileName}</p>
                <p className="mt-1 font-mono-tabular text-[11px] text-zinc-500 truncate">{item.url}</p>
                <div className="mt-3 flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard?.writeText(item.url).catch(() => {});
                      setCopiedId(item.id);
                      setTimeout(() => setCopiedId(null), 1500);
                    }}
                    className="inline-flex items-center gap-1 rounded border border-white/12 px-2.5 py-1 text-[11px] text-zinc-200 hover:border-[#FF1744] cursor-pointer"
                  >
                    {copiedId === item.id ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedId === item.id ? 'Copied' : 'Copy URL'}</span>
                  </button>
                  {item.url.startsWith('/uploads/') && (
                    <button
                      type="button"
                      onClick={() => void onDeleteMedia(item.id)}
                      aria-label={`Delete media ${item.fileName}`}
                      className="inline-flex items-center gap-1 rounded border border-white/12 px-2 py-1 text-[11px] text-zinc-400 hover:text-[#FF1744] cursor-pointer"
                    >
                      <Trash2 className="w-3 h-3" aria-hidden="true" />
                      <span>Delete</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (section === 'intro') {
    const intro = draft.intro;
    const updateIntro = (patch: Partial<SiteContent['intro']>) =>
      onChange({ ...draft, intro: { ...intro, ...patch } });

    return (
      <div>
        <SectionHeader
          title="Intro Animation Settings"
          subtitle="Configure the cinematic opening animation, reveal tagline, duration, and skip button."
        />
        <div className="space-y-4">
          <FieldToggle
            label="Enable Cinematic Intro Animation"
            hint="Displays the glowing ALVISH studio reveal on first visit."
            checked={intro.enabled}
            onChange={(v) => updateIntro({ enabled: v })}
          />
          <FieldInput
            label="Post-Intro Reveal Text"
            value={intro.tagline}
            onChange={(v) => updateIntro({ tagline: v })}
          />
          <label className="block">
            <span className="block text-xs font-semibold text-zinc-300">
              Intro Duration ({intro.durationMs} ms)
            </span>
            <input
              type="range"
              min={2600}
              max={7000}
              step={200}
              value={intro.durationMs}
              onChange={(e) => updateIntro({ durationMs: Number(e.target.value) })}
              className="mt-2 w-full accent-[#FF1744]"
            />
          </label>
          <FieldToggle
            label="Show Crimson Particles During Intro"
            checked={intro.showParticles}
            onChange={(v) => updateIntro({ showParticles: v })}
          />
          <FieldToggle
            label="Show Enter Studio / Skip Button"
            checked={intro.skipButtonVisible}
            onChange={(v) => updateIntro({ skipButtonVisible: v })}
          />
        </div>
      </div>
    );
  }

  if (section === 'music') {
    const m = draft.music;
    const updateMusic = (patch: Partial<SiteContent['music']>) =>
      onChange({ ...draft, music: { ...m, ...patch } });

    return (
      <div>
        <SectionHeader
          title="Music Settings"
          subtitle="Manage the intro soundtrack, upload a custom WAV or MP3 track, and configure playback volume."
        />
        <div className="space-y-4">
          <FieldToggle
            label="Enable Studio Intro Music"
            checked={m.enabled}
            onChange={(v) => updateMusic({ enabled: v })}
          />
          <FieldInput
            label="Track Title"
            value={m.trackTitle}
            onChange={(v) => updateMusic({ trackTitle: v })}
          />
          <MediaUploadField
            label="Intro Audio File URL (WAV / MP3)"
            value={m.trackUrl}
            onChange={(v) => updateMusic({ trackUrl: v })}
            onUploadFile={onUploadFile}
            accept="audio/wav,audio/mpeg"
            placeholder="/assets/alvish-intro.wav"
          />
          <label className="block">
            <span className="block text-xs font-semibold text-zinc-300">
              Default Volume ({Math.round(m.defaultVolume * 100)}%)
            </span>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={m.defaultVolume}
              onChange={(e) => updateMusic({ defaultVolume: Number(e.target.value) })}
              className="mt-2 w-full accent-[#FF1744]"
            />
          </label>
          <FieldToggle
            label="Attempt Autoplay on Website Open"
            hint="Displays a visible Sound-On tap fallback whenever browser policies block autoplay."
            checked={m.attemptAutoplay}
            onChange={(v) => updateMusic({ attemptAutoplay: v })}
          />
          <FieldToggle
            label="Loop Soundtrack After Finishing"
            hint="Keep disabled to play once for the duration of the supplied intro track."
            checked={m.loop}
            onChange={(v) => updateMusic({ loop: v })}
          />
        </div>
      </div>
    );
  }

  if (section === 'theme') {
    const t = draft.theme;
    const updateTheme = (patch: Partial<SiteContent['theme']>) =>
      onChange({ ...draft, theme: { ...t, ...patch } });

    return (
      <div>
        <SectionHeader
          title="Website Theme Settings"
          subtitle="Customize the studio palette, glass blur intensity, particles, animations, and section visibility."
        />
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
          {[
            { key: 'backgroundColor', label: 'Background' },
            { key: 'surfaceColor', label: 'Surface' },
            { key: 'accentColor', label: 'Primary Red' },
            { key: 'deepAccentColor', label: 'Deep Red' },
            { key: 'textColor', label: 'Text White' },
          ].map((c) => (
            <label key={c.key} className="rounded-xl border border-white/10 bg-[#0d0d10] p-3.5 block">
              <span className="block text-xs font-semibold text-zinc-300">{c.label}</span>
              <div className="mt-2 flex items-center gap-2">
                <input
                  type="color"
                  value={(t as unknown as Record<string, string>)[c.key]}
                  onChange={(e) => updateTheme({ [c.key]: e.target.value } as Partial<SiteContent['theme']>)}
                  className="h-8 w-10 rounded bg-transparent cursor-pointer"
                />
                <span className="font-mono-tabular text-xs text-zinc-400">
                  {(t as unknown as Record<string, string>)[c.key]}
                </span>
              </div>
            </label>
          ))}
        </div>

        <div className="mt-6 space-y-4">
          <label className="block">
            <span className="block text-xs font-semibold text-zinc-300">
              Glassmorphism Backdrop Blur ({t.glassBlurPx}px)
            </span>
            <input
              type="range"
              min={4}
              max={32}
              value={t.glassBlurPx}
              onChange={(e) => updateTheme({ glassBlurPx: Number(e.target.value) })}
              className="mt-2 w-full accent-[#FF1744]"
            />
          </label>
          <FieldToggle
            label="Enable Ambient Red Particles"
            checked={t.enableParticles}
            onChange={(v) => updateTheme({ enableParticles: v })}
          />
          <FieldToggle
            label="Enable Page & Motion Transitions"
            checked={t.enableAnimations}
            onChange={(v) => updateTheme({ enableAnimations: v })}
          />
          <div className="border-t border-white/[0.08] pt-5 space-y-3">
            <h3 className="font-display text-sm font-bold text-white">Section Visibility Controls</h3>
            <FieldToggle
              label="Show Featured Projects on Home"
              checked={t.sectionVisibility.featuredWork}
              onChange={(v) =>
                updateTheme({ sectionVisibility: { ...t.sectionVisibility, featuredWork: v } })
              }
            />
            <FieldToggle
              label="Show Website Design Pricing Packages"
              checked={t.sectionVisibility.pricingPackages}
              onChange={(v) =>
                updateTheme({ sectionVisibility: { ...t.sectionVisibility, pricingPackages: v } })
              }
            />
          </div>
        </div>
      </div>
    );
  }

  if (section === 'navigation') {
    const sorted = [...draft.navigation].sort((a, b) => a.order - b.order);

    const moveNav = (idx: number, dir: -1 | 1) => {
      const target = idx + dir;
      if (target < 0 || target >= sorted.length) return;
      const copy = [...sorted];
      const [item] = copy.splice(idx, 1);
      copy.splice(target, 0, item);
      onChange({
        ...draft,
        navigation: copy.map((n, i) => ({ ...n, order: i + 1 })),
      });
    };

    return (
      <div>
        <SectionHeader
          title="Navigation Management"
          subtitle="Rename, hide/show, or reorder navigation menu items across the header and footer."
        />
        <div className="space-y-3">
          {sorted.map((item, idx) => (
            <div
              key={item.id}
              className="rounded-xl border border-white/10 bg-[#0d0d10] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-3">
                <FieldInput
                  label="Label"
                  value={item.label}
                  onChange={(v) => {
                    const copy = [...sorted];
                    copy[idx] = { ...item, label: v };
                    onChange({ ...draft, navigation: copy });
                  }}
                />
                <FieldInput
                  label="URL Path"
                  value={item.path}
                  onChange={(v) => {
                    const copy = [...sorted];
                    copy[idx] = { ...item, path: v };
                    onChange({ ...draft, navigation: copy });
                  }}
                />
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <label className="inline-flex items-center gap-2 text-xs text-zinc-300 mr-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={item.visible}
                    onChange={(e) => {
                      const copy = [...sorted];
                      copy[idx] = { ...item, visible: e.target.checked };
                      onChange({ ...draft, navigation: copy });
                    }}
                    className="accent-[#FF1744]"
                  />
                  <span>Visible</span>
                </label>
                <button
                  type="button"
                  disabled={idx === 0}
                  onClick={() => moveNav(idx, -1)}
                  aria-label={`Move ${item.label} up`}
                  className="rounded border border-white/12 p-1.5 text-zinc-300 hover:border-[#FF1744] disabled:opacity-30 cursor-pointer"
                >
                  <ArrowUp className="w-3.5 h-3.5" aria-hidden="true" />
                </button>
                <button
                  type="button"
                  disabled={idx === sorted.length - 1}
                  onClick={() => moveNav(idx, 1)}
                  aria-label={`Move ${item.label} down`}
                  className="rounded border border-white/12 p-1.5 text-zinc-300 hover:border-[#FF1744] disabled:opacity-30 cursor-pointer"
                >
                  <ArrowDown className="w-3.5 h-3.5" aria-hidden="true" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (section === 'seo') {
    const seo = draft.seo;
    const updateSeo = (patch: Partial<SiteContent['seo']>) =>
      onChange({ ...draft, seo: { ...seo, ...patch } });

    return (
      <div>
        <SectionHeader
          title="SEO Settings"
          subtitle="Configure global page title, search description, keywords, and Open Graph share image."
        />
        <div className="space-y-4">
          <FieldInput label="Default Site Title" value={seo.siteTitle} onChange={(v) => updateSeo({ siteTitle: v })} />
          <FieldTextarea label="Meta Description" value={seo.metaDescription} onChange={(v) => updateSeo({ metaDescription: v })} rows={3} />
          <FieldInput label="Keywords" value={seo.keywords} onChange={(v) => updateSeo({ keywords: v })} />
          <MediaUploadField
            label="Open Graph Social Share Image"
            value={seo.ogImageUrl}
            onChange={(v) => updateSeo({ ogImageUrl: v })}
            onUploadFile={onUploadFile}
          />
        </div>
      </div>
    );
  }

  if (section === 'backup') {
    return (
      <div>
        <SectionHeader
          title="Backup and Restore"
          subtitle="Export a complete JSON snapshot of your website content, enquiries, and media metadata, or restore from a saved backup."
        />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="rounded-xl border border-white/10 bg-[#0d0d10] p-6">
            <h3 className="font-display text-lg font-bold text-white">Export Live Backup</h3>
            <p className="mt-2 text-sm text-zinc-400">
              Downloads a validated JSON snapshot containing all 20 CMS sections, portfolio items, pricing, reviews, and enquiries.
            </p>
            <button
              type="button"
              onClick={() => void onDownloadBackup()}
              className="crimson-glow-btn mt-5 inline-flex items-center gap-2 rounded-lg px-5 py-2.5 text-xs font-semibold text-white cursor-pointer"
            >
              <Download className="w-4 h-4" aria-hidden="true" />
              <span>Download JSON Backup</span>
            </button>
          </div>

          <div className="rounded-xl border border-white/10 bg-[#0d0d10] p-6">
            <h3 className="font-display text-lg font-bold text-white">Restore from Backup</h3>
            <p className="mt-2 text-sm text-zinc-400">
              Upload a previously exported <code className="text-zinc-200">alvish-studio-backup.json</code> file. Payloads are validated before restoring.
            </p>
            <input
              ref={restoreInputRef}
              type="file"
              accept="application/json,.json"
              className="hidden"
              onChange={async (e) => {
                const file = e.target.files?.[0];
                if (!file) return;
                const text = await file.text();
                const res = await onRestoreBackup(text);
                setRestoreFeedback(res);
                e.target.value = '';
              }}
            />
            <button
              type="button"
              onClick={() => restoreInputRef.current?.click()}
              className="mt-5 inline-flex items-center gap-2 rounded-lg border border-white/15 bg-white/[0.04] px-5 py-2.5 text-xs font-semibold text-white hover:border-[#FF1744] cursor-pointer"
            >
              <Upload className="w-4 h-4 text-[#FF1744]" aria-hidden="true" />
              <span>Select Backup File &amp; Restore</span>
            </button>
            {restoreFeedback && (
              <p
                className={`mt-3 text-xs ${
                  restoreFeedback.ok ? 'text-emerald-400' : 'text-[#FF1744]'
                }`}
              >
                {restoreFeedback.message}
              </p>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Security Settings
  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPwFeedback(null);
    if (pwForm.next !== pwForm.confirm) {
      setPwFeedback({ ok: false, message: 'New passwords do not match.' });
      return;
    }
    const res = await onChangePassword(pwForm.current, pwForm.next);
    setPwFeedback(res);
    if (res.ok) {
      setPwForm({ current: '', next: '', confirm: '' });
    }
  };

  return (
    <div>
      <SectionHeader
        title="Security Settings"
        subtitle="Manage admin credentials, review authentication safeguards, and audit recent security events."
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="rounded-xl border border-white/10 bg-[#0d0d10] p-6">
          <div className="flex items-center gap-2.5">
            <Shield className="w-5 h-5 text-[#FF1744]" aria-hidden="true" />
            <h3 className="font-display text-lg font-bold text-white">Change Admin Password</h3>
          </div>

          {envManagedAuth ? (
            <p className="mt-3 text-sm text-zinc-400">
              Admin authentication is currently controlled by the server <code className="text-zinc-200">ADMIN_PASSWORD</code> environment secret. Update it in your hosting Secrets panel to rotate credentials.
            </p>
          ) : (
            <form onSubmit={handlePasswordSubmit} className="mt-4 space-y-4">
              <FieldInput
                label="Current Password"
                type="password"
                value={pwForm.current}
                onChange={(v) => setPwForm((p) => ({ ...p, current: v }))}
              />
              <FieldInput
                label="New Password (min 8 chars, letters + numbers)"
                type="password"
                value={pwForm.next}
                onChange={(v) => setPwForm((p) => ({ ...p, next: v }))}
              />
              <FieldInput
                label="Confirm New Password"
                type="password"
                value={pwForm.confirm}
                onChange={(v) => setPwForm((p) => ({ ...p, confirm: v }))}
              />
              {pwFeedback && (
                <p className={`text-xs ${pwFeedback.ok ? 'text-emerald-400' : 'text-[#FF1744]'}`}>
                  {pwFeedback.message}
                </p>
              )}
              <button
                type="submit"
                className="crimson-glow-btn rounded-lg px-5 py-2.5 text-xs font-semibold text-white cursor-pointer"
              >
                Update Admin Password
              </button>
            </form>
          )}
        </div>

        <div className="rounded-xl border border-white/10 bg-[#0d0d10] p-6">
          <h3 className="font-display text-lg font-bold text-white">Recent Security Activity</h3>
          {securityEvents.length === 0 ? (
            <p className="mt-3 text-sm text-zinc-500">No security events logged yet.</p>
          ) : (
            <ul className="mt-4 space-y-2.5 max-h-72 overflow-y-auto pr-1">
              {securityEvents.slice(0, 12).map((ev) => (
                <li key={ev.id} className="rounded-lg border border-white/[0.06] bg-white/[0.02] px-3.5 py-2.5 text-xs">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-white">{ev.action}</span>
                    <span className="font-mono-tabular text-[11px] text-zinc-500">
                      {new Date(ev.timestamp).toLocaleString()}
                    </span>
                  </div>
                  <p className="mt-1 text-zinc-400">
                    {ev.actor} — {ev.detail}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
};
