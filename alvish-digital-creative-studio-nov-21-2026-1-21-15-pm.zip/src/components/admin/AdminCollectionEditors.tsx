import React from 'react';
import { ArrowDown, ArrowUp, Plus, Trash2 } from 'lucide-react';
import {
  PORTFOLIO_CATEGORIES,
  type AchievementItem,
  type ExperienceItem,
  type MediaFileItem,
  type PortfolioCategory,
  type PortfolioProject,
  type SiteContent,
  type SkillItem,
  type TestimonialItem,
} from '../../shared/types';
import { clampPercentage } from '../../shared/validation';
import {
  FieldInput,
  FieldTextarea,
  FieldToggle,
  MediaUploadField,
  SectionHeader,
} from './AdminFieldKit';

interface CollectionEditorProps {
  section: 'skills' | 'experience' | 'portfolio' | 'achievements' | 'testimonials';
  draft: SiteContent;
  onChange: (next: SiteContent) => void;
  onUploadFile: (file: File) => Promise<MediaFileItem | null>;
}

export const AdminCollectionEditors: React.FC<CollectionEditorProps> = ({
  section,
  draft,
  onChange,
  onUploadFile,
}) => {
  if (section === 'skills') {
    const addSkill = () => {
      const next: SkillItem = {
        id: `sk-${Date.now()}`,
        name: 'New Creative Skill',
        category: 'Creative Design',
        percentage: 85,
        description: 'Describe your capability in this area.',
      };
      onChange({ ...draft, skills: [...draft.skills, next] });
    };

    return (
      <div>
        <SectionHeader
          title="Skills Management"
          subtitle="Add, edit, or delete skills, categories, and percentage proficiency levels."
          action={
            <button
              type="button"
              onClick={addSkill}
              className="crimson-glow-btn inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold text-white cursor-pointer"
            >
              <Plus className="w-4 h-4" aria-hidden="true" />
              <span>Add Skill</span>
            </button>
          }
        />

        <div className="space-y-4">
          {draft.skills.map((skill, idx) => (
            <div key={skill.id} className="rounded-xl border border-white/10 bg-[#0d0d10] p-5 space-y-4">
              <div className="flex items-center justify-between gap-2">
                <span className="font-display text-sm font-bold text-white">
                  {skill.name} ({skill.percentage}%)
                </span>
                <button
                  type="button"
                  onClick={() =>
                    onChange({ ...draft, skills: draft.skills.filter((_, i) => i !== idx) })
                  }
                  aria-label={`Delete skill ${skill.name}`}
                  className="inline-flex items-center gap-1 text-xs text-zinc-400 hover:text-[#FF1744] cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" aria-hidden="true" />
                  <span>Delete</span>
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <FieldInput
                  label="Skill Name"
                  value={skill.name}
                  onChange={(v) => {
                    const list = [...draft.skills];
                    list[idx] = { ...skill, name: v };
                    onChange({ ...draft, skills: list });
                  }}
                />
                <FieldInput
                  label="Category"
                  value={skill.category}
                  onChange={(v) => {
                    const list = [...draft.skills];
                    list[idx] = { ...skill, category: v };
                    onChange({ ...draft, skills: list });
                  }}
                />
                <label className="block">
                  <span className="block text-xs font-semibold text-zinc-300">
                    Percentage ({skill.percentage}%)
                  </span>
                  <input
                    type="number"
                    min={0}
                    max={100}
                    value={skill.percentage}
                    onChange={(e) => {
                      const list = [...draft.skills];
                      list[idx] = { ...skill, percentage: clampPercentage(Number(e.target.value)) };
                      onChange({ ...draft, skills: list });
                    }}
                    className="mt-1.5 w-full rounded-lg border border-white/12 bg-[#0a0a0c] px-3.5 py-2.5 text-sm font-mono-tabular text-white focus:border-[#FF1744] focus:outline-none"
                  />
                </label>
              </div>
              <FieldInput
                label="Description"
                value={skill.description}
                onChange={(v) => {
                  const list = [...draft.skills];
                  list[idx] = { ...skill, description: v };
                  onChange({ ...draft, skills: list });
                }}
              />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (section === 'experience') {
    const addExperience = () => {
      const next: ExperienceItem = {
        id: `exp-${Date.now()}`,
        title: 'Role or Project Lead',
        companyOrProject: 'Studio / Client Name',
        description: 'Key responsibilities and outcomes delivered.',
        startDate: '2025',
        endDate: 'Present',
        highlights: ['Deliverable highlight'],
      };
      onChange({ ...draft, experience: [next, ...draft.experience] });
    };

    return (
      <div>
        <SectionHeader
          title="Experience Management"
          subtitle="Manage your professional timeline, roles, projects, dates, and highlights."
          action={
            <button
              type="button"
              onClick={addExperience}
              className="crimson-glow-btn inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold text-white cursor-pointer"
            >
              <Plus className="w-4 h-4" aria-hidden="true" />
              <span>Add Experience</span>
            </button>
          }
        />

        <div className="space-y-5">
          {draft.experience.map((exp, idx) => (
            <div key={exp.id} className="rounded-xl border border-white/10 bg-[#0d0d10] p-5 space-y-4">
              <div className="flex items-center justify-between gap-2">
                <span className="font-display text-base font-bold text-white">{exp.title}</span>
                <button
                  type="button"
                  onClick={() =>
                    onChange({
                      ...draft,
                      experience: draft.experience.filter((_, i) => i !== idx),
                    })
                  }
                  aria-label={`Delete experience ${exp.title}`}
                  className="inline-flex items-center gap-1 text-xs text-zinc-400 hover:text-[#FF1744] cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" aria-hidden="true" />
                  <span>Delete</span>
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FieldInput
                  label="Experience Title"
                  value={exp.title}
                  onChange={(v) => {
                    const list = [...draft.experience];
                    list[idx] = { ...exp, title: v };
                    onChange({ ...draft, experience: list });
                  }}
                />
                <FieldInput
                  label="Company or Project Name"
                  value={exp.companyOrProject}
                  onChange={(v) => {
                    const list = [...draft.experience];
                    list[idx] = { ...exp, companyOrProject: v };
                    onChange({ ...draft, experience: list });
                  }}
                />
                <FieldInput
                  label="Start Date"
                  value={exp.startDate}
                  onChange={(v) => {
                    const list = [...draft.experience];
                    list[idx] = { ...exp, startDate: v };
                    onChange({ ...draft, experience: list });
                  }}
                />
                <FieldInput
                  label="End Date"
                  value={exp.endDate}
                  onChange={(v) => {
                    const list = [...draft.experience];
                    list[idx] = { ...exp, endDate: v };
                    onChange({ ...draft, experience: list });
                  }}
                />
              </div>
              <FieldTextarea
                label="Description"
                value={exp.description}
                onChange={(v) => {
                  const list = [...draft.experience];
                  list[idx] = { ...exp, description: v };
                  onChange({ ...draft, experience: list });
                }}
              />
              <FieldTextarea
                label="Key Highlights (one per line)"
                value={exp.highlights.join('\n')}
                onChange={(v) => {
                  const list = [...draft.experience];
                  list[idx] = {
                    ...exp,
                    highlights: v
                      .split('\n')
                      .map((l) => l.trim())
                      .filter(Boolean),
                  };
                  onChange({ ...draft, experience: list });
                }}
              />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (section === 'portfolio') {
    const sorted = [...draft.portfolio].sort((a, b) => a.order - b.order);

    const addProject = () => {
      const next: PortfolioProject = {
        id: `pf-${Date.now()}`,
        title: 'New Studio Project',
        category: 'Website Designs',
        clientName: 'Client Name',
        year: String(new Date().getFullYear()),
        summary: 'Concise overview of the deliverable.',
        details: 'Full creative direction, process, and outcome.',
        imageUrl: draft.portfolio[0]?.imageUrl || '',
        metrics: 'Custom Studio Build',
        featured: false,
        published: true,
        order: sorted.length + 1,
      };
      onChange({ ...draft, portfolio: [next, ...sorted].map((p, i) => ({ ...p, order: i + 1 })) });
    };

    const moveProject = (idx: number, dir: -1 | 1) => {
      const target = idx + dir;
      if (target < 0 || target >= sorted.length) return;
      const copy = [...sorted];
      const [item] = copy.splice(idx, 1);
      copy.splice(target, 0, item);
      onChange({
        ...draft,
        portfolio: copy.map((p, i) => ({ ...p, order: i + 1 })),
      });
    };

    const updateProject = (idx: number, patch: Partial<PortfolioProject>) => {
      const copy = [...sorted];
      copy[idx] = { ...copy[idx], ...patch };
      onChange({ ...draft, portfolio: copy });
    };

    return (
      <div>
        <SectionHeader
          title="Portfolio Management"
          subtitle="Add, edit, delete, and reorder projects across all 7 categories with image or video previews."
          action={
            <button
              type="button"
              onClick={addProject}
              className="crimson-glow-btn inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold text-white cursor-pointer"
            >
              <Plus className="w-4 h-4" aria-hidden="true" />
              <span>Add Project</span>
            </button>
          }
        />

        <div className="space-y-5">
          {sorted.map((proj, idx) => (
            <div key={proj.id} className="rounded-xl border border-white/10 bg-[#0d0d10] p-5 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="font-display text-base font-bold text-white">
                  #{idx + 1} · {proj.title}
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    disabled={idx === 0}
                    onClick={() => moveProject(idx, -1)}
                    aria-label={`Move ${proj.title} up`}
                    className="rounded border border-white/12 p-1.5 text-zinc-300 hover:border-[#FF1744] disabled:opacity-30 cursor-pointer"
                  >
                    <ArrowUp className="w-3.5 h-3.5" aria-hidden="true" />
                  </button>
                  <button
                    type="button"
                    disabled={idx === sorted.length - 1}
                    onClick={() => moveProject(idx, 1)}
                    aria-label={`Move ${proj.title} down`}
                    className="rounded border border-white/12 p-1.5 text-zinc-300 hover:border-[#FF1744] disabled:opacity-30 cursor-pointer"
                  >
                    <ArrowDown className="w-3.5 h-3.5" aria-hidden="true" />
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      onChange({
                        ...draft,
                        portfolio: sorted
                          .filter((_, i) => i !== idx)
                          .map((p, i) => ({ ...p, order: i + 1 })),
                      })
                    }
                    aria-label={`Delete project ${proj.title}`}
                    className="inline-flex items-center gap-1 rounded border border-white/12 px-2.5 py-1.5 text-xs text-zinc-400 hover:text-[#FF1744] cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Delete</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <FieldInput
                  label="Project Title"
                  value={proj.title}
                  onChange={(v) => updateProject(idx, { title: v })}
                />
                <label className="block">
                  <span className="block text-xs font-semibold text-zinc-300">Category</span>
                  <select
                    value={proj.category}
                    onChange={(e) =>
                      updateProject(idx, { category: e.target.value as PortfolioCategory })
                    }
                    className="mt-1.5 w-full rounded-lg border border-white/12 bg-[#0a0a0c] px-3 py-2.5 text-sm text-white focus:border-[#FF1744] focus:outline-none"
                  >
                    {PORTFOLIO_CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </label>
                <FieldInput
                  label="Year"
                  value={proj.year}
                  onChange={(v) => updateProject(idx, { year: v })}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FieldInput
                  label="Client Name"
                  value={proj.clientName}
                  onChange={(v) => updateProject(idx, { clientName: v })}
                />
                <FieldInput
                  label="Result / Metric Label"
                  value={proj.metrics || ''}
                  onChange={(v) => updateProject(idx, { metrics: v })}
                />
              </div>

              <MediaUploadField
                label="Cover Image"
                value={proj.imageUrl}
                onChange={(v) => updateProject(idx, { imageUrl: v })}
                onUploadFile={onUploadFile}
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <MediaUploadField
                  label="Optional Video Preview (MP4)"
                  value={proj.videoUrl || ''}
                  onChange={(v) => updateProject(idx, { videoUrl: v })}
                  onUploadFile={onUploadFile}
                  accept="video/mp4"
                  placeholder="/uploads/reel.mp4 or https://..."
                />
                <FieldInput
                  label="Optional Live Project URL"
                  value={proj.projectUrl || ''}
                  onChange={(v) => updateProject(idx, { projectUrl: v })}
                  placeholder="https://..."
                />
              </div>

              <FieldTextarea
                label="Card Summary"
                value={proj.summary}
                onChange={(v) => updateProject(idx, { summary: v })}
                rows={2}
              />
              <FieldTextarea
                label="Full Lightbox Details"
                value={proj.details}
                onChange={(v) => updateProject(idx, { details: v })}
                rows={2}
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <FieldToggle
                  label="Published on Portfolio"
                  checked={proj.published}
                  onChange={(v) => updateProject(idx, { published: v })}
                />
                <FieldToggle
                  label="Featured on Home Page"
                  checked={proj.featured}
                  onChange={(v) => updateProject(idx, { featured: v })}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (section === 'achievements') {
    const addAchievement = () => {
      const next: AchievementItem = {
        id: `ach-${Date.now()}`,
        title: 'New Certificate or Award',
        issuer: 'Issuing Organization',
        kind: 'Certificate',
        dateLabel: String(new Date().getFullYear()),
        description: 'Description of this milestone or certification.',
        imageUrl: draft.achievements[0]?.imageUrl || '',
      };
      onChange({ ...draft, achievements: [next, ...draft.achievements] });
    };

    return (
      <div>
        <SectionHeader
          title="Achievements Management"
          subtitle="Add, edit, or delete certificates, awards, and milestones with certificate image uploads."
          action={
            <button
              type="button"
              onClick={addAchievement}
              className="crimson-glow-btn inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold text-white cursor-pointer"
            >
              <Plus className="w-4 h-4" aria-hidden="true" />
              <span>Add Achievement</span>
            </button>
          }
        />

        <div className="space-y-5">
          {draft.achievements.map((ach, idx) => (
            <div key={ach.id} className="rounded-xl border border-white/10 bg-[#0d0d10] p-5 space-y-4">
              <div className="flex items-center justify-between gap-2">
                <span className="font-display text-base font-bold text-white">{ach.title}</span>
                <button
                  type="button"
                  onClick={() =>
                    onChange({
                      ...draft,
                      achievements: draft.achievements.filter((_, i) => i !== idx),
                    })
                  }
                  aria-label={`Delete achievement ${ach.title}`}
                  className="inline-flex items-center gap-1 text-xs text-zinc-400 hover:text-[#FF1744] cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" aria-hidden="true" />
                  <span>Delete</span>
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <FieldInput
                  label="Title"
                  value={ach.title}
                  onChange={(v) => {
                    const list = [...draft.achievements];
                    list[idx] = { ...ach, title: v };
                    onChange({ ...draft, achievements: list });
                  }}
                />
                <FieldInput
                  label="Issuer"
                  value={ach.issuer}
                  onChange={(v) => {
                    const list = [...draft.achievements];
                    list[idx] = { ...ach, issuer: v };
                    onChange({ ...draft, achievements: list });
                  }}
                />
                <label className="block">
                  <span className="block text-xs font-semibold text-zinc-300">Type</span>
                  <select
                    value={ach.kind}
                    onChange={(e) => {
                      const list = [...draft.achievements];
                      list[idx] = {
                        ...ach,
                        kind: e.target.value as AchievementItem['kind'],
                      };
                      onChange({ ...draft, achievements: list });
                    }}
                    className="mt-1.5 w-full rounded-lg border border-white/12 bg-[#0a0a0c] px-3 py-2.5 text-sm text-white focus:border-[#FF1744] focus:outline-none"
                  >
                    <option value="Certificate">Certificate</option>
                    <option value="Award">Award</option>
                    <option value="Milestone">Milestone</option>
                    <option value="Recognition">Recognition</option>
                  </select>
                </label>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FieldInput
                  label="Date / Year"
                  value={ach.dateLabel}
                  onChange={(v) => {
                    const list = [...draft.achievements];
                    list[idx] = { ...ach, dateLabel: v };
                    onChange({ ...draft, achievements: list });
                  }}
                />
                <FieldInput
                  label="Verification Link (optional)"
                  value={ach.credentialUrl || ''}
                  onChange={(v) => {
                    const list = [...draft.achievements];
                    list[idx] = { ...ach, credentialUrl: v };
                    onChange({ ...draft, achievements: list });
                  }}
                />
              </div>
              <MediaUploadField
                label="Certificate / Award Image"
                value={ach.imageUrl || ''}
                onChange={(v) => {
                  const list = [...draft.achievements];
                  list[idx] = { ...ach, imageUrl: v };
                  onChange({ ...draft, achievements: list });
                }}
                onUploadFile={onUploadFile}
              />
              <FieldTextarea
                label="Description"
                value={ach.description}
                onChange={(v) => {
                  const list = [...draft.achievements];
                  list[idx] = { ...ach, description: v };
                  onChange({ ...draft, achievements: list });
                }}
                rows={2}
              />
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Testimonials Management
  const addReview = () => {
    const next: TestimonialItem = {
      id: `test-${Date.now()}`,
      clientName: 'Verified Client Name',
      clientRole: 'Founder',
      clientCompany: 'Company Name',
      clientAvatarUrl: draft.home.portraitUrl,
      reviewText: 'Enter the verified client testimonial with permission.',
      rating: 5,
      isDemo: false,
      published: true,
    };
    onChange({ ...draft, testimonials: [next, ...draft.testimonials] });
  };

  return (
    <div>
      <SectionHeader
        title="Testimonials Management"
        subtitle="Add, edit, delete, upload client photos, change star ratings, toggle Demo labels, or hide/publish reviews."
        action={
          <button
            type="button"
            onClick={addReview}
            className="crimson-glow-btn inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold text-white cursor-pointer"
          >
            <Plus className="w-4 h-4" aria-hidden="true" />
            <span>Add Client Review</span>
          </button>
        }
      />

      <div className="space-y-5">
        {draft.testimonials.map((rev, idx) => (
          <div key={rev.id} className="rounded-xl border border-white/10 bg-[#0d0d10] p-5 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <span className="font-display text-base font-bold text-white">
                {rev.clientName} · {rev.rating}★
              </span>
              <button
                type="button"
                onClick={() =>
                  onChange({
                    ...draft,
                    testimonials: draft.testimonials.filter((_, i) => i !== idx),
                  })
                }
                aria-label={`Delete review by ${rev.clientName}`}
                className="inline-flex items-center gap-1 text-xs text-zinc-400 hover:text-[#FF1744] cursor-pointer"
              >
                <Trash2 className="w-4 h-4" aria-hidden="true" />
                <span>Delete</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <FieldInput
                label="Client Name"
                value={rev.clientName}
                onChange={(v) => {
                  const list = [...draft.testimonials];
                  list[idx] = { ...rev, clientName: v };
                  onChange({ ...draft, testimonials: list });
                }}
              />
              <FieldInput
                label="Role"
                value={rev.clientRole}
                onChange={(v) => {
                  const list = [...draft.testimonials];
                  list[idx] = { ...rev, clientRole: v };
                  onChange({ ...draft, testimonials: list });
                }}
              />
              <FieldInput
                label="Company / Brand"
                value={rev.clientCompany}
                onChange={(v) => {
                  const list = [...draft.testimonials];
                  list[idx] = { ...rev, clientCompany: v };
                  onChange({ ...draft, testimonials: list });
                }}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <MediaUploadField
                label="Client Profile Image"
                value={rev.clientAvatarUrl || ''}
                onChange={(v) => {
                  const list = [...draft.testimonials];
                  list[idx] = { ...rev, clientAvatarUrl: v };
                  onChange({ ...draft, testimonials: list });
                }}
                onUploadFile={onUploadFile}
              />
              <label className="block">
                <span className="block text-xs font-semibold text-zinc-300">Star Rating (1–5)</span>
                <select
                  value={rev.rating}
                  onChange={(e) => {
                    const list = [...draft.testimonials];
                    list[idx] = { ...rev, rating: Number(e.target.value) };
                    onChange({ ...draft, testimonials: list });
                  }}
                  className="mt-1.5 w-full rounded-lg border border-white/12 bg-[#0a0a0c] px-3 py-2.5 text-sm text-white focus:border-[#FF1744] focus:outline-none"
                >
                  {[5, 4, 3, 2, 1].map((r) => (
                    <option key={r} value={r}>
                      {r} Stars
                    </option>
                  ))}
                </select>
              </label>
            </div>

            <FieldTextarea
              label="Client Review Text"
              value={rev.reviewText}
              onChange={(v) => {
                const list = [...draft.testimonials];
                list[idx] = { ...rev, reviewText: v };
                onChange({ ...draft, testimonials: list });
              }}
              rows={3}
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <FieldToggle
                label="Published on Website"
                checked={rev.published}
                onChange={(v) => {
                  const list = [...draft.testimonials];
                  list[idx] = { ...rev, published: v };
                  onChange({ ...draft, testimonials: list });
                }}
              />
              <FieldToggle
                label="Label as Demo Content"
                hint="Turn off once replaced with a genuine verified client review."
                checked={rev.isDemo}
                onChange={(v) => {
                  const list = [...draft.testimonials];
                  list[idx] = { ...rev, isDemo: v };
                  onChange({ ...draft, testimonials: list });
                }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
