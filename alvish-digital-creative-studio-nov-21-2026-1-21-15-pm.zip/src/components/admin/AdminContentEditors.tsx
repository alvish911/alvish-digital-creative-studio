import React from 'react';
import { Plus, Trash2 } from 'lucide-react';
import type {
  ContactEnquiry,
  MediaFileItem,
  PricingPackage,
  ServiceItem,
  SiteContent,
} from '../../shared/types';
import {
  FieldInput,
  FieldTextarea,
  FieldToggle,
  MediaUploadField,
  SectionHeader,
} from './AdminFieldKit';

interface ContentEditorProps {
  section: 'overview' | 'home' | 'about' | 'services' | 'pricing';
  draft: SiteContent;
  onChange: (next: SiteContent) => void;
  enquiries: ContactEnquiry[];
  media: MediaFileItem[];
  hasUnpublishedChanges: boolean;
  onUploadFile: (file: File) => Promise<MediaFileItem | null>;
  onNavigateSection: (sec: string) => void;
}

const SERVICE_ICONS = [
  'Globe',
  'Layout',
  'Layers',
  'Crown',
  'Film',
  'Music',
  'Clapperboard',
  'Sparkles',
  'Target',
  'Palette',
  'Megaphone',
  'PenTool',
];

export const AdminContentEditors: React.FC<ContentEditorProps> = ({
  section,
  draft,
  onChange,
  enquiries,
  media,
  hasUnpublishedChanges,
  onUploadFile,
  onNavigateSection,
}) => {
  if (section === 'overview') {
    const unreadCount = enquiries.filter((e) => e.status === 'new').length;
    return (
      <div>
        <SectionHeader
          title="Website Overview"
          subtitle="Studio metrics, publication state, and recent incoming client enquiries."
        />

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="rounded-xl border border-white/10 bg-[#0d0d10] p-5">
            <p className="text-xs text-zinc-400">Active Services</p>
            <p className="mt-2 font-mono-tabular text-3xl font-bold text-white">
              {draft.services.filter((s) => s.active).length}
            </p>
          </div>
          <div className="rounded-xl border border-white/10 bg-[#0d0d10] p-5">
            <p className="text-xs text-zinc-400">Portfolio Projects</p>
            <p className="mt-2 font-mono-tabular text-3xl font-bold text-white">
              {draft.portfolio.length}
            </p>
          </div>
          <div className="rounded-xl border border-white/10 bg-[#0d0d10] p-5">
            <p className="text-xs text-zinc-400">New Enquiries</p>
            <p className="mt-2 font-mono-tabular text-3xl font-bold text-[#FF1744]">
              {unreadCount}
            </p>
          </div>
          <div className="rounded-xl border border-white/10 bg-[#0d0d10] p-5">
            <p className="text-xs text-zinc-400">Media Assets</p>
            <p className="mt-2 font-mono-tabular text-3xl font-bold text-white">
              {media.length}
            </p>
          </div>
        </div>

        <div className="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="rounded-xl border border-white/10 bg-[#0d0d10] p-6">
            <h3 className="font-display text-base font-bold text-white">Publish Status</h3>
            <p className="mt-2 text-sm text-zinc-400">
              Current version:{' '}
              <span className="font-mono-tabular text-white">v{draft.version}</span> ·{' '}
              {hasUnpublishedChanges ? (
                <span className="text-amber-300 font-medium">Unpublished draft edits pending</span>
              ) : (
                <span className="text-emerald-400 font-medium">Live site matches draft</span>
              )}
            </p>
            <div className="mt-5 grid grid-cols-2 gap-2.5 text-xs">
              {[
                { id: 'home', label: 'Edit Home Hero' },
                { id: 'services', label: 'Manage Services' },
                { id: 'pricing', label: 'Edit Pricing Tiers' },
                { id: 'portfolio', label: 'Manage Portfolio' },
                { id: 'testimonials', label: 'Manage Reviews' },
                { id: 'contact', label: 'View Enquiries' },
              ].map((shortcut) => (
                <button
                  key={shortcut.id}
                  type="button"
                  onClick={() => onNavigateSection(shortcut.id)}
                  className="rounded-lg border border-white/10 bg-white/[0.03] px-3.5 py-2.5 text-left font-medium text-zinc-200 hover:border-[#FF1744]/50 hover:text-white cursor-pointer"
                >
                  {shortcut.label}
                </button>
              ))}
            </div>
          </div>

          <div className="rounded-xl border border-white/10 bg-[#0d0d10] p-6">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-base font-bold text-white">Recent Enquiries</h3>
              <button
                type="button"
                onClick={() => onNavigateSection('contact')}
                className="text-xs font-semibold text-[#FF1744] hover:underline cursor-pointer"
              >
                Open Inbox
              </button>
            </div>
            {enquiries.length === 0 ? (
              <p className="mt-4 text-sm text-zinc-500">
                No contact enquiries submitted yet. Submissions from /contact appear here immediately.
              </p>
            ) : (
              <ul className="mt-4 divide-y divide-white/[0.06]">
                {enquiries.slice(0, 4).map((enq) => (
                  <li key={enq.id} className="py-3">
                    <div className="flex items-center justify-between gap-2 text-sm">
                      <span className="font-semibold text-white">{enq.name}</span>
                      <span className="font-mono-tabular text-[11px] text-zinc-500">
                        {new Date(enq.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-zinc-400 line-clamp-1">{enq.message}</p>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (section === 'home') {
    const h = draft.home;
    const updateHome = (patch: Partial<SiteContent['home']>) =>
      onChange({ ...draft, home: { ...h, ...patch } });

    return (
      <div>
        <SectionHeader
          title="Home Page Editor"
          subtitle="Control the hero heading, studio subheading, designation, portrait, introduction, and metrics."
        />
        <div className="space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FieldInput
              label="Main Brand Heading"
              value={h.brandName}
              onChange={(v) => updateHome({ brandName: v })}
            />
            <FieldInput
              label="Subheading"
              value={h.subheading}
              onChange={(v) => updateHome({ subheading: v })}
            />
            <FieldInput
              label="Designation"
              value={h.designation}
              onChange={(v) => updateHome({ designation: v })}
            />
            <FieldInput
              label="Hero Tagline / Reveal Phrase"
              value={h.revealTagline}
              onChange={(v) => updateHome({ revealTagline: v })}
            />
          </div>

          <FieldTextarea
            label="Hero Description"
            value={h.description}
            onChange={(v) => updateHome({ description: v })}
            rows={3}
          />

          <MediaUploadField
            label="Hero Portrait Image"
            value={h.portraitUrl}
            onChange={(v) => updateHome({ portraitUrl: v })}
            onUploadFile={onUploadFile}
          />

          <FieldInput
            label="Studio Introduction Heading"
            value={h.introHeading}
            onChange={(v) => updateHome({ introHeading: v })}
          />
          <FieldTextarea
            label="Studio Introduction Paragraph"
            value={h.introBody}
            onChange={(v) => updateHome({ introBody: v })}
            rows={3}
          />

          <div className="border-t border-white/[0.08] pt-5">
            <h3 className="font-display text-base font-semibold text-white mb-3">Home Metric Strip</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {h.stats.map((stat, idx) => (
                <div key={stat.id} className="rounded-xl border border-white/10 bg-[#0d0d10] p-4 grid grid-cols-2 gap-3">
                  <FieldInput
                    label={`Stat ${idx + 1} Value`}
                    value={stat.value}
                    onChange={(val) => {
                      const next = [...h.stats];
                      next[idx] = { ...stat, value: val };
                      updateHome({ stats: next });
                    }}
                  />
                  <FieldInput
                    label={`Stat ${idx + 1} Label`}
                    value={stat.label}
                    onChange={(val) => {
                      const next = [...h.stats];
                      next[idx] = { ...stat, label: val };
                      updateHome({ stats: next });
                    }}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (section === 'about') {
    const a = draft.about;
    const updateAbout = (patch: Partial<SiteContent['about']>) =>
      onChange({ ...draft, about: { ...a, ...patch } });

    return (
      <div>
        <SectionHeader
          title="About Page Editor"
          subtitle="Edit founder portrait, brand story, professional journey, creative vision, mission, goals, and statistics."
        />
        <div className="space-y-5">
          <MediaUploadField
            label="Profile Image"
            value={a.profileImageUrl}
            onChange={(v) => updateAbout({ profileImageUrl: v })}
            onUploadFile={onUploadFile}
          />
          <FieldTextarea
            label="Brand Introduction"
            value={a.brandIntroduction}
            onChange={(v) => updateAbout({ brandIntroduction: v })}
          />
          <FieldTextarea
            label="Personal Description"
            value={a.personalDescription}
            onChange={(v) => updateAbout({ personalDescription: v })}
          />
          <FieldTextarea
            label="Professional Journey"
            value={a.professionalJourney}
            onChange={(v) => updateAbout({ professionalJourney: v })}
          />
          <FieldTextarea
            label="Creative Vision"
            value={a.creativeVision}
            onChange={(v) => updateAbout({ creativeVision: v })}
          />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FieldTextarea
              label="Mission"
              value={a.mission}
              onChange={(v) => updateAbout({ mission: v })}
            />
            <FieldTextarea
              label="Goals"
              value={a.goals}
              onChange={(v) => updateAbout({ goals: v })}
            />
          </div>
          <div className="border-t border-white/[0.08] pt-5">
            <h3 className="font-display text-base font-semibold text-white mb-3">About Statistics</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {a.stats.map((stat, idx) => (
                <div key={stat.id} className="rounded-xl border border-white/10 bg-[#0d0d10] p-4 grid grid-cols-2 gap-3">
                  <FieldInput
                    label="Value"
                    value={stat.value}
                    onChange={(val) => {
                      const next = [...a.stats];
                      next[idx] = { ...stat, value: val };
                      updateAbout({ stats: next });
                    }}
                  />
                  <FieldInput
                    label="Label"
                    value={stat.label}
                    onChange={(val) => {
                      const next = [...a.stats];
                      next[idx] = { ...stat, label: val };
                      updateAbout({ stats: next });
                    }}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (section === 'services') {
    const addService = () => {
      const next: ServiceItem = {
        id: `srv-${Date.now()}`,
        slug: `service-${Date.now()}`,
        title: 'New Studio Service',
        shortDescription: 'Concise summary of the new service.',
        fullDescription: 'Detailed scope and creative deliverables.',
        startingPrice: '₹2,999',
        iconName: 'Sparkles',
        imageUrl: draft.services[0]?.imageUrl || '',
        deliverables: ['Custom creative direction'],
        featured: false,
        active: true,
      };
      onChange({ ...draft, services: [next, ...draft.services] });
    };

    const updateService = (idx: number, patch: Partial<ServiceItem>) => {
      const list = [...draft.services];
      list[idx] = { ...list[idx], ...patch };
      onChange({ ...draft, services: list });
    };

    const removeService = (idx: number) => {
      onChange({ ...draft, services: draft.services.filter((_, i) => i !== idx) });
    };

    return (
      <div>
        <SectionHeader
          title="Services Management"
          subtitle="Add, edit, or delete services, starting prices, descriptions, icons, and imagery."
          action={
            <button
              type="button"
              onClick={addService}
              className="crimson-glow-btn inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold text-white cursor-pointer"
            >
              <Plus className="w-4 h-4" aria-hidden="true" />
              <span>Add Service</span>
            </button>
          }
        />

        <div className="space-y-5">
          {draft.services.map((srv, idx) => (
            <div key={srv.id} className="rounded-xl border border-white/10 bg-[#0d0d10] p-5 space-y-4">
              <div className="flex items-center justify-between gap-3">
                <span className="font-display text-base font-bold text-white">
                  {idx + 1}. {srv.title}
                </span>
                <button
                  type="button"
                  onClick={() => removeService(idx)}
                  aria-label={`Delete service ${srv.title}`}
                  className="inline-flex items-center gap-1 text-xs text-zinc-400 hover:text-[#FF1744] cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" aria-hidden="true" />
                  <span>Delete</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <FieldInput
                  label="Service Title"
                  value={srv.title}
                  onChange={(v) => updateService(idx, { title: v })}
                />
                <FieldInput
                  label="Starting Price"
                  value={srv.startingPrice}
                  onChange={(v) => updateService(idx, { startingPrice: v })}
                />
                <label className="block">
                  <span className="block text-xs font-semibold text-zinc-300">Icon</span>
                  <select
                    value={srv.iconName}
                    onChange={(e) => updateService(idx, { iconName: e.target.value })}
                    className="mt-1.5 w-full rounded-lg border border-white/12 bg-[#0a0a0c] px-3 py-2.5 text-sm text-white focus:border-[#FF1744] focus:outline-none"
                  >
                    {SERVICE_ICONS.map((icon) => (
                      <option key={icon} value={icon}>
                        {icon}
                      </option>
                    ))}
                  </select>
                </label>
              </div>

              <FieldTextarea
                label="Short Card Description"
                value={srv.shortDescription}
                onChange={(v) => updateService(idx, { shortDescription: v })}
                rows={2}
              />
              <FieldTextarea
                label="Full Details Modal Description"
                value={srv.fullDescription}
                onChange={(v) => updateService(idx, { fullDescription: v })}
                rows={2}
              />
              <MediaUploadField
                label="Service Cover Image"
                value={srv.imageUrl || ''}
                onChange={(v) => updateService(idx, { imageUrl: v })}
                onUploadFile={onUploadFile}
              />
              <FieldTextarea
                label="Deliverables (one per line)"
                value={srv.deliverables.join('\n')}
                onChange={(v) =>
                  updateService(idx, {
                    deliverables: v
                      .split('\n')
                      .map((line) => line.trim())
                      .filter(Boolean),
                  })
                }
                rows={3}
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <FieldToggle
                  label="Visible on Services Page"
                  checked={srv.active}
                  onChange={(v) => updateService(idx, { active: v })}
                />
                <FieldToggle
                  label="Featured on Home Page"
                  checked={srv.featured}
                  onChange={(v) => updateService(idx, { featured: v })}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Pricing Management
  const updatePkg = (idx: number, patch: Partial<PricingPackage>) => {
    const list = [...draft.pricingPackages];
    list[idx] = { ...list[idx], ...patch };
    onChange({ ...draft, pricingPackages: list });
  };

  return (
    <div>
      <SectionHeader
        title="Pricing Management"
        subtitle="Customize Website Design Packages (Basic, Premium, Pro), prices, WhatsApp prompts, and editable feature lists."
      />
      <div className="space-y-6">
        {draft.pricingPackages.map((pkg, idx) => (
          <div key={pkg.id} className="rounded-xl border border-white/10 bg-[#0d0d10] p-6 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <FieldInput
                label="Package Name"
                value={pkg.name}
                onChange={(v) => updatePkg(idx, { name: v })}
              />
              <FieldInput
                label="Price"
                value={pkg.price}
                onChange={(v) => updatePkg(idx, { price: v })}
              />
              <FieldInput
                label="Target Audience"
                value={pkg.audience}
                onChange={(v) => updatePkg(idx, { audience: v })}
              />
            </div>

            <FieldInput
              label="Short Subtitle / Note"
              value={pkg.description}
              onChange={(v) => updatePkg(idx, { description: v })}
            />

            <FieldTextarea
              label="Package Features (one editable feature per line)"
              value={pkg.features.join('\n')}
              onChange={(v) =>
                updatePkg(idx, {
                  features: v
                    .split('\n')
                    .map((line) => line.trim())
                    .filter(Boolean),
                })
              }
              rows={5}
            />

            <FieldInput
              label="Pre-filled WhatsApp Enquiry Message"
              value={pkg.whatsappPrompt}
              onChange={(v) => updatePkg(idx, { whatsappPrompt: v })}
            />

            <FieldToggle
              label="Highlight as Recommended Package"
              checked={pkg.highlighted}
              onChange={(v) => updatePkg(idx, { highlighted: v })}
            />
          </div>
        ))}
      </div>
    </div>
  );
};
