import React, { useRef, useState } from 'react';
import { Upload } from 'lucide-react';
import type { MediaFileItem } from '../../shared/types';

export const SectionHeader: React.FC<{
  title: string;
  subtitle: string;
  action?: React.ReactNode;
}> = ({ title, subtitle, action }) => (
  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/[0.08] pb-5 mb-6">
    <div>
      <h2 className="font-display text-2xl font-bold text-white">{title}</h2>
      <p className="mt-1 text-xs sm:text-sm text-zinc-400">{subtitle}</p>
    </div>
    {action && <div className="shrink-0">{action}</div>}
  </div>
);

export const FieldInput: React.FC<{
  label: string;
  value: string;
  onChange: (val: string) => void;
  placeholder?: string;
  type?: string;
}> = ({ label, value, onChange, placeholder, type = 'text' }) => (
  <label className="block">
    <span className="block text-xs font-semibold text-zinc-300">{label}</span>
    <input
      type={type}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="mt-1.5 w-full rounded-lg border border-white/12 bg-[#0a0a0c] px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-500 focus:border-[#FF1744] focus:outline-none"
    />
  </label>
);

export const FieldTextarea: React.FC<{
  label: string;
  value: string;
  onChange: (val: string) => void;
  rows?: number;
  placeholder?: string;
}> = ({ label, value, onChange, rows = 3, placeholder }) => (
  <label className="block">
    <span className="block text-xs font-semibold text-zinc-300">{label}</span>
    <textarea
      rows={rows}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="mt-1.5 w-full rounded-lg border border-white/12 bg-[#0a0a0c] px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-500 focus:border-[#FF1744] focus:outline-none"
    />
  </label>
);

export const FieldToggle: React.FC<{
  label: string;
  checked: boolean;
  onChange: (val: boolean) => void;
  hint?: string;
}> = ({ label, checked, onChange, hint }) => (
  <label className="flex items-start justify-between gap-4 rounded-xl border border-white/10 bg-white/[0.02] px-4 py-3 cursor-pointer">
    <div>
      <span className="block text-sm font-medium text-white">{label}</span>
      {hint && <span className="block text-xs text-zinc-400 mt-0.5">{hint}</span>}
    </div>
    <input
      type="checkbox"
      checked={checked}
      onChange={(e) => onChange(e.target.checked)}
      className="mt-1 h-4 w-4 accent-[#FF1744] cursor-pointer"
    />
  </label>
);

export const MediaUploadField: React.FC<{
  label: string;
  value: string;
  onChange: (url: string) => void;
  onUploadFile: (file: File) => Promise<MediaFileItem | null>;
  accept?: string;
  placeholder?: string;
}> = ({
  label,
  value,
  onChange,
  onUploadFile,
  accept = 'image/png,image/jpeg,image/webp',
  placeholder = '/uploads/...',
}) => {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [uploading, setUploading] = useState(false);

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const uploaded = await onUploadFile(file);
    setUploading(false);
    if (uploaded) {
      onChange(uploaded.url);
    }
    e.target.value = '';
  };

  return (
    <div>
      <span className="block text-xs font-semibold text-zinc-300">{label}</span>
      <div className="mt-1.5 flex items-center gap-2">
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className="flex-1 rounded-lg border border-white/12 bg-[#0a0a0c] px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-500 focus:border-[#FF1744] focus:outline-none"
        />
        <input
          ref={inputRef}
          type="file"
          accept={accept}
          onChange={handleFile}
          className="hidden"
        />
        <button
          type="button"
          disabled={uploading}
          onClick={() => inputRef.current?.click()}
          className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-white/[0.04] px-3.5 py-2.5 text-xs font-semibold text-white hover:border-[#FF1744]/60 cursor-pointer whitespace-nowrap disabled:opacity-50"
        >
          <Upload className="w-3.5 h-3.5 text-[#FF1744]" aria-hidden="true" />
          <span>{uploading ? 'Uploading...' : 'Upload'}</span>
        </button>
      </div>
    </div>
  );
};
