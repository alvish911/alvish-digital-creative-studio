import React from 'react';
import {
  Clapperboard,
  Crown,
  Film,
  Globe,
  Layers,
  Layout,
  Megaphone,
  Music,
  Palette,
  PenTool,
  Sparkles,
  Target,
} from 'lucide-react';

const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  Globe,
  Layout,
  Layers,
  Crown,
  Film,
  Music,
  Clapperboard,
  Sparkles,
  Target,
  Palette,
  Megaphone,
  PenTool,
};

export const ServiceIcon: React.FC<{ name: string; className?: string }> = ({
  name,
  className = 'w-5 h-5',
}) => {
  const IconComponent = ICON_MAP[name] || Globe;
  return <IconComponent className={className} aria-hidden="true" />;
};
