import React from 'react';
import { Link } from 'react-router-dom';
import { MessageCircle, Instagram, Lock } from 'lucide-react';
import { useSite } from '../context/SiteContext';
import { safeHref } from '../shared/validation';

export const Footer: React.FC = () => {
  const { site } = useSite();
  const visibleNav = [...site.navigation]
    .filter((item) => item.visible)
    .sort((a, b) => a.order - b.order);

  return (
    <footer className="relative z-10 border-t border-white/[0.08] bg-[#050505]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-12">
          {/* Brand Summary */}
          <div className="md:col-span-5">
            <Link to="/" className="font-display text-2xl font-extrabold tracking-[0.16em] text-white">
              {site.home.brandName}
            </Link>
            <p className="mt-1.5 text-xs font-semibold tracking-[0.22em] text-[#FF1744]">
              {site.home.subheading}
            </p>
            <p className="mt-4 max-w-md text-sm leading-relaxed text-zinc-400">
              {site.home.description}
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <a
                href={safeHref(site.contact.whatsappLink, 'https://wa.me/918247206736')}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-lg border border-white/12 bg-white/[0.03] px-4 py-2 text-xs font-medium text-white hover:border-[#FF1744]/50 transition-colors"
              >
                <MessageCircle className="w-4 h-4 text-[#FF1744]" aria-hidden="true" />
                <span>WhatsApp · {site.contact.whatsappNumber}</span>
              </a>
              <a
                href={safeHref(site.contact.instagramUrl, 'https://instagram.com/alvish_studios_dwm')}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-lg border border-white/12 bg-white/[0.03] px-4 py-2 text-xs font-medium text-white hover:border-[#FF1744]/50 transition-colors"
              >
                <Instagram className="w-4 h-4 text-[#FF1744]" aria-hidden="true" />
                <span>@{site.contact.instagramHandle}</span>
              </a>
            </div>
          </div>

          {/* Navigation Links */}
          <div className="md:col-span-4">
            <h2 className="font-display text-sm font-semibold text-white">Explore Studio</h2>
            <ul className="mt-4 grid grid-cols-2 gap-x-6 gap-y-2.5 text-sm">
              {visibleNav.map((item) => (
                <li key={item.id}>
                  <Link
                    to={item.path}
                    className="text-zinc-400 hover:text-white transition-colors"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Direct Studio Info */}
          <div className="md:col-span-3">
            <h2 className="font-display text-sm font-semibold text-white">Direct Contact</h2>
            <div className="mt-4 space-y-2.5 text-sm text-zinc-400">
              <p className="text-zinc-200 font-medium">{site.home.designation}</p>
              <p>{site.contact.location}</p>
              <p className="font-mono-tabular text-zinc-300">{site.contact.whatsappDisplay}</p>
              <p>{site.contact.email}</p>
            </div>
          </div>
        </div>

        <div className="mt-12 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-white/[0.07] pt-6 text-xs text-zinc-500">
          <p>
            © {new Date().getFullYear()} {site.home.brandName} – Digital Creative Studio. All rights reserved.
          </p>
          <Link
            to="/admin/login"
            className="inline-flex items-center gap-1.5 text-zinc-500 hover:text-zinc-200 transition-colors"
          >
            <Lock className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Admin Portal</span>
          </Link>
        </div>
      </div>
    </footer>
  );
};
