import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { Eye, X } from 'lucide-react';
import { Navbar } from './Navbar';
import { Footer } from './Footer';
import { ParticleCanvas } from './ParticleCanvas';
import { useSite } from '../context/SiteContext';

interface PageShellProps {
  title?: string;
  description?: string;
  children: React.ReactNode;
}

export const PageShell: React.FC<PageShellProps> = ({ title, description, children }) => {
  const { site, isPreviewMode, setPreviewContent } = useSite();

  useEffect(() => {
    const fullTitle = title
      ? `${title} | ${site.home.brandName} – Digital Creative Studio`
      : site.seo.siteTitle;
    document.title = fullTitle;

    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) {
      metaDesc.setAttribute('content', description || site.seo.metaDescription);
    }
  }, [title, description, site.home.brandName, site.seo.siteTitle, site.seo.metaDescription]);

  return (
    <div className="relative min-h-screen flex flex-col bg-[var(--studio-bg)] text-[var(--studio-text)] studio-ambient-radial">
      <ParticleCanvas
        enabled={site.theme.enableParticles}
        accentColor={site.theme.accentColor}
      />

      {isPreviewMode && (
        <div className="relative z-50 border-b border-[#FF1744]/40 bg-[#1c060b] px-4 py-2.5 text-xs text-white">
          <div className="mx-auto flex max-w-7xl items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Eye className="w-4 h-4 text-[#FF1744]" aria-hidden="true" />
              <span className="font-medium">
                Live Draft Preview — You are viewing unpublished changes from Admin Dashboard.
              </span>
            </div>
            <div className="flex items-center gap-3">
              <Link
                to="/admin/dashboard"
                className="font-semibold text-[#FF1744] hover:underline whitespace-nowrap"
              >
                Return to Dashboard
              </Link>
              <button
                type="button"
                onClick={() => setPreviewContent(null)}
                aria-label="Exit draft preview"
                className="inline-flex items-center gap-1 rounded border border-white/20 px-2 py-1 hover:bg-white/10 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Exit</span>
              </button>
            </div>
          </div>
        </div>
      )}

      <Navbar />

      <motion.main
        initial={site.theme.enableAnimations ? { opacity: 0.01, y: 10 } : false}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
        className="relative z-10 flex-1"
      >
        {children}
      </motion.main>

      <Footer />
    </div>
  );
};
