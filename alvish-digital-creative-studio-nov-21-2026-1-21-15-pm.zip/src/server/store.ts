import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import type {
  ContactEnquiry,
  MediaFileItem,
  SecurityEvent,
  SiteContent,
} from '../shared/types.ts';
import { createDefaultSiteContent } from '../shared/defaultData.ts';
import type { StoredAdminCredential } from './auth.ts';

export interface DatabaseSnapshot {
  published: SiteContent;
  draft: SiteContent;
  enquiries: ContactEnquiry[];
  media: MediaFileItem[];
  securityEvents: SecurityEvent[];
  adminCredential: StoredAdminCredential | null;
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'alvish-db.json');

function clone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value));
}

export class StudioStore {
  private state: DatabaseSnapshot;

  constructor(private readonly filePath = DATA_FILE) {
    this.state = this.loadFromDisk();
  }

  private createInitialState(): DatabaseSnapshot {
    const initialSite = createDefaultSiteContent();
    return {
      published: clone(initialSite),
      draft: clone(initialSite),
      enquiries: [],
      media: [
        {
          id: 'med-portrait',
          fileName: 'alvish-portrait_154cfaa1.png',
          url: '/assets/aistudio/alvish-portrait_154cfaa1.png',
          mimeType: 'image/png',
          sizeBytes: 0,
          createdAt: new Date().toISOString(),
        },
        {
          id: 'med-intro-audio',
          fileName: 'alvish-track_c7df55aa.mp3',
          url: '/assets/aistudio/alvish-track_c7df55aa.mp3',
          mimeType: 'audio/mpeg',
          sizeBytes: 0,
          createdAt: new Date().toISOString(),
        },
      ],
      securityEvents: [],
      adminCredential: null,
    };
  }

  private loadFromDisk(): DatabaseSnapshot {
    try {
      if (fs.existsSync(this.filePath)) {
        const raw = fs.readFileSync(this.filePath, 'utf8');
        const parsed = JSON.parse(raw) as Partial<DatabaseSnapshot>;
        const defaults = this.createInitialState();
        const published = parsed.published ?? defaults.published;
        const draft = parsed.draft ?? published ?? defaults.draft;
        const legacyAudio = '/assets/alvish-intro.wav';
        const uploadedAudio = '/assets/aistudio/alvish-track_c7df55aa.mp3';
        if (published.music?.trackUrl === legacyAudio) {
          published.music.trackUrl = uploadedAudio;
        }
        if (draft.music?.trackUrl === legacyAudio) {
          draft.music.trackUrl = uploadedAudio;
        }
        return {
          published,
          draft,
          enquiries: Array.isArray(parsed.enquiries) ? parsed.enquiries : [],
          media: Array.isArray(parsed.media) && parsed.media.length > 0 ? parsed.media : defaults.media,
          securityEvents: Array.isArray(parsed.securityEvents) ? parsed.securityEvents : [],
          adminCredential: parsed.adminCredential ?? null,
        };
      }
    } catch (err) {
      console.error('Failed to read persisted studio store, falling back to defaults:', err);
    }
    const fresh = this.createInitialState();
    this.persist(fresh);
    return fresh;
  }

  private persist(nextState: DatabaseSnapshot): void {
    try {
      const dir = path.dirname(this.filePath);
      fs.mkdirSync(dir, { recursive: true });
      const tempPath = `${this.filePath}.${crypto.randomBytes(6).toString('hex')}.tmp`;
      fs.writeFileSync(tempPath, JSON.stringify(nextState, null, 2), 'utf8');
      fs.renameSync(tempPath, this.filePath);
    } catch (err) {
      console.error('Unable to persist studio store to disk:', err);
    }
  }

  getPublishedSite(): SiteContent {
    return clone(this.state.published);
  }

  getDraftSite(): SiteContent {
    return clone(this.state.draft);
  }

  hasUnpublishedChanges(): boolean {
    return JSON.stringify(this.state.draft) !== JSON.stringify(this.state.published);
  }

  saveDraft(nextDraft: SiteContent): SiteContent {
    const updated: SiteContent = {
      ...clone(nextDraft),
      updatedAt: new Date().toISOString(),
    };
    this.state.draft = updated;
    this.persist(this.state);
    return clone(updated);
  }

  publish(content?: SiteContent): SiteContent {
    const source = content ? clone(content) : clone(this.state.draft);
    source.version = (this.state.published.version || 1) + 1;
    source.updatedAt = new Date().toISOString();
    this.state.published = clone(source);
    this.state.draft = clone(source);
    this.persist(this.state);
    return clone(this.state.published);
  }

  discardDraft(): SiteContent {
    this.state.draft = clone(this.state.published);
    this.persist(this.state);
    return clone(this.state.draft);
  }

  getAdminCredential(): StoredAdminCredential | null {
    return this.state.adminCredential ? clone(this.state.adminCredential) : null;
  }

  setAdminCredential(cred: StoredAdminCredential): void {
    this.state.adminCredential = clone(cred);
    this.persist(this.state);
  }

  addEnquiry(input: Omit<ContactEnquiry, 'id' | 'status' | 'createdAt'>): ContactEnquiry {
    const enquiry: ContactEnquiry = {
      id: `enq-${crypto.randomBytes(6).toString('hex')}`,
      name: input.name,
      phone: input.phone,
      email: input.email,
      message: input.message,
      status: 'new',
      createdAt: new Date().toISOString(),
    };
    this.state.enquiries.unshift(enquiry);
    this.persist(this.state);
    return clone(enquiry);
  }

  listEnquiries(): ContactEnquiry[] {
    return clone(this.state.enquiries);
  }

  updateEnquiryStatus(id: string, status: ContactEnquiry['status']): ContactEnquiry | null {
    const target = this.state.enquiries.find((e) => e.id === id);
    if (!target) return null;
    target.status = status;
    this.persist(this.state);
    return clone(target);
  }

  deleteEnquiry(id: string): boolean {
    const before = this.state.enquiries.length;
    this.state.enquiries = this.state.enquiries.filter((e) => e.id !== id);
    if (this.state.enquiries.length === before) return false;
    this.persist(this.state);
    return true;
  }

  listMedia(): MediaFileItem[] {
    return clone(this.state.media);
  }

  addMedia(item: Omit<MediaFileItem, 'id' | 'createdAt'>): MediaFileItem {
    const created: MediaFileItem = {
      id: `med-${crypto.randomBytes(6).toString('hex')}`,
      fileName: item.fileName,
      url: item.url,
      mimeType: item.mimeType,
      sizeBytes: item.sizeBytes,
      createdAt: new Date().toISOString(),
    };
    this.state.media.unshift(created);
    this.persist(this.state);
    return clone(created);
  }

  deleteMedia(id: string): MediaFileItem | null {
    const found = this.state.media.find((m) => m.id === id) ?? null;
    if (!found) return null;
    this.state.media = this.state.media.filter((m) => m.id !== id);
    this.persist(this.state);
    return clone(found);
  }

  recordSecurityEvent(action: string, actor: string, detail: string): void {
    const event: SecurityEvent = {
      id: `sec-${crypto.randomBytes(5).toString('hex')}`,
      action,
      actor,
      detail,
      timestamp: new Date().toISOString(),
    };
    this.state.securityEvents.unshift(event);
    if (this.state.securityEvents.length > 60) {
      this.state.securityEvents = this.state.securityEvents.slice(0, 60);
    }
    this.persist(this.state);
  }

  listSecurityEvents(): SecurityEvent[] {
    return clone(this.state.securityEvents);
  }

  exportBackup() {
    return {
      exportedAt: new Date().toISOString(),
      studio: 'ALVISH – Digital Creative Studio',
      schemaVersion: 1,
      published: clone(this.state.published),
      enquiries: clone(this.state.enquiries),
      media: clone(this.state.media),
    };
  }

  restoreBackup(site: SiteContent, enquiries?: ContactEnquiry[]): SiteContent {
    const restored: SiteContent = {
      ...clone(site),
      version: (this.state.published.version || 1) + 1,
      updatedAt: new Date().toISOString(),
    };
    this.state.published = clone(restored);
    this.state.draft = clone(restored);
    if (Array.isArray(enquiries)) {
      this.state.enquiries = clone(enquiries);
    }
    this.persist(this.state);
    return clone(restored);
  }
}
