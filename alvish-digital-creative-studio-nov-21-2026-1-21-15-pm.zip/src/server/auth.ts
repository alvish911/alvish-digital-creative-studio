import crypto from 'node:crypto';

export interface StoredAdminCredential {
  email: string;
  passwordHash: string; // format: scrypt$<saltHex>$<derivedHex>
  createdAt: string;
  updatedAt: string;
}

export interface SessionRecord {
  token: string;
  email: string;
  createdAt: number;
  expiresAt: number;
}

const SESSION_TTL_MS = 24 * 60 * 60 * 1000;

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt$${salt}$${derived}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split('$');
  if (parts.length !== 3 || parts[0] !== 'scrypt') return false;
  const [, salt, originalHex] = parts;
  if (!salt || !originalHex) return false;
  const derivedBuf = crypto.scryptSync(password, salt, 64);
  const originalBuf = Buffer.from(originalHex, 'hex');
  if (derivedBuf.length !== originalBuf.length) return false;
  return crypto.timingSafeEqual(derivedBuf, originalBuf);
}

export function constantTimeStringEqual(a: string, b: string): boolean {
  const aBuf = Buffer.from(a, 'utf8');
  const bBuf = Buffer.from(b, 'utf8');
  if (aBuf.length !== bBuf.length) {
    // Run dummy compare to reduce length timing leak
    crypto.timingSafeEqual(aBuf, Buffer.alloc(aBuf.length));
    return false;
  }
  return crypto.timingSafeEqual(aBuf, bBuf);
}

export class SessionManager {
  private sessions = new Map<string, SessionRecord>();

  create(email: string): SessionRecord {
    const token = crypto.randomBytes(32).toString('hex');
    const now = Date.now();
    const record: SessionRecord = {
      token,
      email,
      createdAt: now,
      expiresAt: now + SESSION_TTL_MS,
    };
    this.sessions.set(token, record);
    return record;
  }

  verify(token: string | undefined | null): SessionRecord | null {
    if (!token) return null;
    const record = this.sessions.get(token);
    if (!record) return null;
    if (Date.now() > record.expiresAt) {
      this.sessions.delete(token);
      return null;
    }
    return record;
  }

  revoke(token: string): void {
    this.sessions.delete(token);
  }

  revokeAll(): void {
    this.sessions.clear();
  }
}

interface RateBucket {
  count: number;
  resetAt: number;
}

export class RateLimiter {
  private buckets = new Map<string, RateBucket>();

  constructor(
    private readonly maxAttempts: number,
    private readonly windowMs: number,
  ) {}

  check(key: string): { allowed: boolean; remaining: number; retryAfterSeconds: number } {
    const now = Date.now();
    const existing = this.buckets.get(key);
    if (!existing || now > existing.resetAt) {
      return { allowed: true, remaining: this.maxAttempts, retryAfterSeconds: 0 };
    }
    if (existing.count >= this.maxAttempts) {
      return {
        allowed: false,
        remaining: 0,
        retryAfterSeconds: Math.max(1, Math.ceil((existing.resetAt - now) / 1000)),
      };
    }
    return {
      allowed: true,
      remaining: this.maxAttempts - existing.count,
      retryAfterSeconds: 0,
    };
  }

  recordAttempt(key: string): void {
    const now = Date.now();
    const existing = this.buckets.get(key);
    if (!existing || now > existing.resetAt) {
      this.buckets.set(key, { count: 1, resetAt: now + this.windowMs });
    } else {
      existing.count += 1;
    }
  }

  reset(key: string): void {
    this.buckets.delete(key);
  }
}
