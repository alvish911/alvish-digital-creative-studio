import React, { useEffect, useState } from 'react';
import { BrowserRouter, Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { SiteProvider, useSite } from './context/SiteContext';
import { AuthProvider } from './context/AuthContext';
import { AudioProvider } from './context/AudioContext';
import { CinematicIntro } from './components/CinematicIntro';
import { HomePage } from './pages/HomePage';
import { AboutPage } from './pages/AboutPage';
import { ServicesPage } from './pages/ServicesPage';
import { SkillsPage } from './pages/SkillsPage';
import { ExperiencePage } from './pages/ExperiencePage';
import { PortfolioPage } from './pages/PortfolioPage';
import { AchievementsPage } from './pages/AchievementsPage';
import { TestimonialsPage } from './pages/TestimonialsPage';
import { ContactPage } from './pages/ContactPage';
import { AdminLoginPage } from './pages/AdminLoginPage';
import { AdminDashboardPage } from './pages/AdminDashboardPage';
import { ExportPage } from './pages/ExportPage';

class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(): { hasError: boolean } {
    return { hasError: true };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#050505] text-white flex flex-col items-center justify-center p-6 text-center">
          <h1 className="font-display text-2xl font-bold">ALVISH – Digital Creative Studio</h1>
          <p className="mt-2 text-sm text-zinc-400">
            Something unexpected happened while rendering this view.
          </p>
          <button
            type="button"
            onClick={() => window.location.reload()}
            className="crimson-glow-btn mt-6 rounded-lg px-5 py-2.5 text-sm font-semibold text-white cursor-pointer"
          >
            Reload Website
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

const ScrollToTop: React.FC = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'auto' });
  }, [pathname]);
  return null;
};

const AppShellRoutes: React.FC = () => {
  const { site } = useSite();
  const location = useLocation();

  const [introDone, setIntroDone] = useState<boolean>(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') return true;
    if (window.location.pathname.startsWith('/admin') || window.location.pathname.startsWith('/export')) {
      return true;
    }
    const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    if (reduced) return true;
    return false;
  });

  const shouldShowIntro =
    !introDone &&
    site.intro.enabled &&
    site.theme.sectionVisibility.introAnimation &&
    !location.pathname.startsWith('/admin') &&
    !location.pathname.startsWith('/export');

  return (
    <>
      <ScrollToTop />
      {shouldShowIntro && <CinematicIntro onComplete={() => setIntroDone(true)} />}
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/services" element={<ServicesPage />} />
        <Route path="/skills" element={<SkillsPage />} />
        <Route path="/experience" element={<ExperiencePage />} />
        <Route path="/portfolio" element={<PortfolioPage />} />
        <Route path="/achievements" element={<AchievementsPage />} />
        <Route path="/testimonials" element={<TestimonialsPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/admin/login" element={<AdminLoginPage />} />
        <Route path="/admin/dashboard" element={<AdminDashboardPage />} />
        <Route path="/export" element={<ExportPage />} />
        <Route path="/admin" element={<Navigate to="/admin/login" replace />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  );
};

export default function App() {
  return (
    <ErrorBoundary>
      <SiteProvider>
        <AuthProvider>
          <AudioProvider>
            <BrowserRouter>
              <AppShellRoutes />
            </BrowserRouter>
          </AudioProvider>
        </AuthProvider>
      </SiteProvider>
    </ErrorBoundary>
  );
}
