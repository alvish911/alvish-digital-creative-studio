export type PortfolioCategory =
  | 'Website Designs'
  | 'AI Videos'
  | 'AI Songs'
  | 'Advertisements'
  | 'Posters'
  | 'Business Promotions'
  | 'Social Media Designs';

export const PORTFOLIO_CATEGORIES: PortfolioCategory[] = [
  'Website Designs',
  'AI Videos',
  'AI Songs',
  'Advertisements',
  'Posters',
  'Business Promotions',
  'Social Media Designs',
];

export interface HomeContent {
  brandName: string;
  subheading: string;
  designation: string;
  description: string;
  revealTagline: string;
  portraitUrl: string;
  introHeading: string;
  introBody: string;
  stats: Array<{ id: string; value: string; label: string }>;
}

export interface AboutContent {
  profileImageUrl: string;
  brandIntroduction: string;
  personalDescription: string;
  professionalJourney: string;
  creativeVision: string;
  mission: string;
  goals: string;
  stats: Array<{ id: string; value: string; label: string }>;
}

export interface ServiceItem {
  id: string;
  slug: string;
  title: string;
  shortDescription: string;
  fullDescription: string;
  startingPrice: string;
  iconName: string;
  imageUrl?: string;
  deliverables: string[];
  featured: boolean;
  active: boolean;
}

export interface PricingPackage {
  id: string;
  name: string;
  price: string;
  audience: string;
  description: string;
  features: string[];
  highlighted: boolean;
  whatsappPrompt: string;
}

export interface SkillItem {
  id: string;
  name: string;
  category: string;
  percentage: number;
  description: string;
}

export interface ExperienceItem {
  id: string;
  title: string;
  companyOrProject: string;
  description: string;
  startDate: string;
  endDate: string;
  highlights: string[];
}

export interface PortfolioProject {
  id: string;
  title: string;
  category: PortfolioCategory;
  clientName: string;
  year: string;
  summary: string;
  details: string;
  imageUrl: string;
  videoUrl?: string;
  projectUrl?: string;
  metrics?: string;
  featured: boolean;
  published: boolean;
  order: number;
}

export interface AchievementItem {
  id: string;
  title: string;
  issuer: string;
  kind: 'Certificate' | 'Award' | 'Milestone' | 'Recognition';
  dateLabel: string;
  description: string;
  imageUrl?: string;
  credentialUrl?: string;
}

export interface TestimonialItem {
  id: string;
  clientName: string;
  clientRole: string;
  clientCompany: string;
  clientAvatarUrl?: string;
  reviewText: string;
  rating: number;
  isDemo: boolean;
  published: boolean;
}

export interface ContactDetails {
  studioName: string;
  subName: string;
  whatsappNumber: string;
  whatsappDisplay: string;
  whatsappLink: string;
  instagramHandle: string;
  instagramUrl: string;
  email: string;
  location: string;
  availabilityText: string;
}

export interface SocialLinks {
  whatsapp: string;
  instagram: string;
  youtube: string;
  linkedin: string;
  behance: string;
  x: string;
}

export interface IntroSettings {
  enabled: boolean;
  tagline: string;
  durationMs: number;
  showParticles: boolean;
  skipButtonVisible: boolean;
}

export interface MusicSettings {
  enabled: boolean;
  trackUrl: string;
  trackTitle: string;
  attemptAutoplay: boolean;
  loop: boolean;
  defaultVolume: number;
}

export interface ThemeSettings {
  backgroundColor: string;
  surfaceColor: string;
  accentColor: string;
  deepAccentColor: string;
  textColor: string;
  glassBlurPx: number;
  enableParticles: boolean;
  enableAnimations: boolean;
  sectionVisibility: {
    featuredWork: boolean;
    pricingPackages: boolean;
    testimonials: boolean;
    achievements: boolean;
    introAnimation: boolean;
  };
}

export interface NavItem {
  id: string;
  label: string;
  path: string;
  visible: boolean;
  order: number;
}

export interface SeoSettings {
  siteTitle: string;
  metaDescription: string;
  keywords: string;
  ogImageUrl: string;
}

export interface SiteContent {
  version: number;
  updatedAt: string;
  home: HomeContent;
  about: AboutContent;
  services: ServiceItem[];
  pricingPackages: PricingPackage[];
  skills: SkillItem[];
  experience: ExperienceItem[];
  portfolio: PortfolioProject[];
  achievements: AchievementItem[];
  testimonials: TestimonialItem[];
  contact: ContactDetails;
  socialLinks: SocialLinks;
  intro: IntroSettings;
  music: MusicSettings;
  theme: ThemeSettings;
  navigation: NavItem[];
  seo: SeoSettings;
}

export interface ContactEnquiry {
  id: string;
  name: string;
  phone: string;
  email: string;
  message: string;
  status: 'new' | 'read' | 'replied';
  createdAt: string;
}

export interface MediaFileItem {
  id: string;
  fileName: string;
  url: string;
  mimeType: string;
  sizeBytes: number;
  createdAt: string;
}

export interface SecurityEvent {
  id: string;
  action: string;
  actor: string;
  timestamp: string;
  detail: string;
}

export interface AdminAuthStatus {
  authenticated: boolean;
  needsBootstrap: boolean;
  envManaged: boolean;
  email: string | null;
}

export interface AdminDashboardState {
  published: SiteContent;
  draft: SiteContent;
  hasUnpublishedChanges: boolean;
  enquiries: ContactEnquiry[];
  media: MediaFileItem[];
  securityEvents: SecurityEvent[];
}
