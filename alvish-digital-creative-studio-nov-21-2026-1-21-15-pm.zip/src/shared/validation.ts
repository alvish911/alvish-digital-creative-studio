import type { SiteContent } from './types';

export interface ContactFormInput {
  name: string;
  phone: string;
  email: string;
  message: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: Record<string, string>;
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const PHONE_REGEX = /^[+\d][\d\s\-()]{7,18}$/;

export function sanitizeText(value: unknown, maxLength = 2000): string {
  if (typeof value !== 'string') return '';
  return value.replace(/\0/g, '').trim().slice(0, maxLength);
}

export function isSafeUrl(url: string | undefined | null): boolean {
  if (!url) return true;
  const trimmed = url.trim();
  if (!trimmed) return true;
  if (trimmed.startsWith('/')) {
    return !trimmed.startsWith('//');
  }
  try {
    const parsed = new URL(trimmed);
    return parsed.protocol === 'https:' || parsed.protocol === 'http:' || parsed.protocol === 'mailto:' || parsed.protocol === 'tel:';
  } catch {
    return false;
  }
}

export function safeHref(url: string | undefined | null, fallback = '#'): string {
  if (!url || !isSafeUrl(url)) return fallback;
  return url.trim();
}

export function validateContactForm(input: ContactFormInput): ValidationResult {
  const errors: Record<string, string> = {};
  const name = sanitizeText(input.name, 120);
  const phone = sanitizeText(input.phone, 30);
  const email = sanitizeText(input.email, 160);
  const message = sanitizeText(input.message, 3000);

  if (name.length < 2) {
    errors.name = 'Please enter your full name (at least 2 characters).';
  }
  if (!PHONE_REGEX.test(phone)) {
    errors.phone = 'Please enter a valid phone or WhatsApp number.';
  }
  if (!EMAIL_REGEX.test(email)) {
    errors.email = 'Please enter a valid email address.';
  }
  if (message.length < 10) {
    errors.message = 'Please tell us a bit more about your project (at least 10 characters).';
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors,
  };
}

export function validateAdminPassword(password: string): { valid: boolean; reason?: string } {
  if (typeof password !== 'string' || password.length < 8) {
    return { valid: false, reason: 'Password must be at least 8 characters long.' };
  }
  if (password.length > 128) {
    return { valid: false, reason: 'Password must not exceed 128 characters.' };
  }
  const hasLetter = /[A-Za-z]/.test(password);
  const hasNumber = /\d/.test(password);
  if (!hasLetter || !hasNumber) {
    return { valid: false, reason: 'Password must contain at least one letter and one number.' };
  }
  return { valid: true };
}

export function clampPercentage(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(100, Math.round(value)));
}

export function buildWhatsAppUrl(baseLink: string, message: string): string {
  const cleanBase = isSafeUrl(baseLink) && baseLink ? baseLink.trim() : 'https://wa.me/918247206736';
  const separator = cleanBase.includes('?') ? '&' : '?';
  return `${cleanBase}${separator}text=${encodeURIComponent(message)}`;
}

export function validateBackupPayload(payload: unknown): { valid: boolean; error?: string; site?: SiteContent } {
  if (!payload || typeof payload !== 'object') {
    return { valid: false, error: 'Backup must be a valid JSON object.' };
  }
  const candidate = (payload as Record<string, unknown>).published ?? payload;
  if (!candidate || typeof candidate !== 'object') {
    return { valid: false, error: 'Backup is missing site content data.' };
  }
  const site = candidate as Partial<SiteContent>;
  if (!site.home || !site.about || !Array.isArray(site.services) || !Array.isArray(site.pricingPackages)) {
    return { valid: false, error: 'Backup is missing required sections (home, about, services, pricingPackages).' };
  }
  if (!Array.isArray(site.skills) || !Array.isArray(site.experience) || !Array.isArray(site.portfolio)) {
    return { valid: false, error: 'Backup is missing required arrays (skills, experience, portfolio).' };
  }
  if (!Array.isArray(site.achievements) || !Array.isArray(site.testimonials) || !Array.isArray(site.navigation)) {
    return { valid: false, error: 'Backup is missing required arrays (achievements, testimonials, navigation).' };
  }
  if (!site.contact || !site.theme || !site.seo) {
    return { valid: false, error: 'Backup is missing contact, theme, or SEO configuration.' };
  }
  return { valid: true, site: site as SiteContent };
}
