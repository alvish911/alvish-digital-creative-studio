import type { SiteContent } from './types';

export const ASSET_PATHS = {
  portrait: '/assets/aistudio/alvish-portrait_154cfaa1.png',
  webShowcase: '/src/assets/images/portfolio_luxury_web_1795237560522.jpg',
  aiVideo: '/src/assets/images/portfolio_ai_video_1795237565962.jpg',
  aiMusic: '/src/assets/images/portfolio_ai_music_1795237562533.jpg',
  adCampaign: '/src/assets/images/portfolio_ad_campaign_1795237556323.jpg',
  achievementAward: '/src/assets/images/achievement_award_visual_1795237558963.jpg',
  introAudio: '/assets/aistudio/alvish-track_c7df55aa.mp3',
} as const;

export function createDefaultSiteContent(): SiteContent {
  return {
    version: 1,
    updatedAt: new Date().toISOString(),
    home: {
      brandName: 'ALVISH',
      subheading: 'DIGITAL CREATIVE STUDIO',
      designation: 'FREELANCER & ENTREPRENEUR',
      description:
        'I create modern digital experiences, creative designs, AI-powered promotions, and professional websites that help brands grow.',
      revealTagline: "LET'S CREATE SOMETHING AMAZING",
      portraitUrl: ASSET_PATHS.portrait,
      introHeading: 'Luxury digital craftsmanship built for ambitious brands.',
      introBody:
        'ALVISH – Digital Creative Studio brings together bespoke web engineering, cinematic AI commercial production, original AI soundtracks, and conversion-focused social media campaigns under one disciplined creative direction.',
      stats: [
        { id: 'st-1', value: '12+', label: 'Core Studio Capabilities' },
        { id: 'st-2', value: '360°', label: 'Web, AI Media & Growth' },
        { id: 'st-3', value: '48h', label: 'Rapid Concept Turnaround' },
        { id: 'st-4', value: '100%', label: 'Custom Brand Direction' },
      ],
    },
    about: {
      profileImageUrl: ASSET_PATHS.portrait,
      brandIntroduction:
        'ALVISH – Digital Creative Studio is an independent creative & technology practice founded by Alvish — Freelancer & Entrepreneur dedicated to transforming businesses through cinema-grade digital storytelling and high-converting web architecture.',
      personalDescription:
        'Blending visual design precision with next-generation generative AI production, I partner directly with founders, creators, and growing businesses to build unmistakable digital presence—from flagship websites and Meta ad funnels to bespoke AI video commercials and studio-grade brand identities.',
      professionalJourney:
        'What began as a deep obsession with visual craft, typography, and digital media rapidly evolved into a full-spectrum creative studio. Over years of hands-on freelance and entrepreneurial execution, I expanded from responsive web design into AI commercial filmmaking, UGC AI campaigns, original AI music production, and full-funnel social growth systems.',
      creativeVision:
        'Every brand deserves a digital presence that commands attention within the first three seconds—uniting bold visual restraint, kinetic motion, and measurable commercial performance.',
      mission:
        'Deliver agency-caliber websites, AI-powered advertising, and creative assets with direct founder-level speed, transparent pricing, and zero template compromises.',
      goals:
        'Empower modern businesses across India and globally to scale faster using high-impact visual storytelling, interactive web platforms, and AI-accelerated creative workflows.',
      stats: [
        { id: 'ab-1', value: '50+', label: 'Creative Campaigns Delivered' },
        { id: 'ab-2', value: '12', label: 'Specialized Digital Services' },
        { id: 'ab-3', value: '7', label: 'Portfolio Disciplines' },
        { id: 'ab-4', value: '24/7', label: 'Direct WhatsApp Studio Access' },
      ],
    },
    services: [
      {
        id: 'srv-1',
        slug: 'website-designing',
        title: 'Website Designing',
        shortDescription:
          'Bespoke, responsive, cinema-grade websites engineered for visual authority and measurable conversion.',
        fullDescription:
          'End-to-end website design and architecture crafted from scratch around your brand identity—combining responsive layouts, refined motion, SEO foundations, and fast loading speeds across desktop and mobile.',
        startingPrice: '₹5,999',
        iconName: 'Globe',
        imageUrl: ASSET_PATHS.webShowcase,
        deliverables: [
          'Custom UI/UX architecture tailored to your brand',
          'Responsive desktop, tablet, and mobile layouts',
          'WhatsApp & lead-capture integration',
          'SEO-ready semantic markup & fast performance',
        ],
        featured: true,
        active: true,
      },
      {
        id: 'srv-2',
        slug: 'basic-website',
        title: 'Basic Website',
        shortDescription:
          'A sharp, fast-loading business launch website built to establish immediate credibility online.',
        fullDescription:
          'Ideal for entrepreneurs, local businesses, and creators launching their first professional web presence with clean layouts, mobile optimization, and direct WhatsApp enquiry flows.',
        startingPrice: '₹5,999',
        iconName: 'Layout',
        imageUrl: ASSET_PATHS.webShowcase,
        deliverables: [
          'Editable package features managed via Admin Dashboard',
          'Mobile-first responsive design',
          'Direct WhatsApp & Contact form setup',
        ],
        featured: false,
        active: true,
      },
      {
        id: 'srv-3',
        slug: 'premium-website',
        title: 'Premium Website',
        shortDescription:
          'Multi-page interactive studio & brand website with custom motion, portfolio galleries, and elevated visual craft.',
        fullDescription:
          'Designed for scaling brands that need multi-page storytelling, interactive showcases, glassmorphism aesthetics, and structured lead conversion.',
        startingPrice: '₹9,999',
        iconName: 'Layers',
        imageUrl: ASSET_PATHS.webShowcase,
        deliverables: [
          'Editable package features managed via Admin Dashboard',
          'Multi-page architecture with smooth animations',
          'Enhanced SEO & social sharing setup',
        ],
        featured: true,
        active: true,
      },
      {
        id: 'srv-4',
        slug: 'pro-website',
        title: 'Pro Website',
        shortDescription:
          'Flagship custom web platform with full-control admin dashboard, media management, and enterprise polish.',
        fullDescription:
          'Our flagship digital studio build—engineered for ambitious brands seeking complete content ownership, dynamic showcases, custom animations, and full backend readiness.',
        startingPrice: '₹15,999',
        iconName: 'Crown',
        imageUrl: ASSET_PATHS.webShowcase,
        deliverables: [
          'Editable package features managed via Admin Dashboard',
          'Dynamic content & portfolio administration',
          'Priority launch consultation & optimization',
        ],
        featured: true,
        active: true,
      },
      {
        id: 'srv-5',
        slug: 'ai-video-creation',
        title: 'AI Video Creation',
        shortDescription:
          'Cinematic AI-directed brand films, product reveals, and high-retention short-form reels.',
        fullDescription:
          'Studio-directed AI video production combining photorealistic visual generation, dynamic camera pacing, color grading, and crisp motion graphics for Instagram Reels, YouTube, and product launches.',
        startingPrice: '₹2,499',
        iconName: 'Film',
        imageUrl: ASSET_PATHS.aiVideo,
        deliverables: [
          'Concept scripting & visual art direction',
          'HD / 4K vertical & widescreen deliverables',
          'Sound design, pacing, and branded title cards',
        ],
        featured: true,
        active: true,
      },
      {
        id: 'srv-6',
        slug: 'ai-song-creation',
        title: 'AI Song Creation',
        shortDescription:
          'Custom AI-composed brand anthems, commercial jingles, and cinematic studio soundtracks.',
        fullDescription:
          'Original musical identities tailored to your campaign mood—from energetic commercial jingles and creator intro themes to atmospheric scores crafted to make your brand instantly recognizable.',
        startingPrice: '₹1,499',
        iconName: 'Music',
        imageUrl: ASSET_PATHS.aiMusic,
        deliverables: [
          'Custom lyric direction & genre styling',
          'High-quality mastered WAV & MP3 tracks',
          'Short cutdowns for Reels and ad hooks',
        ],
        featured: false,
        active: true,
      },
      {
        id: 'srv-7',
        slug: 'ai-advertisements',
        title: 'AI Advertisements',
        shortDescription:
          'Scroll-stopping AI commercial ads engineered to capture attention and drive direct customer enquiries.',
        fullDescription:
          'High-contrast product commercials and visual ad creatives produced with AI cinematography—giving emerging brands luxury commercial aesthetics at a fraction of traditional shoot timelines.',
        startingPrice: '₹2,999',
        iconName: 'Clapperboard',
        imageUrl: ASSET_PATHS.aiVideo,
        deliverables: [
          'Ad hook scripting & visual storyboard',
          'Multiple aspect ratios (9:16, 1:1, 16:9)',
          'CTA end-cards optimized for paid campaigns',
        ],
        featured: true,
        active: true,
      },
      {
        id: 'srv-8',
        slug: 'ugc-ai-promotions',
        title: 'UGC AI Promotions',
        shortDescription:
          'Authentic, relatable AI-powered UGC promotional videos designed for social commerce conversion.',
        fullDescription:
          'Engaging spokesperson and lifestyle-style UGC promotional creatives crafted to feel native to Instagram and Facebook feeds while spotlighting your product benefits clearly.',
        startingPrice: '₹1,999',
        iconName: 'Sparkles',
        imageUrl: ASSET_PATHS.adCampaign,
        deliverables: [
          'Conversion-oriented UGC scriptwriting',
          'Natural pacing with bold kinetic captions',
          'Ready-to-run Reels & ad variations',
        ],
        featured: false,
        active: true,
      },
      {
        id: 'srv-9',
        slug: 'meta-ads',
        title: 'Meta Ads',
        shortDescription:
          'Targeted Facebook & Instagram advertising campaigns paired with high-performing studio creatives.',
        fullDescription:
          'Structured Meta Ads setup, audience targeting, creative testing, and conversion-focused ad assets built to turn ad spend into WhatsApp leads, website visits, and brand growth.',
        startingPrice: '₹3,999',
        iconName: 'Target',
        imageUrl: ASSET_PATHS.adCampaign,
        deliverables: [
          'Campaign architecture & audience segmentation',
          'Scroll-stopping ad visuals & copywriting',
          'Performance review & creative iteration guidance',
        ],
        featured: false,
        active: true,
      },
      {
        id: 'srv-10',
        slug: 'social-media-designs',
        title: 'Social Media Designs',
        shortDescription:
          'Cohesive Instagram carousels, posters, story kits, and grid systems that elevate brand recall.',
        fullDescription:
          'Editorial-grade social media visuals with consistent typography, color discipline, and high visual contrast so every post reinforces your studio-level positioning.',
        startingPrice: '₹1,999',
        iconName: 'Palette',
        imageUrl: ASSET_PATHS.adCampaign,
        deliverables: [
          'Custom carousel, post & story templates',
          'Consistent typography and color system',
          'Print & digital high-resolution exports',
        ],
        featured: false,
        active: true,
      },
      {
        id: 'srv-11',
        slug: 'business-promotions',
        title: 'Business Promotions',
        shortDescription:
          'Integrated digital launch packs uniting posters, promo videos, and WhatsApp lead funnels.',
        fullDescription:
          'Complete promotional campaigns crafted for grand openings, seasonal offers, product drops, and local-to-national business visibility across social channels.',
        startingPrice: '₹3,499',
        iconName: 'Megaphone',
        imageUrl: ASSET_PATHS.adCampaign,
        deliverables: [
          'Campaign visual kit (posters + reels)',
          'Offer messaging & call-to-action strategy',
          'Multi-platform rollout assets',
        ],
        featured: false,
        active: true,
      },
      {
        id: 'srv-12',
        slug: 'branding-and-creative-designs',
        title: 'Branding and Creative Designs',
        shortDescription:
          'Distinctive logos, visual identity systems, color direction, and luxury packaging concepts.',
        fullDescription:
          'Strategic brand identity design that gives your business a memorable visual signature—covering mark exploration, typography pairing, palette guidelines, and brand collateral.',
        startingPrice: '₹4,499',
        iconName: 'PenTool',
        imageUrl: ASSET_PATHS.adCampaign,
        deliverables: [
          'Primary logo & monogram lockups',
          'Color palette & typography system',
          'Brand collateral & social kit guidelines',
        ],
        featured: true,
        active: true,
      },
    ],
    pricingPackages: [
      {
        id: 'pkg-basic',
        name: 'BASIC WEBSITE',
        price: '₹5,999',
        audience: 'For freelancers, creators & local businesses',
        description:
          'Customize package deliverables directly in Admin Dashboard → Pricing Management.',
        features: [
          'Editable feature item — customize in Admin Dashboard',
          'Mobile-responsive business layout',
          'Direct WhatsApp & enquiry button integration',
        ],
        highlighted: false,
        whatsappPrompt: 'Hello ALVISH Studio, I would like to enquire about the BASIC WEBSITE (₹5,999) package.',
      },
      {
        id: 'pkg-premium',
        name: 'PREMIUM WEBSITE',
        price: '₹9,999',
        audience: 'For growing brands & creative studios',
        description:
          'Customize package deliverables directly in Admin Dashboard → Pricing Management.',
        features: [
          'Editable feature item — customize in Admin Dashboard',
          'Multi-page bespoke design & smooth animations',
          'Portfolio showcase, SEO metadata & WhatsApp funnel',
        ],
        highlighted: true,
        whatsappPrompt: 'Hello ALVISH Studio, I would like to enquire about the PREMIUM WEBSITE (₹9,999) package.',
      },
      {
        id: 'pkg-pro',
        name: 'PRO WEBSITE',
        price: '₹15,999',
        audience: 'For flagship brands needing full CMS control',
        description:
          'Customize package deliverables directly in Admin Dashboard → Pricing Management.',
        features: [
          'Editable feature item — customize in Admin Dashboard',
          'Full-control Admin Dashboard & media management',
          'Custom interactive architecture & priority studio support',
        ],
        highlighted: false,
        whatsappPrompt: 'Hello ALVISH Studio, I would like to enquire about the PRO WEBSITE (₹15,999) package.',
      },
    ],
    skills: [
      {
        id: 'sk-1',
        name: 'Website Design & UI/UX Architecture',
        category: 'Web & Interactive',
        percentage: 96,
        description: 'Responsive luxury interfaces, glassmorphism systems, and conversion-focused user journeys.',
      },
      {
        id: 'sk-2',
        name: 'AI Video Direction & Commercial Production',
        category: 'AI Media Production',
        percentage: 94,
        description: 'Cinematic AI storytelling, product visualizers, and high-retention commercial reels.',
      },
      {
        id: 'sk-3',
        name: 'Brand Identity & Creative Art Direction',
        category: 'Creative Design',
        percentage: 92,
        description: 'Distinctive brand marks, typography systems, posters, and cohesive social aesthetics.',
      },
      {
        id: 'sk-4',
        name: 'AI Song & Audio Identity Creation',
        category: 'AI Media Production',
        percentage: 89,
        description: 'Original brand jingles, cinematic intro scores, and custom AI musical production.',
      },
      {
        id: 'sk-5',
        name: 'Meta Ads & Performance Creatives',
        category: 'Growth & Marketing',
        percentage: 91,
        description: 'Paid social creative strategy, UGC AI promotions, and WhatsApp lead generation funnels.',
      },
      {
        id: 'sk-6',
        name: 'Frontend Engineering & Motion Systems',
        category: 'Web & Interactive',
        percentage: 93,
        description: 'Modern React, TypeScript, Tailwind CSS, and fluid GPU-composited web transitions.',
      },
    ],
    experience: [
      {
        id: 'exp-1',
        title: 'Founder & Creative Director',
        companyOrProject: 'ALVISH – Digital Creative Studio',
        description:
          'Leading end-to-end brand transformation, luxury website development, AI video commercials, AI music production, and Meta advertising campaigns for ambitious businesses and personal brands.',
        startDate: '2024',
        endDate: 'Present',
        highlights: [
          'Built multi-disciplinary digital studio spanning 12 specialized creative & AI services',
          'Delivered bespoke web design packages and full-funnel promotional campaigns',
          'Pioneered AI commercial video and UGC AI ad workflows for rapid client launches',
        ],
      },
      {
        id: 'exp-2',
        title: 'Independent Web Designer & Brand Strategist',
        companyOrProject: 'Freelance Client Engagements',
        description:
          'Partnered directly with startups, local enterprises, and digital creators to design responsive websites, visual identities, and high-contrast social media campaigns.',
        startDate: '2022',
        endDate: '2024',
        highlights: [
          'Designed responsive portfolio, service, and business launch websites',
          'Produced cohesive Instagram branding, promotional posters, and campaign kits',
          'Integrated direct WhatsApp enquiry funnels improving client response velocity',
        ],
      },
      {
        id: 'exp-3',
        title: 'Digital Media & Creative Visual Specialist',
        companyOrProject: 'Creative Production & Social Growth Projects',
        description:
          'Developed foundational craft across visual storytelling, motion graphics, promotional poster systems, and audience-first content design.',
        startDate: '2020',
        endDate: '2022',
        highlights: [
          'Mastered high-contrast dark-mode editorial aesthetics and typography',
          'Executed rapid-turnaround promotional graphics and short-form video edits',
        ],
      },
    ],
    portfolio: [
      {
        id: 'pf-1',
        title: 'Noir Atelier — Luxury Agency Web Experience',
        category: 'Website Designs',
        clientName: 'Studio Showcase',
        year: '2026',
        summary: 'Obsidian-and-crimson multi-page agency platform engineered with fluid motion and bespoke typography.',
        details:
          'A flagship dark-mode web experience showcasing architectural grid discipline, glassmorphism cards, fast initial rendering, and direct WhatsApp lead conversion flows.',
        imageUrl: ASSET_PATHS.webShowcase,
        metrics: 'Sub-1.5s load · Mobile & Desktop',
        featured: true,
        published: true,
        order: 1,
      },
      {
        id: 'pf-2',
        title: 'ONYX Eau de Parfum — Cinematic AI Film',
        category: 'AI Videos',
        clientName: 'Onyx Fragrance Concept',
        year: '2026',
        summary: 'Dramatic volcanic-smoke and crimson rim-lit AI product launch reel crafted for luxury social reach.',
        details:
          'Produced entirely through an AI cinema pipeline with custom lighting consistency, anamorphic lens grading, and synchronized sound design for 9:16 Reels and 16:9 hero banners.',
        imageUrl: ASSET_PATHS.aiVideo,
        metrics: '4K Cinema Render · 9:16 & 16:9',
        featured: true,
        published: true,
        order: 2,
      },
      {
        id: 'pf-3',
        title: 'Crimson Pulse — Custom Brand Anthem & Score',
        category: 'AI Songs',
        clientName: 'ALVISH Sonic Lab',
        year: '2026',
        summary: 'Original AI-composed atmospheric soundtrack and commercial hook designed for luxury visual reveals.',
        details:
          'Layered analog-style dark bass progressions, rhythmic pulses, and shimmering synth textures mastered for intros, brand trailers, and high-impact commercial advertisements.',
        imageUrl: ASSET_PATHS.aiMusic,
        metrics: 'Mastered WAV · Commercial License',
        featured: true,
        published: true,
        order: 3,
      },
      {
        id: 'pf-4',
        title: 'AETERNA — High-Conversion Ad Campaign',
        category: 'Advertisements',
        clientName: 'Aeterna Luxury Goods',
        year: '2026',
        summary: 'High-contrast dark packaging and crimson lacquer visual series built for Meta paid acquisition.',
        details:
          'Created a cohesive set of static and motion ad variants optimized for Instagram & Facebook feed performance, pairing bold visual contrast with clear direct-response CTAs.',
        imageUrl: ASSET_PATHS.adCampaign,
        metrics: 'Multi-Format Meta Ad Kit',
        featured: true,
        published: true,
        order: 4,
      },
      {
        id: 'pf-5',
        title: 'Midnight Launch — Editorial Campaign Poster',
        category: 'Posters',
        clientName: 'Brand Launch Series',
        year: '2025',
        summary: 'Bold sculptural poster series uniting obsidian surfaces, red foil accents, and sharp display type.',
        details:
          'Designed for digital billboards, WhatsApp broadcast promotions, and print-ready event announcements with unmistakable hierarchy.',
        imageUrl: ASSET_PATHS.adCampaign,
        metrics: 'Print & Digital 4K Suite',
        featured: false,
        published: true,
        order: 5,
      },
      {
        id: 'pf-6',
        title: 'Velocity Growth — Full Business Promo Pack',
        category: 'Business Promotions',
        clientName: 'Regional Retail Partner',
        year: '2025',
        summary: 'End-to-end promotional rollout combining landing page, AI ad spot, and WhatsApp enquiry automation.',
        details:
          'Coordinated seasonal campaign graphics, promotional video hooks, and direct click-to-WhatsApp landing experience to streamline customer inquiries.',
        imageUrl: ASSET_PATHS.webShowcase,
        metrics: 'Integrated Web + Promo Funnel',
        featured: false,
        published: true,
        order: 6,
      },
      {
        id: 'pf-7',
        title: 'Monolith Grid — Social Media Design System',
        category: 'Social Media Designs',
        clientName: 'Creator & Brand Suite',
        year: '2026',
        summary: 'Cohesive Instagram carousel architecture, story layouts, and highlight covers in obsidian crimson.',
        details:
          'A scalable visual design system ensuring every post, reel cover, and story frame communicates high-end creative authority.',
        imageUrl: ASSET_PATHS.aiVideo,
        metrics: '30-Asset Monthly System',
        featured: false,
        published: true,
        order: 7,
      },
    ],
    achievements: [
      {
        id: 'ach-1',
        title: 'ALVISH Studio Launch & Full-Stack Creative Milestone',
        issuer: 'ALVISH – Digital Creative Studio',
        kind: 'Milestone',
        dateLabel: '2026',
        description:
          'Established a complete multi-disciplinary studio uniting bespoke web design, AI video commercials, AI song creation, and Meta advertising under one luxury brand system.',
        imageUrl: ASSET_PATHS.achievementAward,
      },
      {
        id: 'ach-2',
        title: 'Generative AI Commercial Production Mastery',
        issuer: 'Creative AI Production Track',
        kind: 'Certificate',
        dateLabel: '2025',
        description:
          'Recognized specialization in cinematic AI video direction, UGC AI promotions, and commercial brand storytelling pipelines.',
        imageUrl: ASSET_PATHS.aiVideo,
      },
      {
        id: 'ach-3',
        title: 'Digital Performance & Meta Ads Craftsmanship',
        issuer: 'Performance Creative Practice',
        kind: 'Recognition',
        dateLabel: '2025',
        description:
          'Proven execution across conversion-focused ad creatives, audience campaign architecture, and direct WhatsApp lead funnels.',
        imageUrl: ASSET_PATHS.adCampaign,
      },
      {
        id: 'ach-4',
        title: 'Modern Responsive Web Engineering Excellence',
        issuer: 'Web Design & UI Architecture',
        kind: 'Award',
        dateLabel: '2024',
        description:
          'Crafting sub-2-second loading interactive websites with glassmorphism UI, semantic SEO, and mobile-first precision.',
        imageUrl: ASSET_PATHS.webShowcase,
      },
    ],
    testimonials: [
      {
        id: 'test-1',
        clientName: 'Demo Client — Retail Brand Founder',
        clientRole: 'Founder',
        clientCompany: 'Sample Showcase Brand',
        clientAvatarUrl: ASSET_PATHS.adCampaign,
        reviewText:
          'Sample demo review — replace with verified client feedback in Admin Dashboard. ALVISH transformed our digital storefront and promotional reels with a sharp luxury look and smooth WhatsApp enquiry flow.',
        rating: 5,
        isDemo: true,
        published: true,
      },
      {
        id: 'test-2',
        clientName: 'Demo Client — Creative Entrepreneur',
        clientRole: 'Director',
        clientCompany: 'Sample Studio Partner',
        clientAvatarUrl: ASSET_PATHS.webShowcase,
        reviewText:
          'Sample demo review — replace with verified client feedback in Admin Dashboard. Fast communication, striking dark-mode design discipline, and AI commercial visuals that immediately stood out in our Meta campaigns.',
        rating: 5,
        isDemo: true,
        published: true,
      },
      {
        id: 'test-3',
        clientName: 'Demo Client — E-Commerce Lead',
        clientRole: 'Marketing Head',
        clientCompany: 'Sample D2C Label',
        clientAvatarUrl: ASSET_PATHS.aiVideo,
        reviewText:
          'Sample demo review — replace with verified client feedback in Admin Dashboard. From our website redesign to custom AI product ads and jingle production, every deliverable arrived on schedule and ready to publish.',
        rating: 5,
        isDemo: true,
        published: true,
      },
    ],
    contact: {
      studioName: 'ALVISH',
      subName: 'DIGITAL CREATIVE STUDIO',
      whatsappNumber: '8247206736',
      whatsappDisplay: '+91 82472 06736',
      whatsappLink: 'https://wa.me/918247206736',
      instagramHandle: 'alvish_studios_dwm',
      instagramUrl: 'https://instagram.com/alvish_studios_dwm',
      email: 'contact@alvishstudios.com',
      location: 'India · Working Worldwide',
      availabilityText: 'Open for select web design, AI production & branding commissions.',
    },
    socialLinks: {
      whatsapp: 'https://wa.me/918247206736',
      instagram: 'https://instagram.com/alvish_studios_dwm',
      youtube: '',
      linkedin: '',
      behance: '',
      x: '',
    },
    intro: {
      enabled: true,
      tagline: "LET'S CREATE SOMETHING AMAZING",
      durationMs: 4200,
      showParticles: true,
      skipButtonVisible: true,
    },
    music: {
      enabled: true,
      trackUrl: ASSET_PATHS.introAudio,
      trackTitle: 'ALVISH Studio Background Track',
      attemptAutoplay: true,
      loop: false,
      defaultVolume: 0.55,
    },
    theme: {
      backgroundColor: '#050505',
      surfaceColor: '#101010',
      accentColor: '#FF1744',
      deepAccentColor: '#8B0000',
      textColor: '#FFFFFF',
      glassBlurPx: 18,
      enableParticles: true,
      enableAnimations: true,
      sectionVisibility: {
        featuredWork: true,
        pricingPackages: true,
        testimonials: true,
        achievements: true,
        introAnimation: true,
      },
    },
    navigation: [
      { id: 'nav-1', label: 'Home', path: '/', visible: true, order: 1 },
      { id: 'nav-2', label: 'About', path: '/about', visible: true, order: 2 },
      { id: 'nav-3', label: 'Services', path: '/services', visible: true, order: 3 },
      { id: 'nav-4', label: 'Skills', path: '/skills', visible: true, order: 4 },
      { id: 'nav-5', label: 'Experience', path: '/experience', visible: true, order: 5 },
      { id: 'nav-6', label: 'Portfolio', path: '/portfolio', visible: true, order: 6 },
      { id: 'nav-7', label: 'Achievements', path: '/achievements', visible: true, order: 7 },
      { id: 'nav-8', label: 'Testimonials', path: '/testimonials', visible: true, order: 8 },
      { id: 'nav-9', label: 'Contact', path: '/contact', visible: true, order: 9 },
    ],
    seo: {
      siteTitle: 'ALVISH – Digital Creative Studio | Websites, AI Media & Branding',
      metaDescription:
        'ALVISH – Digital Creative Studio. Freelancer & Entrepreneur creating modern websites, AI videos, AI songs, Meta ads, and luxury creative branding that help brands grow.',
      keywords:
        'ALVISH, Digital Creative Studio, Website Designing, AI Video Creation, AI Song Creation, Meta Ads, UGC AI Promotions, Branding',
      ogImageUrl: ASSET_PATHS.portrait,
    },
  };
}
