import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildWhatsAppUrl,
  clampPercentage,
  isSafeUrl,
  safeHref,
  validateAdminPassword,
  validateBackupPayload,
  validateContactForm,
} from './validation';
import { createDefaultSiteContent } from './defaultData';
import {
  RateLimiter,
  SessionManager,
  constantTimeStringEqual,
  hashPassword,
  verifyPassword,
} from '../server/auth';

test('validateContactForm rejects empty or invalid fields and accepts valid enquiry', () => {
  const invalid = validateContactForm({
    name: 'A',
    phone: '123',
    email: 'not-an-email',
    message: 'Hi',
  });
  assert.equal(invalid.valid, false);
  assert.ok(invalid.errors.name);
  assert.ok(invalid.errors.phone);
  assert.ok(invalid.errors.email);
  assert.ok(invalid.errors.message);

  const valid = validateContactForm({
    name: 'Rohan Sharma',
    phone: '+91 9876543210',
    email: 'rohan@brand.in',
    message: 'We need a Premium Website and AI commercial video for our upcoming launch.',
  });
  assert.equal(valid.valid, true);
  assert.deepEqual(valid.errors, {});
});

test('isSafeUrl and safeHref block javascript: and data: schemes', () => {
  assert.equal(isSafeUrl('https://wa.me/918247206736'), true);
  assert.equal(isSafeUrl('/portfolio'), true);
  assert.equal(isSafeUrl('javascript:alert(1)'), false);
  assert.equal(isSafeUrl('data:text/html,<script>alert(1)</script>'), false);
  assert.equal(isSafeUrl('//evil.example/path'), false);
  assert.equal(safeHref('javascript:void(0)', '/'), '/');
});

test('validateAdminPassword enforces minimum length and complexity', () => {
  assert.equal(validateAdminPassword('short1').valid, false);
  assert.equal(validateAdminPassword('onlyletters').valid, false);
  assert.equal(validateAdminPassword('AlvishStudio2026').valid, true);
});

test('clampPercentage clamps values between 0 and 100', () => {
  assert.equal(clampPercentage(125), 100);
  assert.equal(clampPercentage(-12), 0);
  assert.equal(clampPercentage(88.6), 89);
});

test('buildWhatsAppUrl encodes enquiry text safely', () => {
  const url = buildWhatsAppUrl('https://wa.me/918247206736', 'Hello ALVISH');
  assert.equal(url, 'https://wa.me/918247206736?text=Hello%20ALVISH');
});

test('validateBackupPayload accepts valid studio snapshot and rejects malformed JSON', () => {
  const defaults = createDefaultSiteContent();
  assert.equal(validateBackupPayload({ published: defaults }).valid, true);
  assert.equal(validateBackupPayload({ foo: 'bar' }).valid, false);
  assert.equal(validateBackupPayload(null).valid, false);
});

test('scrypt password hashing, session verification, and rate limiting work accurately', () => {
  const hash = hashPassword('StudioPass2026');
  assert.equal(verifyPassword('StudioPass2026', hash), true);
  assert.equal(verifyPassword('WrongPass2026', hash), false);
  assert.equal(constantTimeStringEqual('abc', 'abc'), true);
  assert.equal(constantTimeStringEqual('abc', 'abcd'), false);

  const sessions = new SessionManager();
  const s = sessions.create('admin@alvishstudios.com');
  assert.equal(sessions.verify(s.token)?.email, 'admin@alvishstudios.com');
  sessions.revoke(s.token);
  assert.equal(sessions.verify(s.token), null);

  const limiter = new RateLimiter(2, 60_000);
  assert.equal(limiter.check('1.2.3.4').allowed, true);
  limiter.recordAttempt('1.2.3.4');
  limiter.recordAttempt('1.2.3.4');
  assert.equal(limiter.check('1.2.3.4').allowed, false);
  limiter.reset('1.2.3.4');
  assert.equal(limiter.check('1.2.3.4').allowed, true);
});
