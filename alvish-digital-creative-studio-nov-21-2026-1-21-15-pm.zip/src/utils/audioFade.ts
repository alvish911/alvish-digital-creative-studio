export const DEFAULT_FADE_IN_MS = 1800;
export const UNMUTE_FADE_IN_MS = 450;

/**
 * Computes a smooth cubic ease-out volume level for fade-in playback.
 */
export function computeFadeVolume(
  elapsedMs: number,
  durationMs: number,
  targetVolume: number,
): number {
  const safeTarget = Number.isFinite(targetVolume)
    ? Math.max(0, Math.min(1, targetVolume))
    : 0.45;
  if (safeTarget === 0) return 0;
  if (!Number.isFinite(durationMs) || durationMs <= 0) return safeTarget;
  if (!Number.isFinite(elapsedMs) || elapsedMs <= 0) return 0;

  const progress = Math.min(1, elapsedMs / durationMs);
  const eased = 1 - Math.pow(1 - progress, 3);
  return Math.max(0, Math.min(safeTarget, Number((eased * safeTarget).toFixed(4))));
}
