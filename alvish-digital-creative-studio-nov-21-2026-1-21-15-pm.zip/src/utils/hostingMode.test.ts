import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildNetlifyFormBody,
  isJsonApiResponse,
  isJsonContentType,
} from './hostingMode';

test('isJsonContentType distinguishes JSON API responses from SPA HTML fallbacks', () => {
  assert.equal(isJsonContentType('application/json; charset=utf-8'), true);
  assert.equal(isJsonContentType('application/json'), true);
  assert.equal(isJsonContentType('text/html; charset=utf-8'), false);
  assert.equal(isJsonContentType(null), false);
  assert.equal(isJsonContentType(''), false);
});

test('isJsonApiResponse inspects response headers safely', () => {
  assert.equal(
    isJsonApiResponse({
      ok: true,
      status: 200,
      headers: { get: (k) => (k.toLowerCase() === 'content-type' ? 'application/json' : null) },
    }),
    true,
  );
  assert.equal(
    isJsonApiResponse({
      ok: true,
      status: 200,
      headers: { get: (k) => (k.toLowerCase() === 'content-type' ? 'text/html; charset=UTF-8' : null) },
    }),
    false,
  );
});

test('buildNetlifyFormBody encodes form-name and fields properly', () => {
  const encoded = buildNetlifyFormBody('contact', {
    name: 'Aarav Sharma',
    phone: '+91 98765 43210',
    email: 'aarav@example.com',
    message: 'Need a website & AI ad!',
  });
  const parsed = new URLSearchParams(encoded);
  assert.equal(parsed.get('form-name'), 'contact');
  assert.equal(parsed.get('name'), 'Aarav Sharma');
  assert.equal(parsed.get('phone'), '+91 98765 43210');
  assert.equal(parsed.get('email'), 'aarav@example.com');
  assert.equal(parsed.get('message'), 'Need a website & AI ad!');
});
