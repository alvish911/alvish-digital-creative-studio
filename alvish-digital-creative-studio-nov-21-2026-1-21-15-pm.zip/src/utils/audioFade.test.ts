import test from 'node:test';
import assert from 'node:assert/strict';
import { computeFadeVolume } from './audioFade';

test('computeFadeVolume starts at 0 and reaches targetVolume smoothly', () => {
  assert.equal(computeFadeVolume(0, 1800, 0.5), 0);
  const quarter = computeFadeVolume(450, 1800, 0.5);
  const half = computeFadeVolume(900, 1800, 0.5);
  const full = computeFadeVolume(1800, 1800, 0.5);
  assert.ok(quarter > 0 && quarter < half);
  assert.ok(half > quarter && half < 0.5);
  assert.equal(full, 0.5);
});

test('computeFadeVolume clamps out-of-range inputs safely', () => {
  assert.equal(computeFadeVolume(-100, 1800, 0.6), 0);
  assert.equal(computeFadeVolume(5000, 1800, 0.6), 0.6);
  assert.equal(computeFadeVolume(900, 1800, 2.5), 0.875);
  assert.equal(computeFadeVolume(900, 0, 0.4), 0.4);
  assert.equal(computeFadeVolume(900, 1800, 0), 0);
});
