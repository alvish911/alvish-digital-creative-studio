import type { ContactEnquiry } from '../shared/types';

export interface ResponseLike {
  ok: boolean;
  status: number;
  headers: {
    get(name: string): string | null;
  };
}

const LOCAL_ENQUIRIES_KEY = 'alvish_static_enquiries_v1';

/**
 * Returns true when an HTTP response carries an application/json content type.
 * On static hosts (Netlify / Vercel) with SPA rewrites, requests to /api/*
 * resolve to index.html (text/html), so checking the content-type prevents
 * JSON parse exceptions and cleanly detects static hosting mode.
 */
export function isJsonContentType(contentType: string | null | undefined): boolean {
  if (!contentType) return false;
  return contentType.toLowerCase().includes('application/json');
}

export function isJsonApiResponse(res: ResponseLike): boolean {
  return isJsonContentType(res.headers.get('content-type'));
}

export async function readJsonApiResponse<T>(
  res: Response,
): Promise<{ isJson: boolean; ok: boolean; status: number; data: T | null }> {
  const isJson = isJsonApiResponse(res);
  if (!isJson) {
    return { isJson: false, ok: false, status: res.status, data: null };
  }
  try {
    const data = (await res.json()) as T;
    return { isJson: true, ok: res.ok, status: res.status, data };
  } catch {
    return { isJson: false, ok: false, status: res.status, data: null };
  }
}

/**
 * Encodes a contact submission as x-www-form-urlencoded for Netlify Forms.
 */
export function buildNetlifyFormBody(
  formName: string,
  fields: Record<string, string>,
): string {
  const params = new URLSearchParams();
  params.set('form-name', formName);
  for (const [key, value] of Object.entries(fields)) {
    params.set(key, value);
  }
  return params.toString();
}

/**
 * Saves a contact enquiry locally when the site is deployed on static hosting
 * without a Node/Express backend.
 */
export function saveStaticEnquiry(input: {
  name: string;
  phone: string;
  email: string;
  message: string;
}): ContactEnquiry {
  const entry: ContactEnquiry = {
    id: `enq-static-${Date.now()}`,
    name: input.name,
    phone: input.phone,
    email: input.email,
    message: input.message,
    status: 'new',
    createdAt: new Date().toISOString(),
  };

  try {
    const existingRaw = window.localStorage.getItem(LOCAL_ENQUIRIES_KEY);
    const existing: ContactEnquiry[] = existingRaw ? JSON.parse(existingRaw) : [];
    const next = [entry, ...existing].slice(0, 50);
    window.localStorage.setItem(LOCAL_ENQUIRIES_KEY, JSON.stringify(next));
  } catch {
    // Ignore storage quota or private browsing errors
  }

  return entry;
}
