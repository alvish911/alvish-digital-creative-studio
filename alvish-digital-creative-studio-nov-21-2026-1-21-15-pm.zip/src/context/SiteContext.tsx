import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import type { SiteContent } from '../shared/types';
import { createDefaultSiteContent } from '../shared/defaultData';
import { readJsonApiResponse } from '../utils/hostingMode';

interface SiteContextValue {
  site: SiteContent;
  loading: boolean;
  error: string | null;
  isPreviewMode: boolean;
  refreshSite: () => Promise<void>;
  setPreviewContent: (draft: SiteContent | null) => void;
}

const SiteContext = createContext<SiteContextValue | null>(null);

export const SiteProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [publishedSite, setPublishedSite] = useState<SiteContent>(() => createDefaultSiteContent());
  const [previewDraft, setPreviewDraft] = useState<SiteContent | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refreshSite = useCallback(async () => {
    try {
      const res = await fetch('/api/site', { headers: { Accept: 'application/json' } });
      const parsed = await readJsonApiResponse<SiteContent>(res);
      if (parsed.isJson && parsed.ok && parsed.data) {
        setPublishedSite(parsed.data);
        setError(null);
      } else {
        // Static hosting mode (e.g., Netlify / Vercel static build): use bundled studio content silently
        setError(null);
      }
    } catch {
      // Static hosting or offline fallback: default studio content is already active
      setError(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refreshSite();
  }, [refreshSite]);

  const activeSite = previewDraft ?? publishedSite;

  // Apply dynamic theme CSS variables whenever published or preview theme updates
  useEffect(() => {
    const root = document.documentElement;
    const t = activeSite.theme;
    root.style.setProperty('--studio-bg', t.backgroundColor || '#050505');
    root.style.setProperty('--studio-surface', t.surfaceColor || '#101010');
    root.style.setProperty('--studio-accent', t.accentColor || '#FF1744');
    root.style.setProperty('--studio-accent-deep', t.deepAccentColor || '#8B0000');
    root.style.setProperty('--studio-text', t.textColor || '#FFFFFF');
    root.style.setProperty('--studio-glass-blur', `${Math.max(0, Math.min(36, t.glassBlurPx ?? 18))}px`);
  }, [activeSite.theme]);

  return (
    <SiteContext.Provider
      value={{
        site: activeSite,
        loading,
        error,
        isPreviewMode: Boolean(previewDraft),
        refreshSite,
        setPreviewContent: setPreviewDraft,
      }}
    >
      {children}
    </SiteContext.Provider>
  );
};

export function useSite(): SiteContextValue {
  const ctx = useContext(SiteContext);
  if (!ctx) throw new Error('useSite must be used inside SiteProvider');
  return ctx;
}
