import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { useSite } from './SiteContext';
import {
  DEFAULT_FADE_IN_MS,
  UNMUTE_FADE_IN_MS,
  computeFadeVolume,
} from '../utils/audioFade';

interface AudioContextValue {
  isPlaying: boolean;
  isMuted: boolean;
  autoplayBlocked: boolean;
  volume: number;
  enableAudio: () => Promise<void>;
  toggleMute: () => void;
  setVolume: (next: number) => void;
}

const AudioContext = createContext<AudioContextValue | null>(null);

export const AudioProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { site } = useSite();
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const fadeRafRef = useRef<number | null>(null);
  const attemptedSrcRef = useRef<string>('');
  const currentSrcRef = useRef<string>('');

  const defaultVol =
    typeof site.music.defaultVolume === 'number'
      ? Math.max(0, Math.min(1, site.music.defaultVolume))
      : 0.55;

  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [autoplayBlocked, setAutoplayBlocked] = useState(false);
  const [volume, setVolumeState] = useState<number>(defaultVol);
  const volumeRef = useRef<number>(defaultVol);

  useEffect(() => {
    volumeRef.current = volume;
  }, [volume]);

  const cancelFade = useCallback(() => {
    if (fadeRafRef.current !== null) {
      window.cancelAnimationFrame(fadeRafRef.current);
      fadeRafRef.current = null;
    }
  }, []);

  const startFadeIn = useCallback(
    (audio: HTMLAudioElement, targetVolume: number, durationMs = DEFAULT_FADE_IN_MS) => {
      cancelFade();
      const clampedTarget = Math.max(0, Math.min(1, targetVolume));
      const reducedMotion =
        typeof window !== 'undefined' &&
        window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

      if (reducedMotion || durationMs <= 0) {
        try {
          audio.volume = clampedTarget;
        } catch {
          // Read-only volume on iOS Safari
        }
        return;
      }

      try {
        audio.volume = 0;
      } catch {
        // Read-only volume on iOS Safari — playback continues normally
        return;
      }

      const startTime = performance.now();
      const tick = (now: number) => {
        if (audio.paused || audio.muted) {
          fadeRafRef.current = null;
          return;
        }
        const elapsed = now - startTime;
        const nextVol = computeFadeVolume(elapsed, durationMs, clampedTarget);
        try {
          audio.volume = nextVol;
        } catch {
          fadeRafRef.current = null;
          return;
        }
        if (elapsed < durationMs) {
          fadeRafRef.current = window.requestAnimationFrame(tick);
        } else {
          fadeRafRef.current = null;
        }
      };

      fadeRafRef.current = window.requestAnimationFrame(tick);
    },
    [cancelFade],
  );

  const ensureAudioElement = useCallback((): HTMLAudioElement => {
    let audio = audioRef.current;
    if (!audio) {
      audio = new Audio();
      audio.preload = 'auto';
      audio.setAttribute('playsinline', '');
      audio.setAttribute('webkit-playsinline', '');
      audio.addEventListener('play', () => setIsPlaying(true));
      audio.addEventListener('pause', () => {
        cancelFade();
        setIsPlaying(false);
      });
      audio.addEventListener('ended', () => {
        cancelFade();
        setIsPlaying(false);
      });
      audioRef.current = audio;
    }
    return audio;
  }, [cancelFade]);

  // Cleanup fade animation frame on unmount
  useEffect(() => {
    return () => {
      cancelFade();
    };
  }, [cancelFade]);

  // Maintain one persistent HTMLAudioElement from the intro screen across all pages without restarting
  useEffect(() => {
    if (!site.music.enabled || !site.music.trackUrl) {
      if (audioRef.current) {
        cancelFade();
        audioRef.current.pause();
        setIsPlaying(false);
      }
      return;
    }

    const audio = ensureAudioElement();
    audio.loop = Boolean(site.music.loop);
    audio.muted = isMuted;

    // Only update src when the configured track actually changes (never restart on route transitions)
    if (currentSrcRef.current !== site.music.trackUrl) {
      currentSrcRef.current = site.music.trackUrl;
      audio.src = site.music.trackUrl;
      audio.load();
    }

    if (site.music.attemptAutoplay && attemptedSrcRef.current !== site.music.trackUrl) {
      attemptedSrcRef.current = site.music.trackUrl;
      try {
        audio.volume = 0;
      } catch {
        // Ignore on devices with hardware-only volume
      }

      const playPromise = audio.play();
      if (playPromise && typeof playPromise.then === 'function') {
        playPromise
          .then(() => {
            setAutoplayBlocked(false);
            setIsPlaying(true);
            if (!audio.muted) {
              startFadeIn(audio, volumeRef.current, DEFAULT_FADE_IN_MS);
            }
          })
          .catch(() => {
            setAutoplayBlocked(true);
            setIsPlaying(false);
          });
      }
    }
  }, [
    site.music.enabled,
    site.music.trackUrl,
    site.music.loop,
    site.music.attemptAutoplay,
    isMuted,
    ensureAudioElement,
    cancelFade,
    startFadeIn,
  ]);

  // Synchronously trigger play inside click gesture for mobile Safari & Chrome reliability
  const enableAudio = useCallback(async () => {
    if (!site.music.enabled || !site.music.trackUrl) return;
    const audio = ensureAudioElement();
    if (currentSrcRef.current !== site.music.trackUrl) {
      currentSrcRef.current = site.music.trackUrl;
      audio.src = site.music.trackUrl;
    }
    audio.loop = Boolean(site.music.loop);
    audio.muted = false;
    setIsMuted(false);

    const isFreshStart = audio.paused;
    if (isFreshStart) {
      try {
        audio.volume = 0;
      } catch {
        // Hardware-controlled volume on iOS
      }
    }

    try {
      await audio.play();
      setAutoplayBlocked(false);
      setIsPlaying(true);
      startFadeIn(
        audio,
        volumeRef.current,
        isFreshStart ? DEFAULT_FADE_IN_MS : UNMUTE_FADE_IN_MS,
      );
    } catch {
      setAutoplayBlocked(true);
      setIsPlaying(false);
    }
  }, [site.music.enabled, site.music.trackUrl, site.music.loop, ensureAudioElement, startFadeIn]);

  const toggleMute = useCallback(() => {
    const audio = audioRef.current;
    if (!audio || audio.paused || autoplayBlocked) {
      void enableAudio();
      return;
    }
    if (isMuted) {
      audio.muted = false;
      setIsMuted(false);
      startFadeIn(audio, volumeRef.current, UNMUTE_FADE_IN_MS);
    } else {
      cancelFade();
      audio.muted = true;
      setIsMuted(true);
    }
  }, [isMuted, autoplayBlocked, enableAudio, startFadeIn, cancelFade]);

  const setVolume = useCallback(
    (next: number) => {
      const clamped = Math.max(0, Math.min(1, next));
      cancelFade();
      setVolumeState(clamped);
      volumeRef.current = clamped;
      if (audioRef.current) {
        try {
          audioRef.current.volume = clamped;
        } catch {
          // Hardware-controlled volume on iOS
        }
      }
    },
    [cancelFade],
  );

  return (
    <AudioContext.Provider
      value={{
        isPlaying,
        isMuted,
        autoplayBlocked,
        volume,
        enableAudio,
        toggleMute,
        setVolume,
      }}
    >
      {children}
    </AudioContext.Provider>
  );
};

export function useStudioAudio(): AudioContextValue {
  const ctx = useContext(AudioContext);
  if (!ctx) throw new Error('useStudioAudio must be used inside AudioProvider');
  return ctx;
}
