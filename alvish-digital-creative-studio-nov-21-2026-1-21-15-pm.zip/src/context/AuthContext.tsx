import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import type { AdminAuthStatus } from '../shared/types';
import { readJsonApiResponse } from '../utils/hostingMode';

interface AuthContextValue {
  token: string | null;
  status: AdminAuthStatus;
  checking: boolean;
  authHeaders: () => Record<string, string>;
  refreshStatus: (overrideToken?: string | null) => Promise<AdminAuthStatus>;
  login: (email: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  bootstrap: (email: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Held strictly in React memory — never written to localStorage or sessionStorage
  const [token, setToken] = useState<string | null>(null);
  const [checking, setChecking] = useState(true);
  const [status, setStatus] = useState<AdminAuthStatus>({
    authenticated: false,
    needsBootstrap: false,
    envManaged: false,
    email: null,
  });

  const refreshStatus = useCallback(
    async (overrideToken?: string | null): Promise<AdminAuthStatus> => {
      const activeToken = overrideToken !== undefined ? overrideToken : token;
      try {
        const res = await fetch('/api/admin/auth/status', {
          headers: activeToken ? { Authorization: `Bearer ${activeToken}` } : {},
        });
        const parsed = await readJsonApiResponse<AdminAuthStatus>(res);
        if (!parsed.isJson || !parsed.ok || !parsed.data) {
          const fallback: AdminAuthStatus = {
            authenticated: false,
            needsBootstrap: false,
            envManaged: false,
            email: null,
          };
          setStatus(fallback);
          return fallback;
        }
        const data = parsed.data;
        setStatus(data);
        if (!data.authenticated && activeToken) {
          setToken(null);
        }
        return data;
      } catch {
        const fallback: AdminAuthStatus = {
          authenticated: false,
          needsBootstrap: false,
          envManaged: false,
          email: null,
        };
        setStatus(fallback);
        return fallback;
      } finally {
        setChecking(false);
      }
    },
    [token],
  );

  useEffect(() => {
    void refreshStatus();
  }, [refreshStatus]);

  const authHeaders = useCallback((): Record<string, string> => {
    return token ? { Authorization: `Bearer ${token}` } : {};
  }, [token]);

  const login = useCallback(
    async (email: string, password: string) => {
      try {
        const res = await fetch('/api/admin/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password }),
        });
        const parsed = await readJsonApiResponse<{ token?: string; error?: string }>(res);
        if (!parsed.isJson) {
          return {
            ok: false,
            error:
              'Admin authentication requires the Node.js backend server (npm start). Static hosting serves the public portfolio website.',
          };
        }
        if (!parsed.ok || !parsed.data?.token) {
          return { ok: false, error: parsed.data?.error || 'Sign-in failed.' };
        }
        setToken(parsed.data.token);
        await refreshStatus(parsed.data.token);
        return { ok: true };
      } catch {
        return { ok: false, error: 'Network error while signing in.' };
      }
    },
    [refreshStatus],
  );

  const bootstrap = useCallback(
    async (email: string, password: string) => {
      try {
        const res = await fetch('/api/admin/auth/bootstrap', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password }),
        });
        const parsed = await readJsonApiResponse<{ token?: string; error?: string }>(res);
        if (!parsed.isJson) {
          return {
            ok: false,
            error:
              'Admin setup requires the Node.js backend server (npm start). Static hosting serves the public portfolio website.',
          };
        }
        if (!parsed.ok || !parsed.data?.token) {
          return { ok: false, error: parsed.data?.error || 'Admin setup failed.' };
        }
        setToken(parsed.data.token);
        await refreshStatus(parsed.data.token);
        return { ok: true };
      } catch {
        return { ok: false, error: 'Network error while completing admin setup.' };
      }
    },
    [refreshStatus],
  );

  const logout = useCallback(async () => {
    const previousToken = token;
    setToken(null);
    setStatus((prev) => ({ ...prev, authenticated: false, email: null }));
    if (previousToken) {
      try {
        await fetch('/api/admin/auth/logout', {
          method: 'POST',
          headers: { Authorization: `Bearer ${previousToken}` },
        });
      } catch {
        // Proceed with client logout even if request fails
      }
    }
    await refreshStatus(null);
  }, [token, refreshStatus]);

  return (
    <AuthContext.Provider
      value={{
        token,
        status,
        checking,
        authHeaders,
        refreshStatus,
        login,
        bootstrap,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
