import React, { useState } from 'react';
import { MessageCircle, Check, X, ArrowUpRight } from 'lucide-react';
import { PageShell } from '../components/PageShell';
import { SafeImage } from '../components/SafeImage';
import { ServiceIcon } from '../components/ServiceIcon';
import { useSite } from '../context/SiteContext';
import type { ServiceItem } from '../shared/types';
import { buildWhatsAppUrl, safeHref } from '../shared/validation';

export const ServicesPage: React.FC = () => {
  const { site } = useSite();
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);

  const activeServices = site.services.filter((s) => s.active);

  return (
    <PageShell
      title="Services"
      description="Explore all 12 digital services and Website Design Packages (Basic ₹5,999, Premium ₹9,999, Pro ₹15,999) from ALVISH – Digital Creative Studio."
    >
      {/* Header */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-14 pb-10 lg:pt-20">
        <p className="text-xs font-semibold tracking-[0.24em] text-[#FF1744]">
          Studio Capabilities
        </p>
        <h1 className="mt-3 font-display text-4xl sm:text-5xl font-extrabold tracking-tight text-white text-balance">
          Digital Services Built to Grow Brands
        </h1>
        <p className="mt-4 max-w-2xl text-base text-zinc-400">
          Every service below is crafted directly by ALVISH – Digital Creative Studio, uniting luxury design aesthetics with high-conversion commercial execution.
        </p>
      </section>

      {/* 12 Services Grid */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pb-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {activeServices.map((service, idx) => (
            <article
              key={service.id}
              className="group glass-panel glass-panel-hover rounded-2xl overflow-hidden flex flex-col justify-between"
            >
              <div>
                <div className="relative h-44 w-full overflow-hidden bg-[#101010]">
                  <SafeImage
                    src={service.imageUrl}
                    alt={service.title}
                    className="h-full w-full object-cover opacity-85 transition-transform duration-500 group-hover:scale-105"
                  />
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#0d0d0f] via-[#0d0d0f]/35 to-transparent"
                  />
                  <div className="absolute left-5 bottom-4 flex items-center gap-3">
                    <span className="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-[#050505]/85 border border-[#FF1744]/40 text-[#FF1744]">
                      <ServiceIcon name={service.iconName} />
                    </span>
                    <span className="font-mono-tabular text-xs text-zinc-300">
                      {String(idx + 1).padStart(2, '0')} · Starting {service.startingPrice}
                    </span>
                  </div>
                </div>

                <div className="p-6">
                  <h2 className="font-display text-xl font-bold text-white">
                    {service.title}
                  </h2>
                  <p className="mt-2.5 text-sm leading-relaxed text-zinc-400">
                    {service.shortDescription}
                  </p>
                </div>
              </div>

              <div className="px-6 pb-6 pt-2 flex flex-wrap items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => setSelectedService(service)}
                  aria-label={`View details for ${service.title}`}
                  className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-lg border border-white/15 bg-white/[0.04] px-4 py-2.5 text-xs font-semibold text-white hover:border-[#FF1744]/50 transition-colors cursor-pointer whitespace-nowrap"
                >
                  <span>View Details</span>
                  <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
                </button>
                <a
                  href={safeHref(
                    buildWhatsAppUrl(
                      site.contact.whatsappLink,
                      `Hello ALVISH Studio, I am interested in ${service.title} (starting ${service.startingPrice}).`,
                    ),
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="crimson-glow-btn inline-flex flex-1 items-center justify-center gap-1.5 rounded-lg px-4 py-2.5 text-xs font-semibold text-white whitespace-nowrap"
                >
                  <MessageCircle className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Contact on WhatsApp</span>
                </a>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* Website Design Packages Section */}
      {site.theme.sectionVisibility.pricingPackages && (
        <section
          id="packages"
          className="border-t border-white/[0.08] py-16 lg:py-24"
        >
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="max-w-2xl">
              <p className="text-xs font-semibold tracking-[0.24em] text-[#FF1744]">
                Website Design Packages
              </p>
              <h2 className="mt-3 font-display text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
                Basic, Premium &amp; Pro Website Tiers
              </h2>
              <p className="mt-3 text-sm sm:text-base text-zinc-400">
                All pricing tiers and package deliverables are dynamically managed from the studio Admin Dashboard.
              </p>
            </div>

            <div className="mt-10 grid grid-cols-1 lg:grid-cols-3 gap-6">
              {site.pricingPackages.map((pkg) => (
                <div
                  key={pkg.id}
                  className={`rounded-2xl p-8 flex flex-col justify-between ${
                    pkg.highlighted
                      ? 'glass-panel border-[#FF1744]/55 shadow-[0_24px_65px_-22px_rgba(255,23,68,0.42)]'
                      : 'glass-panel'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <h3 className="font-display text-xl font-bold tracking-wide text-white">
                        {pkg.name}
                      </h3>
                      {pkg.highlighted && (
                        <span className="text-xs font-semibold text-[#FF1744]">Recommended</span>
                      )}
                    </div>
                    <p className="mt-1 text-xs text-zinc-400">{pkg.audience}</p>

                    <div className="mt-6 flex items-baseline gap-2">
                      <span className="font-mono-tabular text-4xl font-extrabold text-white">
                        {pkg.price}
                      </span>
                      <span className="text-xs text-zinc-500">starting</span>
                    </div>

                    {pkg.description && (
                      <p className="mt-3 text-xs leading-relaxed text-zinc-400">
                        {pkg.description}
                      </p>
                    )}

                    <ul className="mt-6 space-y-3 border-t border-white/[0.08] pt-6 text-sm text-zinc-200">
                      {pkg.features.map((feat, i) => (
                        <li key={i} className="flex items-start gap-2.5">
                          <Check className="w-4 h-4 text-[#FF1744] shrink-0 mt-0.5" aria-hidden="true" />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <a
                    href={safeHref(buildWhatsAppUrl(site.contact.whatsappLink, pkg.whatsappPrompt))}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`mt-8 inline-flex w-full items-center justify-center gap-2 rounded-lg px-5 py-3.5 text-sm font-semibold transition-colors ${
                      pkg.highlighted
                        ? 'crimson-glow-btn text-white'
                        : 'border border-white/15 bg-white/[0.04] text-white hover:border-[#FF1744]/50'
                    }`}
                  >
                    <MessageCircle className="w-4 h-4" aria-hidden="true" />
                    <span>WhatsApp Enquiry</span>
                  </a>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Service Details Modal */}
      {selectedService && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="service-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4"
          onClick={() => setSelectedService(null)}
        >
          <div
            className="glass-panel max-w-xl w-full rounded-2xl overflow-hidden border border-white/15 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative h-48 w-full bg-[#101010]">
              <SafeImage
                src={selectedService.imageUrl}
                alt={selectedService.title}
                lazy={false}
                className="h-full w-full object-cover"
              />
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#0d0d0f] via-[#0d0d0f]/30 to-transparent"
              />
              <button
                type="button"
                onClick={() => setSelectedService(null)}
                aria-label="Close service details"
                className="absolute top-4 right-4 inline-flex h-10 w-10 items-center justify-center rounded-lg bg-black/70 text-white hover:bg-[#FF1744] transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" aria-hidden="true" />
              </button>
            </div>

            <div className="p-6 sm:p-8">
              <div className="flex items-center justify-between gap-3">
                <h2 id="service-modal-title" className="font-display text-2xl font-bold text-white">
                  {selectedService.title}
                </h2>
                <span className="font-mono-tabular text-lg font-bold text-[#FF1744] whitespace-nowrap">
                  {selectedService.startingPrice}
                </span>
              </div>

              <p className="mt-4 text-sm sm:text-base leading-relaxed text-zinc-300">
                {selectedService.fullDescription}
              </p>

              {selectedService.deliverables.length > 0 && (
                <div className="mt-6 border-t border-white/[0.08] pt-5">
                  <h3 className="text-xs font-semibold tracking-[0.18em] text-zinc-400">
                    Included Deliverables
                  </h3>
                  <ul className="mt-3 space-y-2.5 text-sm text-zinc-200">
                    {selectedService.deliverables.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-2.5">
                        <Check className="w-4 h-4 text-[#FF1744] shrink-0 mt-0.5" aria-hidden="true" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="mt-7 flex flex-wrap items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setSelectedService(null)}
                  className="rounded-lg border border-white/15 px-4 py-2.5 text-sm font-medium text-zinc-300 hover:text-white cursor-pointer"
                >
                  Close
                </button>
                <a
                  href={safeHref(
                    buildWhatsAppUrl(
                      site.contact.whatsappLink,
                      `Hello ALVISH Studio, I want to book ${selectedService.title} (${selectedService.startingPrice}).`,
                    ),
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="crimson-glow-btn inline-flex items-center gap-2 rounded-lg px-5 py-2.5 text-sm font-semibold text-white"
                >
                  <MessageCircle className="w-4 h-4" aria-hidden="true" />
                  <span>Contact on WhatsApp</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </PageShell>
  );
};
