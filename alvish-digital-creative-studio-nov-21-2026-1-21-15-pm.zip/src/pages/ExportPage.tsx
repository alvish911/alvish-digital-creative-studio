import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, CheckCircle2, Download, FolderArchive, Globe, AlertCircle } from 'lucide-react';
import { readJsonApiResponse } from '../utils/hostingMode';

interface ArchiveMeta {
  available: boolean;
  fileName: string;
  sizeBytes: number;
  sizeLabel: string;
}

interface ExportInfoResponse {
  sourceZip: ArchiveMeta;
  distZip: ArchiveMeta;
}

export const ExportPage: React.FC = () => {
  const [info, setInfo] = useState<ExportInfoResponse | null>(null);
  const [downloading, setDownloading] = useState<'source' | 'dist' | null>(null);
  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    document.title = 'Export Project Source | ALVISH – Digital Creative Studio';
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch('/api/export/info', { headers: { Accept: 'application/json' } });
        const parsed = await readJsonApiResponse<ExportInfoResponse>(res);
        if (!cancelled && parsed.isJson && parsed.ok && parsed.data) {
          setInfo(parsed.data);
        }
      } catch {
        // Ignore if running on static host
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const triggerDownload = async (kind: 'source' | 'dist') => {
    setStatusMsg(null);
    setDownloading(kind);
    const endpoint = kind === 'source' ? '/api/export/source-zip' : '/api/export/dist-zip';
    const fileName =
      kind === 'source'
        ? 'alvish-digital-creative-studio.zip'
        : 'alvish-studio-netlify-drop.zip';

    try {
      const res = await fetch(endpoint, { credentials: 'same-origin' });
      if (!res.ok) {
        throw new Error(`Download returned status ${res.status}`);
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = fileName;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 4000);

      setStatusMsg({
        type: 'success',
        text: `Download started for ${fileName}. Check your browser Downloads folder.`,
      });
    } catch {
      setStatusMsg({
        type: 'error',
        text: 'Direct browser download was blocked in this environment. Use the AI Studio top-right "Download app" button or download the ZIP directly from the project Files panel.',
      });
    } finally {
      setDownloading(null);
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] text-white studio-ambient-radial px-4 py-12">
      <div className="mx-auto max-w-3xl">
        <Link
          to="/?autostart=1"
          className="inline-flex items-center gap-2 text-xs font-medium text-zinc-400 hover:text-white transition-colors mb-8"
        >
          <ArrowLeft className="w-4 h-4" aria-hidden="true" />
          <span>Back to ALVISH Studio Website</span>
        </Link>

        <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-white/12">
          <p className="text-xs font-semibold tracking-[0.22em] text-[#FF1744]">
            PROJECT EXPORT CENTER
          </p>
          <h1 className="mt-2 font-display text-2xl sm:text-3xl font-extrabold text-white">
            Download ALVISH – Digital Creative Studio
          </h1>
          <p className="mt-2 text-sm text-zinc-400 leading-relaxed">
            Download inside this authenticated preview session to avoid external 403 proxy blocks. Both archives are freshly built and ready for free hosting on Netlify or Vercel.
          </p>

          {statusMsg && (
            <div
              role="status"
              aria-live="polite"
              className={`mt-5 flex items-start gap-2.5 rounded-xl border px-4 py-3 text-xs ${
                statusMsg.type === 'success'
                  ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-200'
                  : 'border-[#FF1744]/50 bg-[#FF1744]/12 text-red-200'
              }`}
            >
              {statusMsg.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" aria-hidden="true" />
              ) : (
                <AlertCircle className="w-4 h-4 text-[#FF1744] shrink-0 mt-0.5" aria-hidden="true" />
              )}
              <span>{statusMsg.text}</span>
            </div>
          )}

          <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="rounded-xl border border-white/10 bg-white/[0.03] p-5 flex flex-col justify-between gap-4">
              <div>
                <div className="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-[#FF1744]/15 border border-[#FF1744]/35 text-[#FF1744]">
                  <FolderArchive className="w-5 h-5" aria-hidden="true" />
                </div>
                <h2 className="mt-4 font-display text-lg font-bold text-white">
                  Complete Source Code ZIP
                </h2>
                <p className="mt-1.5 text-xs text-zinc-400 leading-relaxed">
                  All React, TypeScript, HTML, CSS, package.json, netlify.toml, vercel.json, server.ts, portrait, portfolio visuals, and MP3 music track. Best for GitHub + Netlify/Vercel.
                </p>
                {info?.sourceZip.available && (
                  <p className="mt-3 font-mono-tabular text-[11px] text-zinc-300">
                    {info.sourceZip.fileName} · {info.sourceZip.sizeLabel}
                  </p>
                )}
              </div>

              <button
                type="button"
                disabled={downloading !== null}
                onClick={() => void triggerDownload('source')}
                className="crimson-glow-btn w-full inline-flex items-center justify-center gap-2 rounded-lg px-4 py-3 text-xs font-semibold text-white cursor-pointer disabled:opacity-60"
              >
                <Download className="w-4 h-4" aria-hidden="true" />
                <span>
                  {downloading === 'source' ? 'Preparing Source ZIP...' : 'Download Complete Source ZIP'}
                </span>
              </button>
            </div>

            <div className="rounded-xl border border-white/10 bg-white/[0.03] p-5 flex flex-col justify-between gap-4">
              <div>
                <div className="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-white/10 border border-white/15 text-white">
                  <Globe className="w-5 h-5" aria-hidden="true" />
                </div>
                <h2 className="mt-4 font-display text-lg font-bold text-white">
                  Ready-to-Drop Netlify Build ZIP
                </h2>
                <p className="mt-1.5 text-xs text-zinc-400 leading-relaxed">
                  Pre-compiled production dist/ bundle (HTML, CSS, JS, _redirects, images, and MP3). Unzip and drag the folder directly onto app.netlify.com/drop — no Node.js needed.
                </p>
                {info?.distZip.available && (
                  <p className="mt-3 font-mono-tabular text-[11px] text-zinc-300">
                    {info.distZip.fileName} · {info.distZip.sizeLabel}
                  </p>
                )}
              </div>

              <button
                type="button"
                disabled={downloading !== null}
                onClick={() => void triggerDownload('dist')}
                className="w-full inline-flex items-center justify-center gap-2 rounded-lg border border-white/20 bg-white/[0.06] px-4 py-3 text-xs font-semibold text-white hover:border-[#FF1744] transition-colors cursor-pointer disabled:opacity-60"
              >
                <Download className="w-4 h-4 text-[#FF1744]" aria-hidden="true" />
                <span>
                  {downloading === 'dist' ? 'Preparing Netlify ZIP...' : 'Download Netlify Drop ZIP'}
                </span>
              </button>
            </div>
          </div>

          <div className="mt-6 rounded-xl border border-white/8 bg-black/40 p-4 text-xs text-zinc-400 leading-relaxed">
            <p className="font-semibold text-zinc-200">Alternative Download Inside Google AI Studio</p>
            <p className="mt-1">
              You can also download the entire project at any time using the <strong className="text-white">Download app</strong> icon in the top-right toolbar of AI Studio Build, or by selecting <code className="text-zinc-200">alvish-digital-creative-studio.zip</code> / <code className="text-zinc-200">alvish-studio-netlify-drop.zip</code> in the Code file explorer.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
