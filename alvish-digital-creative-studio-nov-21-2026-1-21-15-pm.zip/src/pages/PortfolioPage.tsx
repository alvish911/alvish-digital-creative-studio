import React, { useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { ExternalLink, MessageCircle, Play, X } from 'lucide-react';
import { PageShell } from '../components/PageShell';
import { SafeImage } from '../components/SafeImage';
import { useSite } from '../context/SiteContext';
import { PORTFOLIO_CATEGORIES, type PortfolioProject } from '../shared/types';
import { buildWhatsAppUrl, safeHref } from '../shared/validation';

export const PortfolioPage: React.FC = () => {
  const { site } = useSite();
  const [searchParams, setSearchParams] = useSearchParams();
  const initialCategory = searchParams.get('category') || 'All';
  const [activeCategory, setActiveCategory] = useState<string>(
    PORTFOLIO_CATEGORIES.includes(initialCategory as (typeof PORTFOLIO_CATEGORIES)[number])
      ? initialCategory
      : 'All',
  );
  const [selectedProject, setSelectedProject] = useState<PortfolioProject | null>(null);

  const publishedProjects = useMemo(
    () =>
      [...site.portfolio]
        .filter((p) => p.published)
        .sort((a, b) => a.order - b.order),
    [site.portfolio],
  );

  const filteredProjects = useMemo(() => {
    if (activeCategory === 'All') return publishedProjects;
    return publishedProjects.filter((p) => p.category === activeCategory);
  }, [publishedProjects, activeCategory]);

  const handleCategoryChange = (cat: string) => {
    setActiveCategory(cat);
    if (cat === 'All') {
      setSearchParams({});
    } else {
      setSearchParams({ category: cat });
    }
  };

  return (
    <PageShell
      title="Portfolio"
      description="Selected Website Designs, AI Videos, AI Songs, Advertisements, Posters, Business Promotions, and Social Media Designs by ALVISH – Digital Creative Studio."
    >
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-14 lg:py-22">
        <div className="max-w-2xl">
          <p className="text-xs font-semibold tracking-[0.24em] text-[#FF1744]">
            Selected Works
          </p>
          <h1 className="mt-3 font-display text-4xl sm:text-5xl font-extrabold tracking-tight text-white">
            Studio Portfolio Gallery
          </h1>
          <p className="mt-4 text-base text-zinc-400">
            Browse curated web builds, AI commercial films, audio identities, ad campaigns, posters, and social media visual systems.
          </p>
        </div>

        {/* Interactive Category Filter Controls */}
        <div
          role="tablist"
          aria-label="Filter portfolio by category"
          className="mt-10 flex flex-wrap items-center gap-2"
        >
          {['All', ...PORTFOLIO_CATEGORIES].map((category) => {
            const active = activeCategory === category;
            return (
              <button
                key={category}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => handleCategoryChange(category)}
                className={`rounded-lg px-4 py-2 text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                  active
                    ? 'bg-[#FF1744] text-white shadow-[0_8px_24px_-6px_rgba(255,23,68,0.6)]'
                    : 'border border-white/10 bg-white/[0.03] text-zinc-300 hover:border-[#FF1744]/40 hover:text-white'
                }`}
              >
                {category}
              </button>
            );
          })}
        </div>

        {/* Portfolio Grid */}
        {filteredProjects.length === 0 ? (
          <div className="mt-12 glass-panel rounded-2xl p-12 text-center">
            <p className="font-display text-xl font-semibold text-white">
              No projects published in {activeCategory} yet
            </p>
            <p className="mt-2 text-sm text-zinc-400">
              Add new projects in this category anytime from Admin Dashboard → Portfolio Management.
            </p>
            <button
              type="button"
              onClick={() => handleCategoryChange('All')}
              className="mt-5 rounded-lg border border-white/15 px-4 py-2 text-xs font-semibold text-white hover:border-[#FF1744] cursor-pointer"
            >
              Show All Projects
            </button>
          </div>
        ) : (
          <div className="mt-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects.map((project) => (
              <article
                key={project.id}
                className="group glass-panel glass-panel-hover rounded-2xl overflow-hidden flex flex-col justify-between"
              >
                <div>
                  <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#101010]">
                    <SafeImage
                      src={project.imageUrl}
                      alt={project.title}
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div
                      aria-hidden="true"
                      className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#050505]/85 via-transparent to-transparent"
                    />
                    {project.videoUrl && (
                      <div className="absolute top-4 right-4 inline-flex items-center gap-1.5 rounded-md bg-black/75 border border-white/15 px-2.5 py-1 text-xs font-medium text-white">
                        <Play className="w-3.5 h-3.5 text-[#FF1744]" aria-hidden="true" />
                        <span>Video</span>
                      </div>
                    )}
                  </div>

                  <div className="p-6">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-400">
                      <span className="font-medium text-[#FF1744]">{project.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>{project.year}</span>
                      {project.clientName && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span>{project.clientName}</span>
                        </>
                      )}
                    </div>

                    <h2 className="mt-2 font-display text-xl font-bold text-white">
                      {project.title}
                    </h2>
                    <p className="mt-2 text-sm leading-relaxed text-zinc-400">
                      {project.summary}
                    </p>
                  </div>
                </div>

                <div className="px-6 pb-6 pt-1 flex items-center justify-between gap-3">
                  <span className="font-mono-tabular text-xs text-zinc-500 truncate">
                    {project.metrics || project.category}
                  </span>
                  <button
                    type="button"
                    onClick={() => setSelectedProject(project)}
                    aria-label={`Inspect project ${project.title}`}
                    className="rounded-lg border border-white/15 bg-white/[0.04] px-3.5 py-2 text-xs font-semibold text-white hover:border-[#FF1744]/60 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                  >
                    Project Details
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>

      {/* Fullscreen Lightbox Modal */}
      {selectedProject && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="portfolio-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto"
          onClick={() => setSelectedProject(null)}
        >
          <div
            className="glass-panel max-w-3xl w-full rounded-2xl overflow-hidden border border-white/15 shadow-2xl my-8"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative aspect-video w-full bg-black">
              {selectedProject.videoUrl ? (
                <video
                  src={safeHref(selectedProject.videoUrl)}
                  poster={selectedProject.imageUrl}
                  controls
                  playsInline
                  className="h-full w-full object-cover"
                />
              ) : (
                <SafeImage
                  src={selectedProject.imageUrl}
                  alt={selectedProject.title}
                  lazy={false}
                  className="h-full w-full object-cover"
                />
              )}
              <button
                type="button"
                onClick={() => setSelectedProject(null)}
                aria-label="Close project preview"
                className="absolute top-4 right-4 inline-flex h-10 w-10 items-center justify-center rounded-lg bg-black/75 text-white hover:bg-[#FF1744] transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" aria-hidden="true" />
              </button>
            </div>

            <div className="p-6 sm:p-8">
              <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-400">
                <span className="font-semibold text-[#FF1744]">{selectedProject.category}</span>
                <span aria-hidden="true">·</span>
                <span>{selectedProject.clientName || 'Studio Project'}</span>
                <span aria-hidden="true">·</span>
                <span>{selectedProject.year}</span>
                {selectedProject.metrics && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono-tabular text-zinc-300">{selectedProject.metrics}</span>
                  </>
                )}
              </div>

              <h2 id="portfolio-modal-title" className="mt-2 font-display text-2xl sm:text-3xl font-bold text-white">
                {selectedProject.title}
              </h2>

              <p className="mt-4 text-sm sm:text-base leading-relaxed text-zinc-300">
                {selectedProject.details || selectedProject.summary}
              </p>

              <div className="mt-7 flex flex-wrap items-center justify-between gap-3 border-t border-white/[0.08] pt-6">
                {selectedProject.projectUrl ? (
                  <a
                    href={safeHref(selectedProject.projectUrl)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-sm font-semibold text-white hover:text-[#FF1744] transition-colors"
                  >
                    <span>Visit Live Project</span>
                    <ExternalLink className="w-4 h-4" aria-hidden="true" />
                  </a>
                ) : (
                  <span className="text-xs text-zinc-500">ALVISH – Digital Creative Studio Archive</span>
                )}

                <a
                  href={safeHref(
                    buildWhatsAppUrl(
                      site.contact.whatsappLink,
                      `Hello ALVISH Studio, I liked your project "${selectedProject.title}" (${selectedProject.category}) and would love something similar.`,
                    ),
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="crimson-glow-btn inline-flex items-center gap-2 rounded-lg px-5 py-2.5 text-sm font-semibold text-white"
                >
                  <MessageCircle className="w-4 h-4" aria-hidden="true" />
                  <span>Request Similar Project</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </PageShell>
  );
};
