import React, { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  CheckCircle2,
  Eye,
  LogOut,
  Menu,
  RotateCcw,
  Save,
  Send,
  X,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useSite } from '../context/SiteContext';
import type {
  AdminDashboardState,
  ContactEnquiry,
  MediaFileItem,
  SiteContent,
} from '../shared/types';
import { AdminContentEditors } from '../components/admin/AdminContentEditors';
import { AdminCollectionEditors } from '../components/admin/AdminCollectionEditors';
import { AdminSystemEditors } from '../components/admin/AdminSystemEditors';

type SectionId =
  | 'overview'
  | 'home'
  | 'about'
  | 'services'
  | 'pricing'
  | 'skills'
  | 'experience'
  | 'portfolio'
  | 'achievements'
  | 'testimonials'
  | 'contact'
  | 'social'
  | 'media'
  | 'intro'
  | 'music'
  | 'theme'
  | 'navigation'
  | 'seo'
  | 'backup'
  | 'security';

const DASHBOARD_SECTIONS: Array<{ id: SectionId; label: string; group: string }> = [
  { id: 'overview', label: '1. Website Overview', group: 'Core' },
  { id: 'home', label: '2. Home Page Editor', group: 'Pages' },
  { id: 'about', label: '3. About Page Editor', group: 'Pages' },
  { id: 'services', label: '4. Services Management', group: 'Offerings' },
  { id: 'pricing', label: '5. Pricing Management', group: 'Offerings' },
  { id: 'skills', label: '6. Skills Management', group: 'Credentials' },
  { id: 'experience', label: '7. Experience Management', group: 'Credentials' },
  { id: 'portfolio', label: '8. Portfolio Management', group: 'Showcase' },
  { id: 'achievements', label: '9. Achievements Management', group: 'Showcase' },
  { id: 'testimonials', label: '10. Testimonials Management', group: 'Showcase' },
  { id: 'contact', label: '11. Contact & Enquiries', group: 'Channels' },
  { id: 'social', label: '12. Social Media Links', group: 'Channels' },
  { id: 'media', label: '13. Images & Media', group: 'Assets' },
  { id: 'intro', label: '14. Intro Animation', group: 'Experience' },
  { id: 'music', label: '15. Music Settings', group: 'Experience' },
  { id: 'theme', label: '16. Website Theme', group: 'System' },
  { id: 'navigation', label: '17. Navigation Management', group: 'System' },
  { id: 'seo', label: '18. SEO Settings', group: 'System' },
  { id: 'backup', label: '19. Backup & Restore', group: 'System' },
  { id: 'security', label: '20. Security Settings', group: 'System' },
];

export const AdminDashboardPage: React.FC = () => {
  const { token, status, checking, authHeaders, logout } = useAuth();
  const { refreshSite, setPreviewContent } = useSite();
  const navigate = useNavigate();

  const [activeSection, setActiveSection] = useState<SectionId>('overview');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [dashboardState, setDashboardState] = useState<AdminDashboardState | null>(null);
  const [draft, setDraft] = useState<SiteContent | null>(null);
  const [dirtyLocal, setDirtyLocal] = useState(false);
  const [busyAction, setBusyAction] = useState<string | null>(null);
  const [notice, setNotice] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const showNotice = useCallback((type: 'success' | 'error', text: string) => {
    setNotice({ type, text });
    window.setTimeout(() => {
      setNotice((curr) => (curr?.text === text ? null : curr));
    }, 4500);
  }, []);

  const loadDashboard = useCallback(async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/admin/state', { headers: authHeaders() });
      if (res.status === 401) {
        navigate('/admin/login', { replace: true });
        return;
      }
      if (!res.ok) throw new Error('Unable to load admin state.');
      const data = (await res.json()) as AdminDashboardState;
      setDashboardState(data);
      setDraft(data.draft);
      setDirtyLocal(false);
    } catch {
      showNotice('error', 'Failed to load dashboard data from server.');
    } finally {
      setLoading(false);
    }
  }, [token, authHeaders, navigate, showNotice]);

  useEffect(() => {
    document.title = 'Admin Dashboard | ALVISH – Digital Creative Studio';
    if (!checking && (!status.authenticated || !token)) {
      navigate('/admin/login', { replace: true });
      return;
    }
    if (!checking && status.authenticated && token) {
      void loadDashboard();
    }
  }, [checking, status.authenticated, token, navigate, loadDashboard]);

  const handleDraftChange = (next: SiteContent) => {
    setDraft(next);
    setDirtyLocal(true);
  };

  const handleSaveDraft = async () => {
    if (!draft) return;
    setBusyAction('save');
    try {
      const res = await fetch('/api/admin/draft', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', ...authHeaders() },
        body: JSON.stringify({ content: draft }),
      });
      const data = await res.json();
      if (!res.ok) {
        showNotice('error', data.error || 'Could not save draft.');
        return;
      }
      setDraft(data.draft);
      setDirtyLocal(false);
      setDashboardState((prev) =>
        prev ? { ...prev, draft: data.draft, hasUnpublishedChanges: data.hasUnpublishedChanges } : prev,
      );
      showNotice('success', 'Draft saved. Use Preview to inspect or Publish Live when ready.');
    } catch {
      showNotice('error', 'Network error while saving draft.');
    } finally {
      setBusyAction(null);
    }
  };

  const handlePublish = async () => {
    if (!draft) return;
    setBusyAction('publish');
    try {
      const res = await fetch('/api/admin/publish', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders() },
        body: JSON.stringify({ content: draft }),
      });
      const data = await res.json();
      if (!res.ok) {
        showNotice('error', data.error || 'Publish failed.');
        return;
      }
      setDraft(data.published);
      setDirtyLocal(false);
      setPreviewContent(null);
      await refreshSite();
      await loadDashboard();
      showNotice('success', `Published live (Version ${data.published.version}).`);
    } catch {
      showNotice('error', 'Network error while publishing.');
    } finally {
      setBusyAction(null);
    }
  };

  const handleDiscard = async () => {
    setBusyAction('discard');
    try {
      const res = await fetch('/api/admin/discard-draft', {
        method: 'POST',
        headers: authHeaders(),
      });
      const data = await res.json();
      if (!res.ok) {
        showNotice('error', data.error || 'Unable to discard draft.');
        return;
      }
      setDraft(data.draft);
      setDirtyLocal(false);
      setPreviewContent(null);
      setDashboardState((prev) =>
        prev ? { ...prev, draft: data.draft, hasUnpublishedChanges: false } : prev,
      );
      showNotice('success', 'Reverted draft to the live published version.');
    } catch {
      showNotice('error', 'Network error while discarding changes.');
    } finally {
      setBusyAction(null);
    }
  };

  const handlePreview = () => {
    if (!draft) return;
    setPreviewContent(draft);
    navigate('/?autostart=1');
  };

  const handleUploadFile = async (file: File): Promise<MediaFileItem | null> => {
    try {
      const dataBase64 = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ''));
        reader.onerror = () => reject(new Error('Failed to read file.'));
        reader.readAsDataURL(file);
      });

      const res = await fetch('/api/admin/media/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders() },
        body: JSON.stringify({
          fileName: file.name,
          mimeType: file.type,
          dataBase64,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        showNotice('error', data.error || 'File upload rejected.');
        return null;
      }
      setDashboardState((prev) =>
        prev ? { ...prev, media: [data.media, ...prev.media] } : prev,
      );
      showNotice('success', `Uploaded ${data.media.fileName}`);
      return data.media as MediaFileItem;
    } catch {
      showNotice('error', 'File upload failed.');
      return null;
    }
  };

  const handleDeleteMedia = async (id: string) => {
    const res = await fetch(`/api/admin/media/${encodeURIComponent(id)}`, {
      method: 'DELETE',
      headers: authHeaders(),
    });
    if (res.ok) {
      setDashboardState((prev) =>
        prev ? { ...prev, media: prev.media.filter((m) => m.id !== id) } : prev,
      );
      showNotice('success', 'Media asset deleted.');
    }
  };

  const handleUpdateEnquiryStatus = async (id: string, nextStatus: ContactEnquiry['status']) => {
    const res = await fetch(`/api/admin/enquiries/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({ status: nextStatus }),
    });
    if (res.ok) {
      const data = await res.json();
      setDashboardState((prev) =>
        prev
          ? {
              ...prev,
              enquiries: prev.enquiries.map((e) => (e.id === id ? data.enquiry : e)),
            }
          : prev,
      );
    }
  };

  const handleDeleteEnquiry = async (id: string) => {
    const res = await fetch(`/api/admin/enquiries/${encodeURIComponent(id)}`, {
      method: 'DELETE',
      headers: authHeaders(),
    });
    if (res.ok) {
      setDashboardState((prev) =>
        prev ? { ...prev, enquiries: prev.enquiries.filter((e) => e.id !== id) } : prev,
      );
      showNotice('success', 'Enquiry deleted.');
    }
  };

  const handleDownloadBackup = async () => {
    const res = await fetch('/api/admin/backup', { headers: authHeaders() });
    if (!res.ok) {
      showNotice('error', 'Unable to export backup.');
      return;
    }
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `alvish-studio-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showNotice('success', 'Backup JSON downloaded.');
  };

  const handleRestoreBackup = async (jsonText: string) => {
    try {
      const parsed = JSON.parse(jsonText);
      const res = await fetch('/api/admin/restore', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders() },
        body: JSON.stringify(parsed),
      });
      const data = await res.json();
      if (!res.ok) {
        return { ok: false, message: data.error || 'Backup validation failed.' };
      }
      await refreshSite();
      await loadDashboard();
      return { ok: true, message: 'Backup restored and published successfully.' };
    } catch {
      return { ok: false, message: 'Selected file is not valid JSON.' };
    }
  };

  const handleChangePassword = async (currentPassword: string, newPassword: string) => {
    try {
      const res = await fetch('/api/admin/auth/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders() },
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { ok: false, message: data.error || 'Password update failed.' };
      }
      await loadDashboard();
      return { ok: true, message: data.message || 'Password updated.' };
    } catch {
      return { ok: false, message: 'Network error while updating password.' };
    }
  };

  if (checking || loading || !draft || !dashboardState) {
    return (
      <div className="min-h-screen bg-[#050505] text-white flex items-center justify-center p-6">
        <p className="text-sm text-zinc-400">Loading ALVISH Admin Dashboard...</p>
      </div>
    );
  }

  const currentSectionMeta = DASHBOARD_SECTIONS.find((s) => s.id === activeSection);

  return (
    <div className="min-h-screen bg-[#050505] text-white flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:w-68 lg:flex-col lg:sticky lg:top-0 lg:h-screen border-r border-white/[0.08] bg-[#08080a] shrink-0">
        <div className="h-16 flex items-center justify-between px-5 border-b border-white/[0.08]">
          <span className="font-display text-base font-extrabold tracking-[0.16em] text-white">
            ALVISH CMS
          </span>
          <span className="font-mono-tabular text-[11px] text-zinc-500">v{draft.version}</span>
        </div>

        <nav aria-label="Admin Sections" className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          {DASHBOARD_SECTIONS.map((sec) => {
            const active = activeSection === sec.id;
            return (
              <button
                key={sec.id}
                type="button"
                onClick={() => setActiveSection(sec.id)}
                className={`w-full rounded-lg px-3 py-2 text-left text-xs font-medium transition-colors cursor-pointer ${
                  active
                    ? 'bg-[#FF1744]/15 text-white border border-[#FF1744]/40'
                    : 'text-zinc-400 hover:bg-white/[0.04] hover:text-white border border-transparent'
                }`}
              >
                {sec.label}
              </button>
            );
          })}
        </nav>

        <div className="border-t border-white/[0.08] p-4">
          <p className="text-[11px] text-zinc-500 truncate">{status.email}</p>
          <button
            type="button"
            onClick={async () => {
              await logout();
              navigate('/admin/login', { replace: true });
            }}
            className="mt-2.5 w-full inline-flex items-center justify-center gap-2 rounded-lg border border-white/12 bg-white/[0.03] px-3 py-2 text-xs font-semibold text-zinc-200 hover:border-[#FF1744]/60 hover:text-white cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5 text-[#FF1744]" aria-hidden="true" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Mobile Sidebar Drawer */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div className="w-72 max-w-[85vw] bg-[#08080a] border-r border-white/10 flex flex-col h-full">
            <div className="h-16 flex items-center justify-between px-4 border-b border-white/10">
              <span className="font-display text-sm font-extrabold tracking-[0.16em]">ALVISH CMS</span>
              <button
                type="button"
                onClick={() => setSidebarOpen(false)}
                aria-label="Close admin sidebar"
                className="p-2 text-zinc-300 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" aria-hidden="true" />
              </button>
            </div>
            <nav className="flex-1 overflow-y-auto px-3 py-3 space-y-1">
              {DASHBOARD_SECTIONS.map((sec) => (
                <button
                  key={sec.id}
                  type="button"
                  onClick={() => {
                    setActiveSection(sec.id);
                    setSidebarOpen(false);
                  }}
                  className={`w-full rounded-lg px-3 py-2.5 text-left text-xs font-medium cursor-pointer ${
                    activeSection === sec.id
                      ? 'bg-[#FF1744]/15 text-white border border-[#FF1744]/40'
                      : 'text-zinc-400 hover:bg-white/[0.04]'
                  }`}
                >
                  {sec.label}
                </button>
              ))}
            </nav>
            <div className="p-4 border-t border-white/10">
              <button
                type="button"
                onClick={async () => {
                  await logout();
                  navigate('/admin/login', { replace: true });
                }}
                className="w-full inline-flex items-center justify-center gap-2 rounded-lg border border-white/15 py-2.5 text-xs font-semibold text-white cursor-pointer"
              >
                <LogOut className="w-4 h-4 text-[#FF1744]" aria-hidden="true" />
                <span>Sign Out</span>
              </button>
            </div>
          </div>
          <div className="flex-1 bg-black/70" onClick={() => setSidebarOpen(false)} />
        </div>
      )}

      {/* Main Workspace */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Action Bar: Save, Cancel/Discard, Preview, Publish */}
        <header className="sticky top-0 z-30 border-b border-white/[0.08] bg-[#050505]/90 backdrop-blur-xl px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setSidebarOpen(true)}
              aria-label="Open admin menu"
              className="lg:hidden inline-flex h-10 w-10 items-center justify-center rounded-lg border border-white/12 text-white cursor-pointer"
            >
              <Menu className="w-5 h-5" aria-hidden="true" />
            </button>
            <div className="min-w-0">
              <p className="text-xs text-zinc-400 truncate">
                Admin Dashboard / <span className="text-white font-medium">{currentSectionMeta?.label}</span>
              </p>
              {(dirtyLocal || dashboardState.hasUnpublishedChanges) && (
                <p className="text-[11px] text-amber-300">Unsaved or unpublished edits active</p>
              )}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handlePreview}
              className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-white/[0.04] px-3.5 py-2 text-xs font-semibold text-white hover:border-[#FF1744]/50 cursor-pointer whitespace-nowrap"
            >
              <Eye className="w-3.5 h-3.5 text-[#FF1744]" aria-hidden="true" />
              <span>Preview</span>
            </button>

            <button
              type="button"
              disabled={busyAction !== null}
              onClick={() => void handleDiscard()}
              className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-white/[0.04] px-3.5 py-2 text-xs font-semibold text-zinc-300 hover:text-white cursor-pointer whitespace-nowrap disabled:opacity-50"
            >
              <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Cancel</span>
            </button>

            <button
              type="button"
              disabled={busyAction !== null}
              onClick={() => void handleSaveDraft()}
              className="inline-flex items-center gap-1.5 rounded-lg border border-white/20 bg-white/[0.06] px-3.5 py-2 text-xs font-semibold text-white hover:border-[#FF1744] cursor-pointer whitespace-nowrap disabled:opacity-50"
            >
              <Save className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{busyAction === 'save' ? 'Saving...' : 'Save Draft'}</span>
            </button>

            <button
              type="button"
              disabled={busyAction !== null}
              onClick={() => void handlePublish()}
              className="crimson-glow-btn inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold text-white cursor-pointer whitespace-nowrap disabled:opacity-50"
            >
              <Send className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{busyAction === 'publish' ? 'Publishing...' : 'Publish Live'}</span>
            </button>
          </div>
        </header>

        {notice && (
          <div
            role="status"
            aria-live="polite"
            className={`mx-4 sm:mx-6 mt-4 flex items-center gap-2 rounded-xl border px-4 py-3 text-xs font-medium ${
              notice.type === 'success'
                ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-200'
                : 'border-[#FF1744]/50 bg-[#FF1744]/12 text-red-200'
            }`}
          >
            <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>{notice.text}</span>
          </div>
        )}

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-5xl w-full">
          {(activeSection === 'overview' ||
            activeSection === 'home' ||
            activeSection === 'about' ||
            activeSection === 'services' ||
            activeSection === 'pricing') && (
            <AdminContentEditors
              section={activeSection}
              draft={draft}
              onChange={handleDraftChange}
              enquiries={dashboardState.enquiries}
              media={dashboardState.media}
              hasUnpublishedChanges={dirtyLocal || dashboardState.hasUnpublishedChanges}
              onUploadFile={handleUploadFile}
              onNavigateSection={(sec) => setActiveSection(sec as SectionId)}
            />
          )}

          {(activeSection === 'skills' ||
            activeSection === 'experience' ||
            activeSection === 'portfolio' ||
            activeSection === 'achievements' ||
            activeSection === 'testimonials') && (
            <AdminCollectionEditors
              section={activeSection}
              draft={draft}
              onChange={handleDraftChange}
              onUploadFile={handleUploadFile}
            />
          )}

          {(activeSection === 'contact' ||
            activeSection === 'social' ||
            activeSection === 'media' ||
            activeSection === 'intro' ||
            activeSection === 'music' ||
            activeSection === 'theme' ||
            activeSection === 'navigation' ||
            activeSection === 'seo' ||
            activeSection === 'backup' ||
            activeSection === 'security') && (
            <AdminSystemEditors
              section={activeSection}
              draft={draft}
              onChange={handleDraftChange}
              enquiries={dashboardState.enquiries}
              media={dashboardState.media}
              securityEvents={dashboardState.securityEvents}
              envManagedAuth={status.envManaged}
              onUploadFile={handleUploadFile}
              onDeleteMedia={handleDeleteMedia}
              onUpdateEnquiryStatus={handleUpdateEnquiryStatus}
              onDeleteEnquiry={handleDeleteEnquiry}
              onDownloadBackup={handleDownloadBackup}
              onRestoreBackup={handleRestoreBackup}
              onChangePassword={handleChangePassword}
            />
          )}
        </main>
      </div>
    </div>
  );
};
