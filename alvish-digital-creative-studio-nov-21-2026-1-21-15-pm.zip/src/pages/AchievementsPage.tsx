import React, { useState } from 'react';
import { Award, ExternalLink, X } from 'lucide-react';
import { PageShell } from '../components/PageShell';
import { SafeImage } from '../components/SafeImage';
import { useSite } from '../context/SiteContext';
import type { AchievementItem } from '../shared/types';
import { safeHref } from '../shared/validation';

export const AchievementsPage: React.FC = () => {
  const { site } = useSite();
  const [selected, setSelected] = useState<AchievementItem | null>(null);

  return (
    <PageShell
      title="Achievements"
      description="Certificates, awards, milestones, and creative recognitions of ALVISH – Digital Creative Studio."
    >
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-14 lg:py-22">
        <div className="max-w-2xl">
          <p className="text-xs font-semibold tracking-[0.24em] text-[#FF1744]">
            Recognition &amp; Credentials
          </p>
          <h1 className="mt-3 font-display text-4xl sm:text-5xl font-extrabold tracking-tight text-white">
            Achievements &amp; Certifications
          </h1>
          <p className="mt-4 text-base text-zinc-400">
            Studio milestones, technical certifications, and creative awards—fully editable with certificate uploads in the Admin Dashboard.
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6">
          {site.achievements.map((item) => (
            <article
              key={item.id}
              className="glass-panel glass-panel-hover rounded-2xl overflow-hidden flex flex-col justify-between"
            >
              <div>
                {item.imageUrl && (
                  <div className="relative aspect-[16/10] w-full overflow-hidden bg-[#101010]">
                    <SafeImage
                      src={item.imageUrl}
                      alt={item.title}
                      className="h-full w-full object-cover"
                    />
                    <div
                      aria-hidden="true"
                      className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#0d0d0f] via-transparent to-transparent opacity-85"
                    />
                  </div>
                )}

                <div className="p-6 sm:p-7">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-400">
                    <span className="font-semibold text-[#FF1744]">{item.kind}</span>
                    <span aria-hidden="true">·</span>
                    <span>{item.issuer}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono-tabular">{item.dateLabel}</span>
                  </div>

                  <h2 className="mt-2.5 font-display text-xl sm:text-2xl font-bold text-white">
                    {item.title}
                  </h2>

                  <p className="mt-3 text-sm leading-relaxed text-zinc-400">
                    {item.description}
                  </p>
                </div>
              </div>

              <div className="px-6 sm:px-7 pb-6 pt-2 flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => setSelected(item)}
                  aria-label={`View certificate for ${item.title}`}
                  className="inline-flex items-center gap-2 rounded-lg border border-white/15 bg-white/[0.04] px-4 py-2 text-xs font-semibold text-white hover:border-[#FF1744]/50 transition-colors cursor-pointer"
                >
                  <Award className="w-4 h-4 text-[#FF1744]" aria-hidden="true" />
                  <span>View Credential</span>
                </button>

                {item.credentialUrl && (
                  <a
                    href={safeHref(item.credentialUrl)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-medium text-zinc-300 hover:text-[#FF1744]"
                  >
                    <span>Verify</span>
                    <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
                  </a>
                )}
              </div>
            </article>
          ))}
        </div>
      </section>

      {selected && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="achievement-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4"
          onClick={() => setSelected(null)}
        >
          <div
            className="glass-panel max-w-2xl w-full rounded-2xl overflow-hidden border border-white/15"
            onClick={(e) => e.stopPropagation()}
          >
            {selected.imageUrl && (
              <div className="relative aspect-[16/10] w-full bg-black">
                <SafeImage
                  src={selected.imageUrl}
                  alt={selected.title}
                  lazy={false}
                  className="h-full w-full object-cover"
                />
                <button
                  type="button"
                  onClick={() => setSelected(null)}
                  aria-label="Close credential preview"
                  className="absolute top-4 right-4 inline-flex h-10 w-10 items-center justify-center rounded-lg bg-black/75 text-white hover:bg-[#FF1744] cursor-pointer"
                >
                  <X className="w-5 h-5" aria-hidden="true" />
                </button>
              </div>
            )}
            <div className="p-6 sm:p-8">
              <p className="text-xs text-zinc-400">
                <span className="font-semibold text-[#FF1744]">{selected.kind}</span> · {selected.issuer} · {selected.dateLabel}
              </p>
              <h2 id="achievement-modal-title" className="mt-2 font-display text-2xl font-bold text-white">
                {selected.title}
              </h2>
              <p className="mt-4 text-sm sm:text-base leading-relaxed text-zinc-300">
                {selected.description}
              </p>
            </div>
          </div>
        </div>
      )}
    </PageShell>
  );
};
