import React from 'react';
import { motion } from 'motion/react';
import { Briefcase, Calendar } from 'lucide-react';
import { PageShell } from '../components/PageShell';
import { useSite } from '../context/SiteContext';

export const ExperiencePage: React.FC = () => {
  const { site } = useSite();

  return (
    <PageShell
      title="Experience"
      description="Professional experience, entrepreneurial milestones, and client leadership of ALVISH – Digital Creative Studio."
    >
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-14 lg:py-22">
        <div className="max-w-2xl">
          <p className="text-xs font-semibold tracking-[0.24em] text-[#FF1744]">
            Career &amp; Studio Chronology
          </p>
          <h1 className="mt-3 font-display text-4xl sm:text-5xl font-extrabold tracking-tight text-white">
            Professional Experience
          </h1>
          <p className="mt-4 text-base text-zinc-400">
            A progressive track record of building luxury websites, launching AI-driven commercial visuals, and scaling digital brands.
          </p>
        </div>

        {/* Animated Vertical Timeline */}
        <div className="relative mt-14">
          <div
            aria-hidden="true"
            className="hidden md:block absolute left-6 top-0 bottom-0 w-px bg-gradient-to-b from-[#FF1744] via-[#FF1744]/35 to-transparent"
          />

          <div className="space-y-8">
            {site.experience.map((item, idx) => (
              <motion.article
                key={item.id}
                initial={{ opacity: 0.9, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.1 }}
                transition={{ duration: 0.4, delay: idx * 0.06, ease: [0.16, 1, 0.3, 1] }}
                className="relative md:pl-16"
              >
                {/* Timeline node */}
                <span
                  aria-hidden="true"
                  className="hidden md:flex absolute left-[17px] top-8 h-3.5 w-3.5 items-center justify-center rounded-full bg-[#FF1744] shadow-[0_0_16px_rgba(255,23,68,0.85)]"
                />

                <div className="glass-panel glass-panel-hover rounded-2xl p-6 sm:p-8">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/[0.08] pb-5">
                    <div>
                      <h2 className="font-display text-2xl font-bold text-white">
                        {item.title}
                      </h2>
                      <p className="mt-1 inline-flex items-center gap-2 text-sm font-medium text-[#FF1744]">
                        <Briefcase className="w-4 h-4" aria-hidden="true" />
                        <span>{item.companyOrProject}</span>
                      </p>
                    </div>

                    <div className="inline-flex items-center gap-2 font-mono-tabular text-xs text-zinc-300 shrink-0">
                      <Calendar className="w-3.5 h-3.5 text-zinc-400" aria-hidden="true" />
                      <span>
                        {item.startDate} — {item.endDate}
                      </span>
                    </div>
                  </div>

                  <p className="mt-5 text-sm sm:text-base leading-relaxed text-zinc-300">
                    {item.description}
                  </p>

                  {item.highlights.length > 0 && (
                    <ul className="mt-5 grid grid-cols-1 md:grid-cols-2 gap-3 pt-4 border-t border-white/[0.06] text-sm text-zinc-400">
                      {item.highlights.map((hl, i) => (
                        <li key={i} className="flex items-start gap-2.5">
                          <span className="font-mono-tabular text-xs text-[#FF1744] mt-0.5">
                            {String(i + 1).padStart(2, '0')}.
                          </span>
                          <span>{hl}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </motion.article>
            ))}
          </div>
        </div>
      </section>
    </PageShell>
  );
};
