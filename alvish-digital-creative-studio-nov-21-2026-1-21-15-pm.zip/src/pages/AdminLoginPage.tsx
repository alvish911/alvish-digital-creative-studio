import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AlertCircle, ArrowLeft, Lock, ShieldCheck } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { validateAdminPassword } from '../shared/validation';

export const AdminLoginPage: React.FC = () => {
  const { status, checking, login, bootstrap } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    document.title = 'Admin Login | ALVISH – Digital Creative Studio';
    if (!checking && status.authenticated) {
      navigate('/admin/dashboard', { replace: true });
    }
  }, [checking, status.authenticated, navigate]);

  const isFirstRun = !checking && status.needsBootstrap;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!email.trim() || !password) {
      setError('Please enter both your admin email and password.');
      return;
    }

    if (isFirstRun) {
      const check = validateAdminPassword(password);
      if (!check.valid) {
        setError(check.reason || 'Choose a stronger password.');
        return;
      }
      if (password !== confirmPassword) {
        setError('Passwords do not match.');
        return;
      }
    }

    setSubmitting(true);
    const result = isFirstRun
      ? await bootstrap(email.trim(), password)
      : await login(email.trim(), password);
    setSubmitting(false);

    if (!result.ok) {
      setError(result.error || 'Authentication failed.');
      return;
    }

    navigate('/admin/dashboard', { replace: true });
  };

  return (
    <div className="min-h-screen bg-[#050505] text-white studio-ambient-radial flex flex-col justify-center px-4 py-12">
      <div className="mx-auto w-full max-w-md">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-xs font-medium text-zinc-400 hover:text-white transition-colors mb-8"
        >
          <ArrowLeft className="w-4 h-4" aria-hidden="true" />
          <span>Back to ALVISH Studio Website</span>
        </Link>

        <div className="glass-panel rounded-2xl p-8 border border-white/12">
          <div className="flex items-center gap-3">
            <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-[#FF1744]/15 border border-[#FF1744]/35 text-[#FF1744]">
              {isFirstRun ? (
                <ShieldCheck className="w-5 h-5" aria-hidden="true" />
              ) : (
                <Lock className="w-5 h-5" aria-hidden="true" />
              )}
            </span>
            <div>
              <p className="font-display text-lg font-extrabold tracking-[0.14em] text-white">
                ALVISH ADMIN
              </p>
              <p className="text-xs text-zinc-400">
                {isFirstRun ? 'First-Run Admin Account Setup' : 'Secure Studio Control Panel'}
              </p>
            </div>
          </div>

          {isFirstRun && (
            <div className="mt-5 rounded-xl border border-amber-500/30 bg-amber-500/10 p-3.5 text-xs leading-relaxed text-amber-100">
              No admin account has been configured yet. Create your studio owner credentials below (hashed on the server using scrypt). This one-time setup locks immediately after claiming.
            </div>
          )}

          {error && (
            <div
              role="alert"
              className="mt-5 flex items-start gap-2.5 rounded-xl border border-[#FF1744]/50 bg-[#FF1744]/12 px-4 py-3 text-xs text-red-200"
            >
              <AlertCircle className="w-4 h-4 text-[#FF1744] shrink-0 mt-0.5" aria-hidden="true" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="mt-6 space-y-5" noValidate>
            <div>
              <label htmlFor="admin-email" className="block text-xs font-semibold text-zinc-200">
                Admin Email
              </label>
              <input
                id="admin-email"
                type="email"
                autoComplete="username"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@alvishstudios.com"
                className="mt-2 w-full rounded-lg border border-white/12 bg-[#0b0b0d] px-4 py-3 text-sm text-white placeholder:text-zinc-500 focus:border-[#FF1744] focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="admin-password" className="block text-xs font-semibold text-zinc-200">
                {isFirstRun ? 'Create Strong Password (min 8 chars, letters + numbers)' : 'Password'}
              </label>
              <input
                id="admin-password"
                type="password"
                autoComplete={isFirstRun ? 'new-password' : 'current-password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="mt-2 w-full rounded-lg border border-white/12 bg-[#0b0b0d] px-4 py-3 text-sm text-white placeholder:text-zinc-500 focus:border-[#FF1744] focus:outline-none"
              />
            </div>

            {isFirstRun && (
              <div>
                <label htmlFor="admin-confirm-password" className="block text-xs font-semibold text-zinc-200">
                  Confirm Password
                </label>
                <input
                  id="admin-confirm-password"
                  type="password"
                  autoComplete="new-password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="mt-2 w-full rounded-lg border border-white/12 bg-[#0b0b0d] px-4 py-3 text-sm text-white placeholder:text-zinc-500 focus:border-[#FF1744] focus:outline-none"
                />
              </div>
            )}

            <button
              type="submit"
              disabled={submitting || checking}
              className="crimson-glow-btn w-full rounded-lg px-5 py-3.5 text-sm font-semibold text-white disabled:opacity-60 cursor-pointer"
            >
              {submitting
                ? 'Authenticating...'
                : isFirstRun
                  ? 'Claim Admin Account & Enter Dashboard'
                  : 'Sign In to Dashboard'}
            </button>
          </form>

          <p className="mt-6 text-[11px] leading-relaxed text-zinc-500">
            Protected by server-side scrypt hashing, session token verification, and login rate limiting. Set <code className="text-zinc-300">ADMIN_EMAIL</code> and <code className="text-zinc-300">ADMIN_PASSWORD</code> in server secrets for environment-managed production credentials.
          </p>
        </div>
      </div>
    </div>
  );
};
