import React, { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, Pause, Play, Star } from 'lucide-react';
import { PageShell } from '../components/PageShell';
import { SafeImage } from '../components/SafeImage';
import { useSite } from '../context/SiteContext';

export const TestimonialsPage: React.FC = () => {
  const { site } = useSite();
  const reviews = site.testimonials.filter((t) => t.published);
  const [activeIndex, setActiveIndex] = useState(0);
  const [paused, setPaused] = useState(false);

  const safeIndex = reviews.length > 0 ? activeIndex % reviews.length : 0;

  useEffect(() => {
    if (paused || reviews.length <= 1) return;
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reducedMotion) return;

    const timer = window.setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % reviews.length);
    }, 5500);

    return () => window.clearInterval(timer);
  }, [paused, reviews.length]);

  const handlePrev = () => {
    if (reviews.length === 0) return;
    setActiveIndex((prev) => (prev - 1 + reviews.length) % reviews.length);
  };

  const handleNext = () => {
    if (reviews.length === 0) return;
    setActiveIndex((prev) => (prev + 1) % reviews.length);
  };

  const current = reviews[safeIndex];

  return (
    <PageShell
      title="Testimonials"
      description="Client reviews and feedback for ALVISH – Digital Creative Studio."
    >
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-14 lg:py-22">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="max-w-2xl">
            <p className="text-xs font-semibold tracking-[0.24em] text-[#FF1744]">
              Client Feedback
            </p>
            <h1 className="mt-3 font-display text-4xl sm:text-5xl font-extrabold tracking-tight text-white">
              Client Reviews &amp; Testimonials
            </h1>
            <p className="mt-4 text-base text-zinc-400">
              Reviews published by ALVISH – Digital Creative Studio. Sample entries are clearly marked as demo content until replaced with verified client testimonials via Admin Dashboard.
            </p>
          </div>

          {reviews.length > 1 && (
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={handlePrev}
                aria-label="Previous review"
                className="inline-flex h-11 w-11 items-center justify-center rounded-lg border border-white/15 bg-white/[0.04] text-white hover:border-[#FF1744]/60 transition-colors cursor-pointer"
              >
                <ChevronLeft className="w-5 h-5" aria-hidden="true" />
              </button>
              <button
                type="button"
                onClick={() => setPaused((p) => !p)}
                aria-label={paused ? 'Resume automatic review slider' : 'Pause automatic review slider'}
                className="inline-flex h-11 items-center gap-2 rounded-lg border border-white/15 bg-white/[0.04] px-4 text-xs font-semibold text-white hover:border-[#FF1744]/60 transition-colors cursor-pointer whitespace-nowrap"
              >
                {paused ? (
                  <>
                    <Play className="w-4 h-4 text-[#FF1744]" aria-hidden="true" />
                    <span>Resume</span>
                  </>
                ) : (
                  <>
                    <Pause className="w-4 h-4 text-[#FF1744]" aria-hidden="true" />
                    <span>Pause</span>
                  </>
                )}
              </button>
              <button
                type="button"
                onClick={handleNext}
                aria-label="Next review"
                className="inline-flex h-11 w-11 items-center justify-center rounded-lg border border-white/15 bg-white/[0.04] text-white hover:border-[#FF1744]/60 transition-colors cursor-pointer"
              >
                <ChevronRight className="w-5 h-5" aria-hidden="true" />
              </button>
            </div>
          )}
        </div>

        {/* Always-Visible Featured Review Slider */}
        {reviews.length === 0 ? (
          <div className="mt-12 glass-panel rounded-2xl p-12 text-center">
            <p className="font-display text-xl font-semibold text-white">
              No client reviews published yet
            </p>
            <p className="mt-2 text-sm text-zinc-400">
              Add verified client reviews anytime in Admin Dashboard → Testimonials Management.
            </p>
          </div>
        ) : (
          <>
            {current && (
              <div
                data-testid="featured-testimonial-card"
                className="mt-10 glass-panel rounded-2xl p-8 sm:p-10 lg:p-12 border border-white/12 transition-all duration-300"
              >
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-1" aria-label={`Rated ${current.rating} out of 5 stars`}>
                    {Array.from({ length: 5 }).map((_, idx) => (
                      <Star
                        key={idx}
                        className={`w-5 h-5 ${
                          idx < current.rating
                            ? 'fill-[#FF1744] text-[#FF1744]'
                            : 'text-zinc-700'
                        }`}
                        aria-hidden="true"
                      />
                    ))}
                    <span className="ml-2 font-mono-tabular text-xs text-zinc-400">
                      {current.rating}.0 / 5.0
                    </span>
                  </div>

                  {current.isDemo && (
                    <span className="text-xs font-medium text-amber-300/90">
                      Demo Content · Replace with verified client review
                    </span>
                  )}
                </div>

                <blockquote className="mt-6 font-display text-xl sm:text-2xl lg:text-3xl font-medium leading-relaxed text-white">
                  &ldquo;{current.reviewText}&rdquo;
                </blockquote>

                <div className="mt-8 flex items-center justify-between gap-4 border-t border-white/[0.08] pt-6">
                  <div className="flex items-center gap-4">
                    <div className="h-14 w-14 overflow-hidden rounded-xl border border-white/15 bg-[#101010] shrink-0">
                      <SafeImage
                        src={current.clientAvatarUrl}
                        alt={current.clientName}
                        lazy={false}
                        className="h-full w-full object-cover"
                      />
                    </div>
                    <div>
                      <p className="font-display text-lg font-bold text-white">
                        {current.clientName}
                      </p>
                      <p className="text-xs sm:text-sm text-zinc-400">
                        {current.clientRole}
                        {current.clientCompany ? ` · ${current.clientCompany}` : ''}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {reviews.map((rev, idx) => (
                      <button
                        key={rev.id}
                        type="button"
                        onClick={() => setActiveIndex(idx)}
                        aria-label={`Show review ${idx + 1} by ${rev.clientName}`}
                        aria-current={idx === safeIndex ? 'true' : undefined}
                        className={`h-2.5 rounded-full transition-all cursor-pointer ${
                          idx === safeIndex
                            ? 'w-8 bg-[#FF1744]'
                            : 'w-2.5 bg-zinc-700 hover:bg-zinc-500'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Complete Always-Visible Reviews Grid */}
            <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-6">
              {reviews.map((rev, idx) => (
                <article
                  key={rev.id}
                  onClick={() => setActiveIndex(idx)}
                  className={`glass-panel rounded-2xl p-6 flex flex-col justify-between transition-colors ${
                    idx === safeIndex ? 'border-[#FF1744]/50' : 'border-white/[0.08]'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1" aria-label={`${rev.rating} out of 5 stars`}>
                        {Array.from({ length: 5 }).map((_, starIdx) => (
                          <Star
                            key={starIdx}
                            className={`w-4 h-4 ${
                              starIdx < rev.rating
                                ? 'fill-[#FF1744] text-[#FF1744]'
                                : 'text-zinc-700'
                            }`}
                            aria-hidden="true"
                          />
                        ))}
                      </div>
                      {rev.isDemo && (
                        <span className="text-[11px] font-medium text-amber-300/85">Demo Sample</span>
                      )}
                    </div>
                    <p className="mt-4 text-sm leading-relaxed text-zinc-300">
                      &ldquo;{rev.reviewText}&rdquo;
                    </p>
                  </div>

                  <div className="mt-6 flex items-center gap-3 border-t border-white/[0.07] pt-4">
                    <div className="h-10 w-10 overflow-hidden rounded-lg border border-white/10 shrink-0">
                      <SafeImage
                        src={rev.clientAvatarUrl}
                        alt={rev.clientName}
                        className="h-full w-full object-cover"
                      />
                    </div>
                    <div className="min-w-0">
                      <p className="font-display text-sm font-semibold text-white truncate">
                        {rev.clientName}
                      </p>
                      <p className="text-xs text-zinc-400 truncate">
                        {rev.clientRole}
                        {rev.clientCompany ? ` · ${rev.clientCompany}` : ''}
                      </p>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </>
        )}
      </section>
    </PageShell>
  );
};
