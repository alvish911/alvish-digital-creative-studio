import React, { useState } from 'react';
import { CheckCircle2, AlertCircle, Instagram, Mail, MapPin, MessageCircle, Phone, Send } from 'lucide-react';
import { PageShell } from '../components/PageShell';
import { useSite } from '../context/SiteContext';
import { safeHref, validateContactForm } from '../shared/validation';
import {
  buildNetlifyFormBody,
  readJsonApiResponse,
  saveStaticEnquiry,
} from '../utils/hostingMode';

export const ContactPage: React.FC = () => {
  const { site } = useSite();
  const { contact } = site;

  const [form, setForm] = useState({
    name: '',
    phone: '',
    email: '',
    message: '',
  });
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [serverFeedback, setServerFeedback] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setServerFeedback(null);

    const check = validateContactForm(form);
    if (!check.valid) {
      setFieldErrors(check.errors);
      return;
    }
    setFieldErrors({});
    setSubmitting(true);

    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const parsed = await readJsonApiResponse<{
        ok?: boolean;
        message?: string;
        error?: string;
        errors?: Record<string, string>;
      }>(res);

      if (parsed.isJson) {
        if (!parsed.ok) {
          if (parsed.data?.errors) setFieldErrors(parsed.data.errors);
          setServerFeedback({
            type: 'error',
            message:
              parsed.data?.error ||
              'Unable to submit your message right now. Please try again or reach out on WhatsApp.',
          });
          return;
        }

        setServerFeedback({
          type: 'success',
          message:
            parsed.data?.message ||
            'Your message was received and saved by ALVISH – Digital Creative Studio.',
        });
        setForm({ name: '', phone: '', email: '', message: '' });
        return;
      }

      // Static hosting mode (Netlify / Vercel): submit via Netlify Forms when available
      let netlifyDelivered = false;
      try {
        const netlifyRes = await fetch('/', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: buildNetlifyFormBody('contact', form),
        });
        netlifyDelivered = netlifyRes.ok;
      } catch {
        netlifyDelivered = false;
      }

      saveStaticEnquiry(form);
      setServerFeedback({
        type: 'success',
        message: netlifyDelivered
          ? 'Your enquiry has been received by ALVISH – Digital Creative Studio. For the fastest reply, you can also message us directly on WhatsApp.'
          : 'Your enquiry has been recorded. For instant studio response on static hosting, please tap "Chat on WhatsApp" directly.',
      });
      setForm({ name: '', phone: '', email: '', message: '' });
    } catch {
      setServerFeedback({
        type: 'error',
        message: 'Network error while reaching the studio server. Your message was not sent—please retry or contact via WhatsApp.',
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <PageShell
      title="Contact"
      description="Contact ALVISH – Digital Creative Studio via WhatsApp (8247206736), Instagram (alvish_studios_dwm), or the direct project enquiry form."
    >
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-14 lg:py-22">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Left Direct Studio Channels */}
          <div className="lg:col-span-5 space-y-6">
            <div>
              <p className="text-xs font-semibold tracking-[0.24em] text-[#FF1744]">
                Direct Studio Access
              </p>
              <h1 className="mt-3 font-display text-4xl sm:text-5xl font-extrabold tracking-tight text-white">
                {contact.studioName}
              </h1>
              <p className="mt-1 font-display text-base font-semibold tracking-[0.18em] text-zinc-300">
                {contact.subName}
              </p>
              <p className="mt-4 text-sm sm:text-base leading-relaxed text-zinc-400">
                {contact.availabilityText}
              </p>
            </div>

            <div className="glass-panel rounded-2xl p-6 space-y-5">
              <div className="flex items-start gap-3.5">
                <Phone className="w-5 h-5 text-[#FF1744] shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="text-xs text-zinc-400">WhatsApp Direct</p>
                  <p className="font-mono-tabular text-base font-semibold text-white">
                    {contact.whatsappNumber}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3.5 border-t border-white/[0.07] pt-5">
                <Instagram className="w-5 h-5 text-[#FF1744] shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="text-xs text-zinc-400">Instagram</p>
                  <p className="text-base font-semibold text-white">
                    @{contact.instagramHandle}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3.5 border-t border-white/[0.07] pt-5">
                <Mail className="w-5 h-5 text-[#FF1744] shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="text-xs text-zinc-400">Email</p>
                  <p className="text-sm font-medium text-zinc-200">{contact.email}</p>
                </div>
              </div>

              <div className="flex items-start gap-3.5 border-t border-white/[0.07] pt-5">
                <MapPin className="w-5 h-5 text-[#FF1744] shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="text-xs text-zinc-400">Location</p>
                  <p className="text-sm font-medium text-zinc-200">{contact.location}</p>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <a
                href={safeHref(contact.whatsappLink, 'https://wa.me/918247206736')}
                target="_blank"
                rel="noopener noreferrer"
                className="crimson-glow-btn inline-flex flex-1 items-center justify-center gap-2 rounded-lg px-5 py-3.5 text-sm font-semibold text-white whitespace-nowrap"
              >
                <MessageCircle className="w-4 h-4" aria-hidden="true" />
                <span>Chat on WhatsApp</span>
              </a>
              <a
                href={safeHref(contact.instagramUrl, 'https://instagram.com/alvish_studios_dwm')}
                target="_blank"
                rel="noopener noreferrer"
                className="glass-panel inline-flex flex-1 items-center justify-center gap-2 rounded-lg px-5 py-3.5 text-sm font-semibold text-white hover:border-[#FF1744]/50 whitespace-nowrap"
              >
                <Instagram className="w-4 h-4 text-[#FF1744]" aria-hidden="true" />
                <span>Follow Instagram</span>
              </a>
            </div>
          </div>

          {/* Right Contact Enquiry Form */}
          <div className="lg:col-span-7">
            <form
              onSubmit={handleSubmit}
              noValidate
              className="glass-panel rounded-2xl p-6 sm:p-8 lg:p-10 space-y-6"
            >
              <div>
                <h2 className="font-display text-2xl font-bold text-white">
                  Send a Project Enquiry
                </h2>
                <p className="mt-1 text-sm text-zinc-400">
                  Tell us about your website, AI video, song, or branding goals. Submissions are saved directly to our studio inbox.
                </p>
              </div>

              {serverFeedback && (
                <div
                  role="status"
                  aria-live="polite"
                  className={`flex items-start gap-3 rounded-xl border px-4 py-3.5 text-sm ${
                    serverFeedback.type === 'success'
                      ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-200'
                      : 'border-[#FF1744]/50 bg-[#FF1744]/10 text-red-200'
                  }`}
                >
                  {serverFeedback.type === 'success' ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" aria-hidden="true" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-[#FF1744] shrink-0 mt-0.5" aria-hidden="true" />
                  )}
                  <span>{serverFeedback.message}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label htmlFor="contact-name" className="block text-xs font-semibold text-zinc-200">
                    Your Name
                  </label>
                  <input
                    id="contact-name"
                    name="name"
                    type="text"
                    required
                    value={form.name}
                    onChange={(e) => setForm((prev) => ({ ...prev, name: e.target.value }))}
                    placeholder="Full name"
                    className="mt-2 w-full rounded-lg border border-white/12 bg-[#0b0b0d] px-4 py-3 text-sm text-white placeholder:text-zinc-500 focus:border-[#FF1744] focus:outline-none"
                  />
                  {fieldErrors.name && (
                    <p className="mt-1.5 text-xs text-[#FF1744]">{fieldErrors.name}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="contact-phone" className="block text-xs font-semibold text-zinc-200">
                    Phone / WhatsApp Number
                  </label>
                  <input
                    id="contact-phone"
                    name="phone"
                    type="tel"
                    required
                    value={form.phone}
                    onChange={(e) => setForm((prev) => ({ ...prev, phone: e.target.value }))}
                    placeholder="+91 98765 43210"
                    className="mt-2 w-full rounded-lg border border-white/12 bg-[#0b0b0d] px-4 py-3 text-sm text-white placeholder:text-zinc-500 focus:border-[#FF1744] focus:outline-none"
                  />
                  {fieldErrors.phone && (
                    <p className="mt-1.5 text-xs text-[#FF1744]">{fieldErrors.phone}</p>
                  )}
                </div>
              </div>

              <div>
                <label htmlFor="contact-email" className="block text-xs font-semibold text-zinc-200">
                  Email Address
                </label>
                <input
                  id="contact-email"
                  name="email"
                  type="email"
                  required
                  value={form.email}
                  onChange={(e) => setForm((prev) => ({ ...prev, email: e.target.value }))}
                  placeholder="you@brand.com"
                  className="mt-2 w-full rounded-lg border border-white/12 bg-[#0b0b0d] px-4 py-3 text-sm text-white placeholder:text-zinc-500 focus:border-[#FF1744] focus:outline-none"
                />
                {fieldErrors.email && (
                  <p className="mt-1.5 text-xs text-[#FF1744]">{fieldErrors.email}</p>
                )}
              </div>

              <div>
                <label htmlFor="contact-message" className="block text-xs font-semibold text-zinc-200">
                  Project Details
                </label>
                <textarea
                  id="contact-message"
                  name="message"
                  rows={5}
                  required
                  value={form.message}
                  onChange={(e) => setForm((prev) => ({ ...prev, message: e.target.value }))}
                  placeholder="Share your goals, service or package interest, and desired timeline..."
                  className="mt-2 w-full rounded-lg border border-white/12 bg-[#0b0b0d] px-4 py-3 text-sm text-white placeholder:text-zinc-500 focus:border-[#FF1744] focus:outline-none"
                />
                {fieldErrors.message && (
                  <p className="mt-1.5 text-xs text-[#FF1744]">{fieldErrors.message}</p>
                )}
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="crimson-glow-btn inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-lg px-7 py-3.5 text-sm font-semibold text-white disabled:opacity-60 cursor-pointer"
              >
                <Send className="w-4 h-4" aria-hidden="true" />
                <span>{submitting ? 'Sending Enquiry...' : 'Submit Enquiry'}</span>
              </button>
            </form>
          </div>
        </div>
      </section>
    </PageShell>
  );
};
