import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ArrowRight, MessageCircle, ArrowUpRight, Check } from 'lucide-react';
import { PageShell } from '../components/PageShell';
import { SafeImage } from '../components/SafeImage';
import { ServiceIcon } from '../components/ServiceIcon';
import { useSite } from '../context/SiteContext';
import { buildWhatsAppUrl, safeHref } from '../shared/validation';

export const HomePage: React.FC = () => {
  const { site } = useSite();
  const featuredProjects = [...site.portfolio]
    .filter((p) => p.published && p.featured)
    .sort((a, b) => a.order - b.order)
    .slice(0, 4);

  const featuredServices = site.services.filter((s) => s.active && s.featured).slice(0, 4);

  return (
    <PageShell>
      {/* Hero Section: Split 2-Column with matching height + Full-Width KPI Row below */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-12 pb-16 lg:pt-20 lg:pb-24">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
          {/* Left Typographic Anchor */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            <p className="text-xs font-semibold tracking-[0.26em] text-[#FF1744]">
              {site.home.designation}
            </p>

            <h1 className="mt-4 font-display text-5xl sm:text-6xl lg:text-[4.5rem] font-extrabold tracking-tight leading-[1.02] text-white text-balance">
              {site.home.brandName}
            </h1>

            <p className="mt-3 font-display text-lg sm:text-2xl font-semibold tracking-[0.14em] text-zinc-200">
              {site.home.subheading}
            </p>

            <p className="mt-6 max-w-2xl text-base sm:text-lg leading-relaxed text-zinc-300">
              {site.home.description}
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-3.5">
              <Link
                to="/portfolio"
                className="crimson-glow-btn inline-flex items-center gap-2 rounded-lg px-6 py-3.5 text-sm font-semibold text-white whitespace-nowrap shrink-0"
              >
                <span>View My Work</span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </Link>

              <Link
                to="/contact"
                className="glass-panel inline-flex items-center gap-2 rounded-lg px-6 py-3.5 text-sm font-semibold text-white hover:border-[#FF1744]/50 transition-colors whitespace-nowrap shrink-0"
              >
                <span>Contact Me</span>
              </Link>

              <a
                href={safeHref(
                  buildWhatsAppUrl(
                    site.contact.whatsappLink,
                    'Hello ALVISH – Digital Creative Studio, I would like to discuss a project.',
                  ),
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-lg border border-white/12 bg-white/[0.03] px-5 py-3.5 text-sm font-medium text-zinc-200 hover:border-[#FF1744]/50 hover:text-white transition-colors whitespace-nowrap shrink-0"
              >
                <MessageCircle className="w-4 h-4 text-[#FF1744]" aria-hidden="true" />
                <span>WhatsApp</span>
              </a>
            </div>

            <div className="mt-8 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-zinc-400">
              <span>Website Designing</span>
              <span aria-hidden="true">·</span>
              <span>AI Videos &amp; Songs</span>
              <span aria-hidden="true">·</span>
              <span>Meta Ads &amp; UGC AI</span>
              <span aria-hidden="true">·</span>
              <span>Luxury Branding</span>
            </div>
          </div>

          {/* Right Portrait Visual Frame */}
          <motion.div
            initial={{ opacity: 0.9, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 flex"
          >
            <div className="relative w-full min-h-[380px] sm:min-h-[440px] lg:h-full overflow-hidden rounded-2xl border border-white/10 bg-[#101010] shadow-[0_24px_80px_-24px_rgba(255,23,68,0.35)]">
              <SafeImage
                src={site.home.portraitUrl}
                alt="ALVISH — Founder of ALVISH Digital Creative Studio"
                lazy={false}
                className="h-full w-full object-cover object-top"
              />
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-transparent opacity-80"
              />
              <div className="absolute inset-x-0 bottom-0 p-6">
                <p className="text-xs font-medium tracking-[0.2em] text-[#FF1744]">
                  {site.home.revealTagline}
                </p>
                <p className="mt-1 font-display text-lg font-semibold text-white">
                  {site.contact.studioName} · {site.contact.location}
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Full-Width 4-Column Studio Metric Strip below Hero Split */}
        <div className="mt-12 grid grid-cols-2 lg:grid-cols-4 gap-4">
          {site.home.stats.map((stat) => (
            <div
              key={stat.id}
              className="glass-panel rounded-xl px-6 py-5"
            >
              <p className="font-mono-tabular text-2xl sm:text-3xl font-semibold text-white">
                {stat.value}
              </p>
              <p className="mt-1 text-xs sm:text-sm text-zinc-400">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Studio Introduction & Core Capabilities */}
      <section className="border-t border-white/[0.07] py-16 lg:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
            <div className="lg:col-span-5">
              <p className="text-xs font-semibold tracking-[0.22em] text-[#FF1744]">
                Studio Introduction
              </p>
              <h2 className="mt-3 font-display text-3xl sm:text-4xl font-bold tracking-tight text-white text-balance">
                {site.home.introHeading}
              </h2>
              <p className="mt-5 text-base leading-relaxed text-zinc-400">
                {site.home.introBody}
              </p>
              <div className="mt-7 flex items-center gap-5">
                <Link
                  to="/about"
                  className="inline-flex items-center gap-2 text-sm font-semibold text-white hover:text-[#FF1744] transition-colors"
                >
                  <span>About the Studio</span>
                  <ArrowUpRight className="w-4 h-4" aria-hidden="true" />
                </Link>
                <Link
                  to="/services"
                  className="inline-flex items-center gap-2 text-sm font-medium text-zinc-400 hover:text-white transition-colors"
                >
                  <span>Explore All 12 Services</span>
                </Link>
              </div>
            </div>

            <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {featuredServices.map((srv, idx) => (
                <div
                  key={srv.id}
                  className="glass-panel glass-panel-hover rounded-xl p-6 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-[#FF1744]/12 text-[#FF1744]">
                        <ServiceIcon name={srv.iconName} />
                      </span>
                      <span className="font-mono-tabular text-xs text-zinc-400">
                        0{idx + 1} · From {srv.startingPrice}
                      </span>
                    </div>
                    <h3 className="mt-5 font-display text-lg font-semibold text-white">
                      {srv.title}
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-zinc-400">
                      {srv.shortDescription}
                    </p>
                  </div>
                  <div className="mt-5 pt-4 border-t border-white/[0.06]">
                    <Link
                      to="/services"
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-zinc-200 hover:text-[#FF1744] transition-colors"
                    >
                      <span>View Service Details</span>
                      <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Featured Projects Showcase */}
      {site.theme.sectionVisibility.featuredWork && featuredProjects.length > 0 && (
        <section className="border-t border-white/[0.07] py-16 lg:py-24">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
              <div>
                <p className="text-xs font-semibold tracking-[0.22em] text-[#FF1744]">
                  Selected Work
                </p>
                <h2 className="mt-2 font-display text-3xl sm:text-4xl font-bold tracking-tight text-white">
                  Featured Studio Projects
                </h2>
              </div>
              <Link
                to="/portfolio"
                className="inline-flex items-center gap-2 text-sm font-semibold text-white hover:text-[#FF1744] transition-colors whitespace-nowrap"
              >
                <span>Open Full Portfolio</span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </Link>
            </div>

            <div className="mt-10 grid grid-cols-1 md:grid-cols-2 gap-6">
              {featuredProjects.map((project) => (
                <Link
                  key={project.id}
                  to={`/portfolio?category=${encodeURIComponent(project.category)}`}
                  className="group glass-panel glass-panel-hover overflow-hidden rounded-2xl flex flex-col"
                >
                  <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#101010]">
                    <SafeImage
                      src={project.imageUrl}
                      alt={project.title}
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div
                      aria-hidden="true"
                      className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#050505]/85 via-[#050505]/20 to-transparent"
                    />
                  </div>
                  <div className="p-6 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-2 text-xs text-zinc-400">
                        <span className="text-[#FF1744] font-medium">{project.category}</span>
                        <span aria-hidden="true">·</span>
                        <span>{project.year}</span>
                        {project.metrics && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span>{project.metrics}</span>
                          </>
                        )}
                      </div>
                      <h3 className="mt-2 font-display text-xl font-semibold text-white group-hover:text-[#FF1744] transition-colors">
                        {project.title}
                      </h3>
                      <p className="mt-2 text-sm leading-relaxed text-zinc-400">
                        {project.summary}
                      </p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Website Design Packages Teaser */}
      {site.theme.sectionVisibility.pricingPackages && (
        <section className="border-t border-white/[0.07] py-16 lg:py-24">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
              <div>
                <p className="text-xs font-semibold tracking-[0.22em] text-[#FF1744]">
                  Website Design Packages
                </p>
                <h2 className="mt-2 font-display text-3xl sm:text-4xl font-bold tracking-tight text-white">
                  Transparent Studio Pricing
                </h2>
              </div>
              <Link
                to="/services#packages"
                className="inline-flex items-center gap-2 text-sm font-semibold text-white hover:text-[#FF1744] transition-colors whitespace-nowrap"
              >
                <span>Compare All Services</span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </Link>
            </div>

            <div className="mt-10 grid grid-cols-1 lg:grid-cols-3 gap-6">
              {site.pricingPackages.map((pkg) => (
                <div
                  key={pkg.id}
                  className={`rounded-2xl p-7 flex flex-col justify-between transition-all ${
                    pkg.highlighted
                      ? 'glass-panel border-[#FF1744]/50 shadow-[0_24px_60px_-24px_rgba(255,23,68,0.4)]'
                      : 'glass-panel'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <h3 className="font-display text-lg font-bold tracking-wide text-white">
                        {pkg.name}
                      </h3>
                      {pkg.highlighted && (
                        <span className="text-xs font-semibold text-[#FF1744]">Most Popular</span>
                      )}
                    </div>
                    <p className="mt-1 text-xs text-zinc-400">{pkg.audience}</p>
                    <p className="mt-5 font-mono-tabular text-4xl font-bold text-white">
                      {pkg.price}
                    </p>
                    <ul className="mt-6 space-y-3 border-t border-white/[0.08] pt-5 text-sm text-zinc-300">
                      {pkg.features.map((feat, i) => (
                        <li key={i} className="flex items-start gap-2.5">
                          <Check className="w-4 h-4 text-[#FF1744] shrink-0 mt-0.5" aria-hidden="true" />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <a
                    href={safeHref(buildWhatsAppUrl(site.contact.whatsappLink, pkg.whatsappPrompt))}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`mt-8 inline-flex w-full items-center justify-center gap-2 rounded-lg px-5 py-3 text-sm font-semibold transition-colors ${
                      pkg.highlighted
                        ? 'crimson-glow-btn text-white'
                        : 'border border-white/15 bg-white/[0.04] text-white hover:border-[#FF1744]/50'
                    }`}
                  >
                    <MessageCircle className="w-4 h-4" aria-hidden="true" />
                    <span>Enquire on WhatsApp</span>
                  </a>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Closing CTA Band */}
      <section className="border-t border-white/[0.07] py-16 lg:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="glass-panel rounded-2xl px-8 py-12 sm:px-12 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8">
            <div className="max-w-2xl">
              <p className="text-xs font-semibold tracking-[0.24em] text-[#FF1744]">
                {site.home.revealTagline}
              </p>
              <h2 className="mt-3 font-display text-3xl sm:text-4xl font-bold tracking-tight text-white text-balance">
                Ready to build a website or AI campaign that stands apart?
              </h2>
            </div>
            <div className="flex flex-wrap items-center gap-3 shrink-0">
              <Link
                to="/contact"
                className="crimson-glow-btn inline-flex items-center gap-2 rounded-lg px-6 py-3.5 text-sm font-semibold text-white whitespace-nowrap"
              >
                <span>Start a Project</span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </Link>
              <a
                href={safeHref(site.contact.whatsappLink, 'https://wa.me/918247206736')}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-lg border border-white/15 bg-white/[0.04] px-5 py-3.5 text-sm font-medium text-white hover:border-[#FF1744]/50 whitespace-nowrap"
              >
                <MessageCircle className="w-4 h-4 text-[#FF1744]" aria-hidden="true" />
                <span>WhatsApp {site.contact.whatsappNumber}</span>
              </a>
            </div>
          </div>
        </div>
      </section>
    </PageShell>
  );
};
