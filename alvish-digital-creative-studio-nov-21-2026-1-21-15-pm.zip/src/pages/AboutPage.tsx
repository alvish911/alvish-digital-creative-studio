import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, MessageCircle } from 'lucide-react';
import { PageShell } from '../components/PageShell';
import { SafeImage } from '../components/SafeImage';
import { useSite } from '../context/SiteContext';
import { safeHref } from '../shared/validation';

export const AboutPage: React.FC = () => {
  const { site } = useSite();
  const { about, home, contact } = site;

  return (
    <PageShell
      title="About"
      description={`Learn about ${home.brandName} – ${home.subheading}, founder journey, creative vision, mission, and goals.`}
    >
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-14 lg:py-22">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
          {/* Portrait Column */}
          <div className="lg:col-span-5 flex">
            <div className="relative w-full min-h-[380px] overflow-hidden rounded-2xl border border-white/10 bg-[#101010] shadow-[0_24px_70px_-24px_rgba(255,23,68,0.3)]">
              <SafeImage
                src={about.profileImageUrl}
                alt={`${home.brandName} portrait`}
                lazy={false}
                className="h-full w-full object-cover object-top"
              />
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-transparent opacity-75"
              />
              <div className="absolute inset-x-0 bottom-0 p-6">
                <p className="font-display text-2xl font-bold text-white">{home.brandName}</p>
                <p className="text-xs font-semibold tracking-[0.2em] text-[#FF1744] mt-1">
                  {home.designation}
                </p>
              </div>
            </div>
          </div>

          {/* Brand Introduction & Personal Bio */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            <p className="text-xs font-semibold tracking-[0.24em] text-[#FF1744]">
              About the Founder &amp; Studio
            </p>
            <h1 className="mt-3 font-display text-4xl sm:text-5xl font-extrabold tracking-tight text-white text-balance">
              {home.brandName} – {home.subheading}
            </h1>

            <p className="mt-6 text-base sm:text-lg leading-relaxed text-zinc-200">
              {about.brandIntroduction}
            </p>
            <p className="mt-4 text-base leading-relaxed text-zinc-400">
              {about.personalDescription}
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-3.5">
              <Link
                to="/portfolio"
                className="crimson-glow-btn inline-flex items-center gap-2 rounded-lg px-6 py-3 text-sm font-semibold text-white whitespace-nowrap"
              >
                <span>Explore Portfolio</span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </Link>
              <a
                href={safeHref(contact.whatsappLink, 'https://wa.me/918247206736')}
                target="_blank"
                rel="noopener noreferrer"
                className="glass-panel inline-flex items-center gap-2 rounded-lg px-5 py-3 text-sm font-medium text-white hover:border-[#FF1744]/50 whitespace-nowrap"
              >
                <MessageCircle className="w-4 h-4 text-[#FF1744]" aria-hidden="true" />
                <span>Connect on WhatsApp</span>
              </a>
            </div>
          </div>
        </div>

        {/* Animated / Tabular Statistics Row */}
        <div className="mt-14 grid grid-cols-2 lg:grid-cols-4 gap-4">
          {about.stats.map((stat) => (
            <div key={stat.id} className="glass-panel rounded-xl px-6 py-6">
              <p className="font-mono-tabular text-3xl sm:text-4xl font-bold text-white">
                {stat.value}
              </p>
              <p className="mt-1.5 text-sm text-zinc-400">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Professional Journey, Creative Vision, Mission & Goals */}
        <div className="mt-14 grid grid-cols-1 lg:grid-cols-2 gap-6">
          <article className="glass-panel rounded-2xl p-8">
            <p className="text-xs font-semibold tracking-[0.2em] text-[#FF1744]">01. Professional Journey</p>
            <h2 className="mt-3 font-display text-2xl font-bold text-white">
              From Visual Craft to Full-Spectrum AI Studio
            </h2>
            <p className="mt-4 text-sm sm:text-base leading-relaxed text-zinc-300">
              {about.professionalJourney}
            </p>
          </article>

          <article className="glass-panel rounded-2xl p-8">
            <p className="text-xs font-semibold tracking-[0.2em] text-[#FF1744]">02. Creative Vision</p>
            <h2 className="mt-3 font-display text-2xl font-bold text-white">
              Unmistakable Digital Presence
            </h2>
            <p className="mt-4 text-sm sm:text-base leading-relaxed text-zinc-300">
              {about.creativeVision}
            </p>
          </article>

          <article className="glass-panel rounded-2xl p-8">
            <p className="text-xs font-semibold tracking-[0.2em] text-[#FF1744]">03. Studio Mission</p>
            <h2 className="mt-3 font-display text-2xl font-bold text-white">
              Direct Founder-Level Execution
            </h2>
            <p className="mt-4 text-sm sm:text-base leading-relaxed text-zinc-300">
              {about.mission}
            </p>
          </article>

          <article className="glass-panel rounded-2xl p-8">
            <p className="text-xs font-semibold tracking-[0.2em] text-[#FF1744]">04. Strategic Goals</p>
            <h2 className="mt-3 font-display text-2xl font-bold text-white">
              Scaling Modern Brands Faster
            </h2>
            <p className="mt-4 text-sm sm:text-base leading-relaxed text-zinc-300">
              {about.goals}
            </p>
          </article>
        </div>
      </section>
    </PageShell>
  );
};
