import React from 'react';
import { motion } from 'motion/react';
import { PageShell } from '../components/PageShell';
import { useSite } from '../context/SiteContext';
import { clampPercentage } from '../shared/validation';

export const SkillsPage: React.FC = () => {
  const { site } = useSite();

  // Group skills by discipline for the structured capability layout
  const categories = Array.from(new Set(site.skills.map((s) => s.category || 'Studio Craft')));

  return (
    <PageShell
      title="Skills"
      description="Core creative, web engineering, AI video, AI audio, and marketing skills of ALVISH – Digital Creative Studio."
    >
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-14 lg:py-22">
        <div className="max-w-2xl">
          <p className="text-xs font-semibold tracking-[0.24em] text-[#FF1744]">
            Technical &amp; Creative Proficiency
          </p>
          <h1 className="mt-3 font-display text-4xl sm:text-5xl font-extrabold tracking-tight text-white">
            Skills &amp; Studio Craft
          </h1>
          <p className="mt-4 text-base text-zinc-400">
            Combining web engineering, cinema-grade AI media workflows, and brand design systems. All skill levels are editable directly from the Admin Dashboard.
          </p>
        </div>

        {/* Section 1: Animated Skill Progress Bars */}
        <div className="mt-12 glass-panel rounded-2xl p-6 sm:p-10">
          <h2 className="font-display text-xl font-bold text-white">
            Proficiency Index
          </h2>
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-x-10 gap-y-7">
            {site.skills.map((skill) => {
              const pct = clampPercentage(skill.percentage);
              return (
                <div key={skill.id} className="space-y-2.5">
                  <div className="flex items-baseline justify-between gap-4">
                    <div>
                      <h3 className="font-display text-base font-semibold text-white">
                        {skill.name}
                      </h3>
                      <p className="text-xs text-zinc-500">{skill.category}</p>
                    </div>
                    <span className="font-mono-tabular text-sm font-semibold text-[#FF1744]">
                      {pct}%
                    </span>
                  </div>

                  <div
                    role="progressbar"
                    aria-label={skill.name}
                    aria-valuenow={pct}
                    aria-valuemin={0}
                    aria-valuemax={100}
                    className="h-2.5 w-full overflow-hidden rounded-full bg-white/[0.08]"
                  >
                    <motion.div
                      initial={{ scaleX: 0 }}
                      whileInView={{ scaleX: pct / 100 }}
                      viewport={{ once: true, amount: 0.1 }}
                      transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
                      style={{ transformOrigin: 'left center' }}
                      className="h-full w-full rounded-full bg-gradient-to-r from-[#8B0000] via-[#FF1744] to-[#ff5274] shadow-[0_0_16px_rgba(255,23,68,0.65)]"
                    />
                  </div>

                  {skill.description && (
                    <p className="text-xs leading-relaxed text-zinc-400">
                      {skill.description}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Section 2: Reference-Inspired Discipline Cards Layout */}
        <div className="mt-12">
          <h2 className="font-display text-2xl font-bold text-white">
            Studio Disciplines
          </h2>
          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            {categories.map((category, idx) => {
              const items = site.skills.filter((s) => (s.category || 'Studio Craft') === category);
              const avg = Math.round(
                items.reduce((acc, s) => acc + clampPercentage(s.percentage), 0) /
                  Math.max(1, items.length),
              );
              return (
                <div key={category} className="glass-panel glass-panel-hover rounded-2xl p-7">
                  <div className="flex items-center justify-between gap-4 border-b border-white/[0.08] pb-4">
                    <div>
                      <span className="font-mono-tabular text-xs text-[#FF1744]">
                        {String(idx + 1).padStart(2, '0')}
                      </span>
                      <h3 className="mt-1 font-display text-xl font-bold text-white">
                        {category}
                      </h3>
                    </div>
                    <span className="font-mono-tabular text-2xl font-bold text-white">
                      {avg}%
                    </span>
                  </div>
                  <ul className="mt-5 space-y-3.5">
                    {items.map((item) => (
                      <li key={item.id} className="flex items-start justify-between gap-4 text-sm">
                        <div>
                          <p className="font-medium text-zinc-100">{item.name}</p>
                          {item.description && (
                            <p className="mt-0.5 text-xs text-zinc-400">{item.description}</p>
                          )}
                        </div>
                        <span className="font-mono-tabular text-xs text-zinc-300 shrink-0">
                          {clampPercentage(item.percentage)}%
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </PageShell>
  );
};
